function show_variables() {
    
    chrome.storage.sync.get( "showLogs", function (obj) {
        if (obj.showLogs)
            document.getElementById('showLogs').value = obj.showLogs;
    });
    
    chrome.storage.local.get( "appList", function (obj) {
        theAppList = obj.appList.split(",");
        theAppList = theAppList.join(", ");
        document.getElementById('appList').innerHTML = theAppList;

    });
    chrome.storage.local.get( "urlList", function (obj) {
        theUrlList = obj.urlList;
        theUrlString = "";
        theUrlList.forEach(function(element, index, array) {
            theUrlString+= element.url + ",";
        });

        document.getElementById('urlList').innerHTML = theUrlString;

    });

    chrome.storage.local.get( "recordingsList", function (obj) {
        recordingsList = obj.recordingsList;
        theRecordingsString = "";
        theRecordingsList.forEach(function(element, index, array) {
            theUrlString+= element + ",";
        });
        document.getElementById('recordingsList').innerHTML = theRecordingsString;

    });

    chrome.storage.local.get( "appsLog", function (obj) {
        theAppsLog = obj.appsLog;
        theAppsString ="";

        theAppsLog.forEach(function (element) {
            theAppsString+= element.app + " : " + element.occurences + ", ";
        });

        console.log(theAppsString);
        document.getElementById('appsLog').innerHTML = theAppsString;
    });
    chrome.storage.local.get( "geoloc", function (obj) {
        document.getElementById('geolocation').innerHTML = obj.geoloc.val
    });

    // OG-733
    chrome.storage.local.get( "defaultGeolocation", function (obj) {
        console.log('Fetching defaultGeolocation: ', obj);
        if (obj.defaultGeolocation)
            document.getElementById('defaultGeolocation').value = obj.defaultGeolocation.val;
    });
    
    chrome.storage.sync.get( "endpoint", function (obj) {
        if(obj.endpoint) {
            document.getElementById('endpoint').value = obj.endpoint;
        }
    });

     chrome.storage.local.get( "admin", function (obj) {
        document.getElementById('admin').innerHTML = obj.admin;
    });

     chrome.storage.local.get( "geocached", function (obj) {
        currentTime = Date.now();
        timeDiff = currentTime - obj.geocached.val;
        document.getElementById('geolocation_last_refresh').innerHTML = timeDiff / 60000;
    });

   /* chrome.storage.local.get( "sdcode", function (obj) {
        document.getElementById('sdcode').innerHTML = obj.sdcode.val;
    });
    */

    chrome.storage.local.get( "geoip", function (obj) {
        document.getElementById('country').innerHTML = obj.geoip.val.country;
        document.getElementById('state').innerHTML = obj.geoip.val.state;
        document.getElementById('city').innerHTML = obj.geoip.val.city;

    });


}

//document.getElementById('delete_sdcode').onclick=function(){chrome.storage.local.remove("sdcode"); location.reload();};
document.getElementById('delete_appList').onclick=function(){chrome.storage.local.remove("appList"); chrome.storage.local.remove("appsCache"); location.reload();};
document.getElementById('delete_urlList').onclick=function(){chrome.storage.local.remove("urlList"); chrome.storage.local.remove("urlCache"); location.reload();};
document.getElementById('delete_endpoint').onclick=function(){chrome.storage.sync.remove("endpoint"); location.reload();};
document.getElementById('update_endpoint').onclick=function(){chrome.storage.sync.set( {"endpoint": document.getElementById('endpoint').value }, function (obj) {}); location.reload();};
document.getElementById('delete_appsLog').onclick=function(){chrome.storage.local.remove("appsLog"); location.reload();};
document.getElementById('delete_geolocation').onclick=function(){chrome.storage.local.remove("geoloc"); location.reload();};
document.getElementById('delete_geolocation_last_refresh').onclick=function(){chrome.storage.local.remove("geocached"); location.reload();};
document.getElementById('update_defaultGeolocation').onclick=function() {
    chrome.runtime.sendMessage ( {command: "setDefaultGeolocation", coords: document.getElementById('defaultGeolocation').value.trim()}, (response) => { console.log('geolocation set response: ', response)} );
    chrome.storage.local.set( {"defaultGeolocation": {'val': document.getElementById('defaultGeolocation').value.trim()}}, (obj) => {console.log('Setting def geoloc from options - results: ', obj)} );
    location.reload(); 
};
document.getElementById('delete_defaultGeolocation').onclick=function(){chrome.storage.local.remove("defaultGeolocation"); location.reload();};
document.getElementById('delete_country').onclick=function(){chrome.storage.local.remove("geoip"); location.reload();};
document.getElementById('delete_showLogs').onclick=function(){chrome.storage.sync.remove("showLogs"); location.reload();};
document.getElementById('update_showLogs').onclick=function(){chrome.storage.sync.set( {"showLogs": document.getElementById('showLogs').value }, function (obj) {}); location.reload(); };

document.addEventListener('DOMContentLoaded',show_variables);

