stop = false;
theServer = "";
cloudServiceUrl = "";
action = 1;
globalTimeout = 10000;
account = "none";
masterpass = false;
cacheLimit = 30000;
trainingFields = [];
extraAuthenticationField = "";
extraAuthenticationField2 = "";
fallback = 0;
fallback_limit = 30;
attempts_count = 0;
fallback_seconds = 0;
kill_popup_limit = 60;
bulk = false;
theElementList = [];
savedHtmls = [];
blockMessageShown = 0;
lockContext = false;
stopChecking = false;
transparentOverlayId = 0;
foundAuthenticatableElement = false;
foundRestrictedElement = false;
aggressiveHeuristic = true;
autologin_seconds = 3;
stopLogin = false;
showLogs = false;
showBypassCloseButton = false;

/* Add the login page URL */
internalAppsWithHack = {
    'eb_vsphere1': 'https://10.100.255.115/vsphere-client',
    'eb_vsphere2': 'https://10.100.255.115/vsphere-client/?csp',
    'eb_tuckervcenter': 'https://tuckervcenter.enterprisebank.com/websso/SAML2/SSO',
    'impoc.dimex': 'http://10.10.231.72:6061/frmLogin.aspx',
    'zoom.us': 'https://zoom.us/signin',
    'microsoftonline': 'https://login.microsoftonline.com/',
    'live': 'https://login.live.com',
    'account.box.com': 'https://account.box.com/login',
    'box': 'https://app.box.com/login',
    'airbnb': 'https://www.airbnb.com/login',
    'preview.athenahealth.com': 'https://preview.athenahealth.com/.*/.*/login.esp',
    'athenanet.athenahealth.com': 'https://athenanet.athenahealth.com/.*/.*/login.esp',
    'onelogin': 'https://.*.onelogin.com/login2/*',
    'okta': 'https://flexport.okta.com',
    'credentialsmart': 'https://www.credentialsmart.net/(CredSmart/login.jsp|CredSmart/servlet/LoginController|telenutrition)',
    'whitefishcu_ss': 'https://whitefishcu.secretservercloud.com/login.aspx.*',
    //'exvm-corp-epo:8443': 'https://exvm-corp-epo:8443/.*',
    '192.168.247.1': 'https://192.168.247.1/login', // Extra.com Fortgate
    '192.168.49.129:11880': 'http://192.168.49.129:11880/settings/login',  // Extra.com SFTP
    'jumpcloud': 'https://console.jumpcloud.com/login'
};


if (!Date.now) {
    Date.now = function now() {
        return new Date().getTime();
    };
}

function OnionIDLog(message) {
    var callerStack = '';
    try {
        callerStack = (new Error()).stack.toString().split(/\r\n|\n/)[2].split('/').pop();  // TODO: Find caller line no in a portable way
    } catch (err) {
        console.error("Js exeception: Couldn't get callerStack value while logging.");
        console.log(err.stack);
    }

    try {
        chrome.storage.sync.get("showLogs", function (obj) {
            if (obj.showLogs || showLogs)
                console.log(`[${callerStack}] ` + JSON.stringify(message));
        });
    } catch (err) {
        console.error("Js exeception: Unable to fetch showLogs settings.");
        console.log(err.stack);
    }
}

//Function to prevent unwanted appearance of OnionId form
function customUrlFilters () {
    // TODO: Update currentUrl or replace with window.href to handle url change via history.pushState
    if(currentUrl == "https://github.com/" || currentUrl == "https://www.acronis.com/en-us/my/profile/" ||
        currentUrl.indexOf("https://www.linkedin.com/fetch")>-1 || currentUrl.indexOf("https://www.creditkarma.com/myprofile/security") > -1 ||
        currentUrl.indexOf("https://www.creditkarma.com/registration/creditsignup/need_score") > -1 || currentUrl.indexOf("https://admin.google.com") > -1 ||
        currentUrl == "https://panel.onionid.com/dashboard/password" || currentUrl.match(new RegExp(/https\:\/\/panel.onionid.com\/password\/reset\/([a-zA-Z0-9]*)/g)) ||
        currentUrl.match(new RegExp(/https\:\/\/dash.cloudflare.com\/(?!login)/g)) || currentUrl.indexOf("https://www.cloudflare.com") > -1 ||
        currentUrl.indexOf("https://zoom.us/profile") > -1 || 
        (currentUrl.indexOf("https://www.airbnb") > -1 && $('input#phoneNumber').length)  // Exclude phone based login for Airbnb
        || /.+dashboard\/server\/.+\/username\/.+\/provision/.test(currentUrl)  // Exclude AD server user provision pass reset page. OG-679
        || window.location.href.indexOf("https://console.jumpcloud.com/totp") > -1    // Exclude JumpCloud login TOTP page from BE autologin popup. OG-692. 
        || window.location.href.indexOf("https://console.jumpcloud.com/login?template=loginMFA") > -1    // Exclude JumpCloud Administrator login OTP page from BE autologin popup. OG-692.
        || window.location.href.indexOf("https://console.jumpcloud.com/login?template=resetUserPassword") > -1  // Exclude pass reset page from popup 
        || window.location.href.indexOf("https://console.jumpcloud.com/login?context=sso") > -1    // Exclude app login via JumpCloud SSO option
        || currentUrl.indexOf("https://192.168.247.1/logindisclaimer") > -1 // Extra.com Fortigate disclamer page
        || (currentUrl.indexOf("https://flexport.okta.com") > -1 && !$('input#okta-signin-username').length)  // Exclude non login pages of flexport okta
    )
        return true;
    else
        return false;
}

function customHtmlFilters () {
    if($('.signupFirstStep').size()>0)
        return true;

    // Skip autologin in case of Jumpcloud User Portal login page. OG-628, OG-740
    if ($('.UserLogin__container').length || $('.SsoLogin__formContainer').length || $('form[action="/userconsole/auth"]').length)
        return true;

    // Skip autologin for Airbnb using phone no. OG-661
    if ($('input#phoneNumber').length || $('input#phone-login-phone-number').length)
        return true;
}

/**
 * Get the appname if app is among internal apps which needs hacks
 *
 * @param {String} requestUrl
 * @returns {String}
 */
function getInternalAppNameHack(requestUrl) {
    var decodedUrl = decodeURI(requestUrl);
    var siteIdentifier = '';
    $.each(internalAppsWithHack, function (identifier, url) {
        var regex = new RegExp(`^${url}`);
        //if (decodedUrl.indexOf(url) > -1) {
        if (regex.test(decodedUrl)) {
            siteIdentifier = identifier;
        }
    });
    OnionIDLog(`getInternalAppNameHack(${requestUrl}) -> ${siteIdentifier}`);  // TODO: [Un]comment for debugging.
    return siteIdentifier;
}




/*
** the hostedcafe app is for the Netdefend/accelops application
** the url is: https://health.hostedcafe.com/phoenix/login.jsf
** (for the same app and login form but in html th url is
**  https://health.hostedcafe.com/phoenix/login-html.jsf)
** customer: enterprise bank
** implementation expicitly asked from Anirban
** the login page for this app has 4 fields in the login form.
** The last field domain is usually left empty and the 3rd field is text like Enterprisebank
** the username and password fields are what are primarily used
** we check the url and not the app to prevent onionid BE login popup after login
** because the url after the login is https://health.hostedcafe.com/phoenix/login.jsf#
** whick been translated to the same app hostedcafe
**TODO:
** The right way whould be to explicitly allow the specific login form of that page not the url
*/
function formExistHacks() {
  if(findApp(currentUrl) == "brand-spot"
    || currentUrl == "https://health.hostedcafe.com/phoenix/login.jsf"
    || currentUrl == "https://health.hostedcafe.com/phoenix/login-html.jsf"
    || currentUrl == "https://health.dev.hostedcafe.com/phoenix/login.jsf"
    || currentUrl == "https://health.dev.hostedcafe.com/phoenix/login-html.jsf"
    || currentUrl == "https://health-dev.hostedcafe.com/phoenix/login.jsf"
    || currentUrl == "https://health-dev.hostedcafe.com/phoenix/login-html.jsf"
    || currentUrl.indexOf("https://accounts.google.com/signin") > -1
    || currentUrl.indexOf("https://accounts.google.com/ServiceLogin") > -1
    || getInternalAppNameHack(currentUrl) != '') {

        return true;
    }
    return false;
}

function relevantFormExists() {
    var form_found;
    $('input[type=password]').each(function() {
        form_length = $(this).closest("form").find("input[type=text]:visible, input[type=email]:visible, input[type=password]:visible").length;
        if($(this).is(":visible") && form_length <= 3 && form_length >= 1) {
            OnionIDLog("Found proper login form");
            form_found = true;
        }
    });
    if(formExistHacks()) {
        form_found = true;
    }
    return form_found;
}
//Euristic for login form recognition
function login_found() {
    if(relevantFormExists() && !customUrlFilters() && !customHtmlFilters()) {
        OnionIDLog("login_found() - Found Login form.");
        return true;
    }
    else {
        OnionIDLog("Didn't find login form: " + currentUrl);  // TODO: [Un]comment to debug
        return false;
    }
}

//Same euristic for login form recognition but ignore the OID form
function login_found_register() {
    if($('input[type=password]').size()>0 && $('input[type=password]').is(":visible") && $('input[type=password]').attr("id")!="onionIDpassword" && $('input[type=password]').attr("id") != "onionIdOTP" && !customUrlFilters() && !customHtmlFilters()) {
        OnionIDLog("Found Login form");
        return true;
    }
    else {
        OnionIDLog("Didn't find login form");
        return false;
    }
}
function login_found_hack() {
    if ((currentUrl.indexOf("https://secure.lifelock.com/portal/login/") > -1) || (currentUrl.indexOf("https://vpn.zipongo.com") > -1)) {
        return true;
    }
    else {
        return false;
    }
}


function addBypassButton () {

    // Eable bypass-close button if Development Mode is set.
    chrome.storage.local.get("general_development_mode", function (obj) {

        // Check if popup is not auth related popup or if Development Mode is set.
        if ((!jQuery.isEmptyObject(obj) && obj.general_development_mode == "true") ||
                (!$('#onionID_application_popup').length && !$('#onionID_policy_popup').length && 
                 !$('#onionID_masterpass_popup').length  && !$('#onionID_masterpass_update_popup').length && !$('#onionID_credentials_popup').length
                 && !$('#onionID_otp_popup').length)
           ) {
            OnionIDLog("Development Mode set. Enabling bypass-close button.");

            // Only for cloudflare (application and policy popups only contain the div, other have img itself)
            if (findApp(currentUrl) == 'cloudflare' && $('div.onionIDBypass').length) {
                addSvgImageCode('onionID_logo');
                addSvgImageCode('onionIDBypass');
            } else {
                $('.onionIDBypass').css("display", "block");
                $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
            }

            $('.onionIDBypass').on('click', function () {
                event.stopPropagation();
                removePopups();
                stop=true;
                bypassRequest =  {
                    "url": currentUrl,
                    "sdcode": sdcode,
                    "full_domain": window.location.host,
                    "type": "Chrome Bypass"
                };
                $.ajax({
                    type: "POST",
                    url: theServer,
                    dataType: "json",
                    data: JSON.stringify(bypassRequest),
                    context: document.body
                })
            });
        } else {
            $('.onionIDBypass').css("display", "none");
        }
    });
}


function removePopups() {
    $('#onionID_application_popup').remove();
    $('#onionID_register_popup').remove();
    $('#onionID_register_pin_popup').remove();
    $('#onionID_top_bar').remove();
    $('#onionID_top_error_bar').remove();
    $('#onionID_top_block_bar').remove();
    $('#onionID_credentials_popup').remove();
    $('#onionID_masterpass_popup').remove();
    $('#onionID_policy_popup').remove();
    $('#onionID_overlay').remove();
    $('#onionID_masterpass_update_popup').remove();
    $('#onionID_masterpass_update_email').remove();
    $('#onionID_element_save_popup').remove();
    $('#onionID_access_request_popup').remove();
    $('#onionID_otp_popup').remove();
    lockContext = false;
}

/// BEGIN ACCESS REQUEST FUNCTIONS ///

function showRequestAccessBar(message) {
    // Check if the bar is already there (the blocked element check restarts when windows becomes active after an interval of inactive state)
    if ($('#onionID_top_block_bar_message').length) {
        return;
    }
    $.get(chrome.extension.getURL('html/onionid-top-access-request-banner.html'), function(result) {
        $('body').append(result);
        $('#onionID_top_block_bar_message').html(message);
        OnionIDLog("It works");
        addBypassButton();
        $('#onionID_top_block_bar').click(function() {
                removePopups();
                showRequestAccessPopup();
        });
    });
}

function showRequestAccessPopup() {
    removePopups();
    $.get(chrome.extension.getURL('html/onionid-access-request-popup.html'), function(result) {
        $('body').append(result);
        OnionIDLog("It works");
        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        addBypassButton();
        $('#onionSubmitReason').click(function() {
            theReason = $('#onionIDaccessReason').val();
            $('#onionID_access_request_popup').remove();
            sendAccessRequestToServer(theReason);
            lockContext = false;
        });
    });
}

function sendAccessRequestToServer(theReason) {
     var tempAccessType = "element" ;
     var tempCurrentUrl = currentUrl ;
     if (typeof(banElement) != 'undefined' && banElement != null){
       tempAccessType = "url" ;
       chrome.storage.local.get(['saveBanned'], function(result) {
         tempCurrentUrl = result.saveBanned;
         accessRequest =  {
                "url": tempCurrentUrl,
                "reason": theReason,
                "full_domain": window.location.host,
                "sdcode": sdcode,
                "access_type": tempAccessType,
                "type": "Browser Request Resource Access"
        };

        $.ajax({
            type: "POST",
            url: theServer,
            dataType: "json",
            data: JSON.stringify(accessRequest),
            context: document.body
        });
       });
     }
     else{
       accessRequest =  {
              "url": tempCurrentUrl,
              "reason": theReason,
              "full_domain": window.location.host,
              "sdcode": sdcode,
              "access_type": tempAccessType,
              "type": "Browser Request Resource Access"
      };

      $.ajax({
          type: "POST",
          url: theServer,
          dataType: "json",
          data: JSON.stringify(accessRequest),
          context: document.body
      });
     }
}

/// END ACCESS REQUEST FUNCTIONS ///

//Attempt to authenticate with Request in Timeout intervals
function authenticateAttempt(timeout, request, special_url, autologin, accounts, blockedElement) {
    request.account = account;
    attempts_count++;
    setTimeout(
        function() {
            if (!stop && !stopLogin) {
                $.ajax({
                    type: "POST",
                    url: theServer,
                    dataType: "json",
                    data: JSON.stringify(request),
                    context: document.body,
                    timeout: globalTimeout,
                    success: function (response) {

                        if(response.extra) {
                            extraAuthenticationField = response.extra;
                        }

                        if(response.extra2) {
                            extraAuthenticationField2 = response.extra2;
                            OnionIDLog("The extra auth field 2" + extraAuthenticationField2);
                        }

                        if (response.status != "Waiting for Authentication" && blockedElement) {
                            authenticateElements();
                            return;
                        }

                        if (response.message == "register") {
                            showRegisterForm();
                            stop = true;
                        }
                        else if (response.status == "Waiting for Authentication") {
                            if(attempts_count == kill_popup_limit) {
                                    stop = true;
                                    //removePopups();   // Disable timeout of popup as part of disabling bypass
                            }

                            authenticateAttempt(timeout, request, special_url, autologin, accounts, blockedElement)
                        }
                        else if (response.message == "canceled") {
                            OnionIDLog('canceled');
                            removePopups();
                        }
                        else if (response.status == "pingid_otp") {
                            
                            // Device is unreachable, provide the OTP entry option
                            showOTPPopup('PingId OTP', response.message, accounts, blockedElement);
                            OnionIDLog('Device unreachable, showing PingID OTP popup for login attempt: ' + response.message);
                        }
                        else if (response.status == "pingid_error" || response.status == "okta_error" || response.status == "duo_error") {
                            var custom_messages = {};
                            if (response.status == "pingid_error") {
                                custom_messages = {
                                    'propertiesmissing': 'Ping ID Integration Details are missing. Please contact your Thycotic Access Controller administrator to update the Ping ID properties and try again.',
                                    'duplicate': 'You have another pending authentication request. Please wait for a few minutes before trying again.',
                                    'timeout': 'Authentication request has timed out. This may be due to Firewall Blocks or Network Disruption.',
                                    'notfound': 'Your Ping ID account has not been found. Please contact your Thycotic Access Controller administrator.',
                                    'suspended': 'Your PingID account has been suspended. Please contact your IT administrator.',
                                    'pushdisabled': 'Device push notification is disabled.',
                                    'deviceinvalid': 'Your device is invalid.',
                                    'orgerror': 'Something went wrong. Please contact your IT administrator.',
                                    'nodevice': 'Please install PingID app on your mobile and pair with your account.',
                                    'appnotprimary': 'Please install PingID app on your mobile and set it as the primary device paired with your account.',
                                    'nil': 'Something went wrong. Please try again.'
                                };
                            } else if (response.status == "okta_error") {
                                custom_messages = {
                                    "CANCELLED": "The Factor verification was cancelled by the user.",
                                    "CHALLENGE": "Another verification is required. Please try again.",
                                    "ERROR": "An unexpected server error occurred while verifying the Factor. Please try again.",
                                    "FAILED": "The Factor verification failed. Please try again.",
                                    "PASSCODE_REPLAYED": "The Factor was previously verified within the same time window. Please try again.",
                                    "TIME_WINDOW_EXCEEDED": "The Factor was successfully verified, but outside of the computed time window. Please try again.",
                                    "SETTINGS_NOT_FOUND": "OKTA Integration Details are missing. Please contact your Thycotic Access Controller administrator to update the OKTA properties and try again.",
                                    "FACTOR_NOT_FOUND": "The specific OKTA authentication factor is not active.",
                                    "USER_NOT_FOUND": "OKTA user not found.",
                                };
                            } else if (response.status == "duo_error") {
                                // 'no_user_error' is handled separately
                                custom_messages = {
                                    'internal_error': 'Something went wrong. Please contact your Thycotic Access Controller administrator.',
                                    'integration_disabled_error': 'Duo Integration is not setup. Please contact your Thycotic Access Controller administrator to add the Duo settings and try again.',
                                    'integration_invalid_error': 'Duo Integration Details are invalid. Please contact your Thycotic Access Controller administrator to update the Duo settings and try again.',
                                    'integration_missing_error': 'Duo Integration Details are missing. Please contact your Thycotic Access Controller administrator to update the Duo settings and try again.',
                                    'invalid_user_error': 'Invalid Duo user account. Please contact your Duo administrator to verify your account.',
                                    'push_not_enabled_error': 'Push authentication is not enabled for Duo user.',
                                    'invalid_attempt_error': 'Invalid Duo account status. Please contact your Duo administrator to verify your account.',
                                    'invalid_api_response_error': 'Failed to process the request. Please contact your Thycotic Access Controller administrator.',
                                };
                            }

                            var error_message = 'Something went wrong. Please try again.';
                            if (response.message in custom_messages) {
                                error_message = custom_messages[response.message];
                            }

                            // User should add/upload a Duo username. Not allowing fallback if username is not uploaded for duo
                            if (response.status == "duo_error" && response.message == 'no_user_error') {
                                chrome.storage.sync.get("endpoint", function (obj) {
                                    let theUrl = (obj.endpoint).replace(/:[0-9]{2,4}\/?$/, '') + "/user/duo_username";
                                    console.log("Duo username upload URL: " + theUrl)
                                    onionIdSystemMessage('Your Duo username is not found. Please upload your Duo username <a href="' + theUrl + '" target="_blank">here</a>');
                                    return true;
                                });
                            } else {
                                // Set fallback in 5 seconds, if fallback is enabled
                                if (fallback && fallback_seconds && fallback_limit && (fallback_limit - fallback_seconds > 0)) {
                                    fallback_seconds = fallback_limit - 5;
                                    error_message += " Fallback in 5 seconds.";
                                }

                                onionIdSystemMessage(error_message);
                                OnionIDLog('Error: ' + response.message);
                            }
                        }
                        else if (response.status == "okta_totp") {

                            // Push timeout, provide the OTP entry option
                            showOTPPopup('OKTA TOTP', response.message, accounts, blockedElement);
                            OnionIDLog("OKTA push didn't succeed, showing OKTA OTP popup for login attempt: " + response.message);
                        }
                        else if(!masterpass) {
                          if(action==1) {
                                if(!special_url) {
                                    stop = true;
                                    OnionIDLog(response);
                                    if (findApp(currentUrl).indexOf("hostedcafe") > -1 && findApp(currentUrl).indexOf("servicedesk") == -1) {
                                      //from version 2.9.5 every hosted cafe registration require 4 field
                                      //but we also support login with three because of customer who
                                      //are already registered
                                      //exclude the servicedesk hosted cafe because it has a regural login form
                                      if (response.extra2 == null) {
                                          do_login(response.username, response.password, response.extra);
                                      }
                                      else {
                                        do_login(response.username, response.password, response.extra, response.extra2);
                                      }
                                    }
                                    else {
                                      do_login(response.username, response.password);
                                    }
                                    setTimeout(function() {removePopups();}, 2000);
                                }
                                else {
                                    stop = true;
                                    OnionIDLog("Lets remove popups special url!!!");
                                    removePopups();
                                    window.location.href = currentUrl;
                                }
                            }
                            else if (action==2) {
                                showRegisterForm();
                            }
                            else if (action==3) {
                                showRegisterForm("wrong");
                            }
                            else if (action==4) {
                                deleteAccount();
                            }
                            //OnionIDLog(response);
                        }
                        else {
                           showMasterPassPopup(response.username, response.password);
                        }
                    },
                    error: function(x, t, m) {
                        if (t === "timeout") {
                            authenticateAttempt(timeout, request, false, accounts, blockedElement);
                            OnionIDLog("Auth Attempt Timeout!");
                        } else {
                        }
                    }
                })
            }
        }, timeout
    );
}

function form_find_hacks() {
    //hack for acronis
    if(findApp(currentUrl) == "acronis") {
        loginForm = $('form[name=form]');
    } else if (findApp(currentUrl) == "ecwid") { //hack for ecwid
        loginForm = $('form[action="/cp/login"]');
    } else if (findApp(currentUrl) == "brand-spot") { //hack for cordeo
        loginForm = $('.login-form');
    } else if (findApp(currentUrl) == "tenable") {
        loginForm = $('input[placeholder=Password]').closest('form');
    }
}


function find_form() {
    //Euristic to find if a form is a login one. Mostly discard signup forms. Should ultimately use number of fields.
    $('input[type=password]').closest('form').each(function (candidateForm) {
        if($(this).html().toLowerCase().indexOf("signup") < 0 && $(this).html().toLowerCase().indexOf("registration") < 0 &&
            $(this).attr("id") != "onionRegister" &&
            $(this).attr("id") != "onionOTPForm" && $(this).attr("name") != "reg"){
            loginForm = $(this);
        }
    });

    //If ideal form not found fallback to an option to do login
    if (loginForm == "") {
        loginForm = $('input[type=password]').closest('form');
    }

    //OnionIDLog(loginForm);
    //Or use custom detection for specific application
    form_find_hacks();
}

function username_field_hacks() {

    //hack for a specific dropbox page
    if( currentUrl.indexOf("https://www.dropbox.com/login") >= 0 ) {
        usernameField = loginForm.find('input[name=login_email]');
    } else if (currentUrl.indexOf("https://103.86.25.52/") >= 0 ) {
        usernameField = loginForm.find('input#username');
    } else if (findApp(currentUrl) === "tenable") {
        usernameField = loginForm.find('input[data-name=username]');
    }
}

function password_field_hacks(password) {
    if(findApp(currentUrl) == 'goclio') {
        passwordField.blur();
    }

    if(findApp(currentUrl) == 'hbr') {
        setTimeout(function() {
            $('input[type=password]').val(password);
        },2000);
    }

}

function app_requires_specific_login_process() {
    if(findApp(currentUrl) == 'pinterest' || findApp(currentUrl) == 'rackspace') {
        return true;
    }
    else {
        return false;
    }
}

function specific_login_process(username, password) {
    if(findApp(currentUrl) == 'pinterest' || findApp(currentUrl) == 'rackspace') {
        let event2 = new Event('input', { bubbles: true });
        usernameField[0].dispatchEvent(event2);
        passwordField.val(password);
        let event = new Event('input', { bubbles: true });
        passwordField[0].dispatchEvent(event);
        get_submit_button();
        submit_form();
    }
}

function submit_button_hacks() {
    //Pinterest hack
    if(findApp(currentUrl) == "pinterest") {
        submitButton.removeAttr('disabled');
        submitButton.removeClass('disabled');
    }

    if(findApp(currentUrl) == "mcafee") {
        submitButton = $('input[name=btnLogin]');
    }

    if( currentUrl.indexOf("oauth") >= 0 && findApp(currentUrl) == "twitter" ) {
        submitButton = $('#allow');
    }

    //TODO: Make global
    if( currentUrl.indexOf("/guacamole") >= 0) {
        submitButton = loginForm.find('[type=submit]:visible');
    }


}

function login_to_acronis(username, password) {
    if(findApp(currentUrl) == "acronis") {
        OnionIDLog("login to acronis");
        usernameField = $('input[name="email"]');
        usernameField.val(username);
        //OnionIDLog(usernameField);
        usernameField.trigger('input');
        passwordField = $('input[name="password"]');
        passwordField.val(password);
        passwordField.trigger('input');
    }
}

function fire_input_events() {
    try {
        var event; // The custom event that will be created

        if (document.createEvent) {
            event = document.createEvent("HTMLEvents");
            event.initEvent("input", true, true);
        } else {
            event = document.createEventObject();
            event.eventType = "input";
        }

        event.input = "input";
        if(usernameField[0]) {
            if (document.createEvent) {
                usernameField[0].dispatchEvent(event);
            } else {
                usernameField[0].fireEvent("on" + event.eventType, event);
            }
        }

        if(passwordField[0]) {
            if (document.createEvent) {
                passwordField[0].dispatchEvent(event);
            } else {
                passwordField[0].fireEvent("on" + event.eventType, event);
            }
        }
    } catch (e) { OnionIDLog(e.message); }
}

function appNeedsTimeout() {
    if(findApp(currentUrl) == "eventbrite" || findApp(currentUrl) == "hbr") {
        OnionIDLog("APP NEEDS TIMEOUT");
        return true;
    }
    else {
        return false;
    }
}

function fire_all_events() {
    try {
        usernameField.trigger('input');
        usernameField.focus();
        usernameField.blur();
        passwordField.focus();
        passwordField.blur();
        passwordField.trigger('input');
    } catch (e) { OnionIDLog(e.message); }
}

function find_input_fields(username, password) {
    usernameField = loginForm.find('input[type=text]');

    // Avoid account name being updated by BE, fetch the username field
    if(findApp(currentUrl) == "amazon") {
        usernameField = loginForm.find('input[type=text][name=username]');
    }

    if(usernameField.length==0) {
        usernameField = loginForm.find('input[type=email]');
    }
    if(usernameField.length==0) {
        usernameField = loginForm.find('input[name=email]');
    }
    if(usernameField.length==0) {
        usernameField = loginForm.find('input[name=username]');
    }

    username_field_hacks();

    usernameField.val(username);

    passwordField = loginForm.find('input[type=password]');

    // Custom hack for core.flexport.com app. OG-700
    if (findApp(currentUrl) == "flexport") {
        OnionIDLog('Setting custom passwordField for Flexport.');
        passwordField.clone().attr("id", 'newPassField').attr("value", password).appendTo('form[action="/users/sign_in"]');
        passwordField.remove();
    } else {
        if (passwordField.length > 1) {
            passwordField = loginForm.find('input[type=password]:visible');
            OnionIDLog("Filtering the visible field");
            OnionIDLog(passwordField);
        }
        password_field_hacks(password);
        passwordField.val(password);
    }

    if(app_requires_specific_login_process()) {
        specific_login_process(username, password);
        return;
    }

    fire_all_events();
    fire_input_events();

    //remove disabled attributes
    $(":disabled").removeAttr("disabled");

    //Try with input type submit

    get_submit_button();

    //OnionIDLog(submitButton.value);
    //OnionIDLog(submitButton);

    submit_button_hacks();
}


function get_submit_button() {
     submitButton = loginForm.find('[type=submit]');

    //Try with input type button
    if(submitButton.length==0) {
        submitButton = loginForm.find('[type=button]');
    }

    //Try with button html tag
    if(submitButton.length==0) {
        submitButton = loginForm.find('button');
    }

     //Try with role button
    if(submitButton.length==0) {
        submitButton = loginForm.find('[role=button]');
    }
    //Try with input type image
    if(submitButton.length==0) {
        submitButton = loginForm.find('[type=image]');
    }

    //Try with a html tag
    if(submitButton.length==0) {
        OnionIDLog("Getting desperate. Trying to find a relevant a tag.");
        submitIsATag = true;
        loginForm.find('a').each (function (candidateButton) {
            OnionIDLog("Found an a candidate");
            OnionIDLog($(this));
            if($(this).html().toLowerCase().indexOf("submit") >= 0 || $(this).html().toLowerCase().indexOf("sign") >= 0) {
                submitButton = $(this);
                OnionIDLog("Picked this (html)");
                return false;
            }
            else if($(this).attr("class")) {
                if($(this).attr("class").toLowerCase().indexOf("submit") >= 0 || $(this).attr("class").toLowerCase().indexOf("sign") >= 0) {
                    submitButton = $(this);
                    OnionIDLog("Picked this (class)");
                }
            }
            else if($(this).attr("id")) {
                if($(this).attr("id").toLowerCase().indexOf("submit") >= 0 || $(this).attr("id").toLowerCase().indexOf("sign") >= 0) {
                    submitButton = $(this);
                    OnionIDLog("Picked this (id)");
                }
            }
        });
    }
}

function submit_form_hacks() {
    if(findApp(currentUrl) == "yahoo") {
        setTimeout(function() {
            jQuery('#login-signin').click();
        }, 2000);

        setTimeout(function() {
            jQuery('#login-signin').click();
        }, 4000);

        setTimeout(function() {
            jQuery('#login-signin').click();
        }, 6000);
    }
}

function submit_form() {

    OnionIDLog("The submit button...");

    OnionIDLog(submitButton);

   submit_form_hacks();

   if(findApp(currentUrl) == "citrix") {
        OnionIDLog(jQuery('#pp-login-submit')[0]);
        jQuery('#pp-login-submit')[0].click();
    }
    else {
        OnionIDLog("SUBMIT BUTTON IS: ");
        OnionIDLog(submitButton);

        if (!submitIsATag)
            submitButton.click();
        else{
            window.location.href = submitButton.attr("href");
            submitButton[0].click();
        }
        OnionIDLog('After login submitButton click()');
        
        if (findApp(currentUrl) == "linkedin")
            loginForm.submit();

        if (findApp(currentUrl) == "asana")
            $('#submit_button').click();
    }
}


function login_to_trello(username, password) {

    OnionIDLog('special for trello');
    $('#user').val(username);
    $('#password').val(password);
    $('#login').click();

}

function login_to_forti(username, password) {

    OnionIDLog('special for forti');
    $('#username').val(username);
    $('#password').val(password);
    $('#login_button').click();

}

function login_to_vpn_zipongo(username, password) {

    OnionIDLog('vpn zipongo');
    $('#username').val(username);
    $('#secretkey').val(password);
    $('#go').click();

}


function login_to_hostedcafe(username, password, extra, extra2) {
    extra=extra.split('>');
    if (extra.length > 1) {
      extra=extra[extra.length -1];
    }
    else {
      extra=extra[0];
    }
    extra2=extra2.split('>');
    if (extra2.length > 1) {
      extra2=extra2[extra2.length -1];
    }
    else {
      extra2=extra2[0];
    }
    OnionIDLog('special for hostedcafe');
    $("input[id*='login:username']").val(username);
    $("input[id*='login:password']").val(password);
    $("input[id*='login:domain']").val(extra);
    $("input[id*='login:userDomainText']").val(extra2);
    $("input[id*='login:login']").click();
}

function login_to_hostedcafe_html(username, password, extra, extra2) {
    extra=extra.split('>');
    if (extra.length > 1) {
      extra=extra[extra.length -1];
    }
    else {
      extra=extra[0];
    }
    extra2=extra2.split('>');
    if (extra2.length > 1) {
      extra2=extra2[extra2.length -1];
    }
    else {
      extra2=extra2[0];
    }
    OnionIDLog('special for hostedcafe (html)');
    $("input[id*='loginHtml:username']").val(username);
    $("input[id*='loginHtml:password']").val(password);
    $("input[id*='loginHtml:domain']").val(extra);
    if (currentUrl == "https://health-dev.hostedcafe.com/phoenix/login-html.jsf") {
      // for the -dev on intervison the 4th field is a select not an input element.
      //For now just let the default selection (local with value empty) and dont enything
      //if more option will be addes in the future we must fill that filed too.
    }
    else {
      $("input[id*='loginHtml:userDomain']").val(extra2);
    }
    $("input[id*='loginHtml:loginBtn']").click();
}

function login_to_cloudflare(username, password) {

    OnionIDLog('special for cloudflare');
    $('input[name=email]').val(username);
    $('input[name=password]').val(password);
    $('button[data-testid=login-button]').click();
}

/**
 * Custom login for Instagram accounts
 *
 * @param {String} username
 * @param {String} password
 * @returns {Boolean}
 */


function login_to_instagram(username, password)
{   loginForm = $('#loginForm');

    usernameField = loginForm.find('input[name=username]');
    usernameField.click();
    usernameField.val(username);
    fire_input_events();

    passwordField = loginForm.find('input[name=password]');
    passwordField.click();
    passwordField.val(password);
    fire_input_events();

    setTimeout(function () {
    passwordField.val(password);
    fire_input_events();
    submitButton = $('#loginForm button[type="submit"]')
    submitButton.click();
    submit_form();
    }, 1000);
}

/**
 * Custom login for Godaddy accounts
 *
 * @param {String} username
 * @param {String} password
 * @returns {Boolean}
 */



function login_to_godaddy(username, password) {
    OnionIDLog('custom login for godaddy');    loginForm = $('#login-panel');
    usernameField = loginForm.find('input[type=username]');
    passwordField = loginForm.find('input[type=password]');
    submitButton = loginForm.find('[type=button]');    if (usernameField.length == 0) {
        usernameField = $('#username');
    }    if (passwordField.length == 0) {
        passwordField = $('#password');
    }    if (submitButton.length == 0) {
        submitButton = $('#submitBtn');
    }    usernameField.val(username);
    fire_input_events();    // Add some delay, to allow ajax calls on changing username field
    setTimeout(function () {
        passwordField.val(password);
        fire_input_events();
        submit_form();
    }, 1000);    return;
}


/**
 * Custom login for google accounts
 *
 * @param {String} username
 * @param {String} password
 * @returns {Boolean}
 */
function login_to_google(username, password) {
    OnionIDLog('Special for google');

    // If username field is available (either new entry field or pre-filled hidden field)
    if ($('input[name=identifier]').length) {
        var usernameField = $('input[name=identifier]');

        // If the email field is hidden and autofilled with gmail cookie
        if ($(usernameField).attr('id') == 'hiddenEmail') {

            // If the autofilled one is the username we have, then proceed to submit
            if ($(usernameField).val() == username) {

                // The password field will be available in this case, so proceed to submit password form and return
                return google_pass_form_submit(password);
            } else {

                // Get back to the account list
                $('#profileIdentifier').click();

                // Choose our account from the list which appears on click
                setTimeout(function () {
                    return google_choose_account_from_list(username, password);
                }, 1000);
            }
        } else if ($(usernameField).val() == '') {

            // If the username field is visible and empty, then fill with the username we have and proceed to login
            return google_login_form_submit(username, password);
        }

    } else {
        // When user has multiple accounts, the account list page is displayed initially
        return google_choose_account_from_list(username, password);
    }

    return false;
}

/**
 * Choose specific account form the accounts list and login
 *
 * @param {String} username
 * @param {String} password
 * @returns {Boolean}
 */
function google_choose_account_from_list(username, password) {

    // If the list is not found, then return
    if (!$('form ul li').length) {
        return;
    }

    OnionIDLog('Handling choosing/adding account, if google accounts list is displayed.');

    var addAccountElement = false;
    var myAccountElement = false;

    $.each($('form ul li'), function (index, li) {
        var identifierElement = $(li).find('#profileIdentifier');

        // If it's and an account name item
        if (identifierElement.length) {

            // Fetch our email id element if it is available in the list
            if ($(identifierElement).attr('data-email') == username) {
                myAccountElement = identifierElement;
            }
        } else {
            var item = $(li).find('div:last');

            // Ge the new account add link
            if ($(li).find('div:last').text() == 'Use another account') {
                addAccountElement = item;
            }
        }
    });

    // If our account name is found, choose it and proceed to login
    if (myAccountElement !== false) {

        // Click on the username to choose it
        $(myAccountElement).click();

        // Password field appears after choosing username field, submit it and return
        setTimeout(function () {
            return google_pass_form_submit(password);
        }, 1000);

    } else if (addAccountElement !== false) {

        // If the new account add link is located, proceed to add new account form and then login
        $(addAccountElement).click();
        return google_login_form_submit(username, password);
    }
    return true;
}

/**
 * Fill and submit google login form
 *
 * @param {String} username
 * @param {String} password
 * @param {Integer} fieldCheck
 * @returns {Boolean}
 */
function google_login_form_submit(username, password, fieldCheck) {
    OnionIDLog('Handling google username form');

    // This variable is not provided on initial call from other functions
    if (isNaN(fieldCheck)) {
        fieldCheck = 1;
    } else {
        fieldCheck++;
    }

    // Confirm that username field exists, as it appears after clicking the add account link or clicking a username from list (if the account list is displayed first)
    if ($('input[name=identifier]').length) {
        $('input[name=identifier]').val(username);
        $('#identifierNext').click();
        return google_pass_form_submit(password);
    } else if (fieldCheck < 15) {

        // Try 15 times. Around 15 seconds considering slow speed connections
        setTimeout(function () {
            return google_login_form_submit(username, password, fieldCheck);
        }, 1000);
    }
}

/**
 * Fill and submit google password field form
 *
 * @param {String} password
 * @param {Integer} fieldCheck
 * @returns {Boolean}
 */
function google_pass_form_submit(password, fieldCheck) {
    OnionIDLog('Handling google password form');

    // This variable is not provided on initial call from other functions
    if (isNaN(fieldCheck)) {
        fieldCheck = 1;
    } else {
        fieldCheck++;
    }

    // Confirm that password field exists, as it appears after submitting and verifying username
    if ($('input[name=password]').length) {
        $('input[name=password]').val(password);

        if (!$('#passwordNext').length && fieldCheck < 15)
            setTimeout(() => google_pass_form_submit(password, fieldCheck), 200);

        $('#passwordNext').click();

        // Focus on password field again to avoid placeholder text being displayed
        $('input[name=password]').focus();
        removePopups();
        return true;
    } else if (fieldCheck < 15) {

        // Try 15 times. Around 15 seconds considering slow speed connections
        setTimeout(function () {
            return google_pass_form_submit(password, fieldCheck);
        }, 1000);
    }
}

/**
 * Special login actions for internal applications which does not have normal login form
 *
 * @param {string} username
 * @param {string} password
 * @param {string} app
 * @returns {Boolean}
 */
function login_to_internal_app(username, password, app='', addrUrl='') {
    OnionIDLog(`login_to_internal_app(${username}, ${password}, ${app}, ${addrUrl})`);
    /* Add app specific code */
    switch (app) {
        case 'eb_vsphere1':    // fall-through - eb_vsphere1 OR eb_vsphere2
        case 'eb_vsphere2':
            OnionIDLog('Custom login submission for VMware vCenter (eb_vsphere)');
            usernameField = $('iframe#websso').contents().find('#username');
            passwordField = $('iframe#websso').contents().find('#password');
            submitButton = $('iframe#websso').contents().find('#submit');

            OnionIDLog('iframe#websso login elements -> #username: ' + usernameField.length + ', #password: ' + passwordField.length + ', #submit: ' + submitButton.length);
            
            usernameField.val(username);
            passwordField.val(password);
            submitIsATag = false;

            fire_all_events();
            submit_form();
            return true;
        case 'eb_tuckervcenter':
            OnionIDLog('Custom login submission for Enterprisebank tuckervcenter');

            usernameField = $('#username');
            passwordField = $('#password');
            submitButton = $('#submit');

            OnionIDLog('Tuckervcenter login elements -> #username: ' + usernameField.length + ', #password: ' + passwordField.length + ', #submit: ' + submitButton.length);

            usernameField.val(username);
            passwordField.val(password);
            submitIsATag = false;

            fire_all_events();
            submit_form();
            return true;
        case 'impoc.dimex':
            OnionIDLog("Custom login form submission for Dimex internal app impoc.dimex.");
            usernameField = $('#Login1_UserName');
            passwordField = $('#Login1_Password');
            submitButton = $('#Login1_LoginLinkButton.loginButton');

            usernameField.val(username);
            passwordField.val(password);
            submitIsATag = true;

            fire_all_events();
            submit_form();
            return true;
        case 'zoom.us':
            OnionIDLog('Custom login submission for Zoom.us');

            usernameField = $('#email');
            passwordField = $('#password');
            submitButton = $('#login-form .btn.btn-primary.submit.signin.user');

            OnionIDLog('Zoom.us login elements -> #username: ' + usernameField.length + ', #password: ' + passwordField.length + ', #submit: ' + submitButton.length);

            usernameField.val(username);
            passwordField.val(password);
            submitIsATag = true;

            fire_all_events();
            submit_form();
            return true;

        case 'microsoftonline':
        case 'live':
            OnionIDLog('Custom login submission for login.live.com');

            usernameField = $('input[name ="loginfmt"]');
            submitButton = $('.btn.btn-block.btn-primary');

            OnionIDLog('Login elements -> #username: ' + usernameField.length + ', #submit: ' + submitButton.length);

            // Submit username & pass as two separate page-form submissions
            if (usernameField.length && !window.name) {
                OnionIDLog("Microsoft live: Saving credentials to window.name and submitting email");
                window.name = JSON.stringify({"app": "live", "username": username, "password": password });

                usernameField.val(username);
                usernameField.trigger('input');
                usernameField.focus();
                usernameField.blur();
                submitButton.click();
            }
            var winName = '';
            if (window.name && window.name.indexOf('live') > -1 && findApp(currentUrl).indexOf("live") > -1 ) {
                OnionIDLog("Microsoft Live: Using password from window.name");
                try {
                    winName = JSON.parse(window.name);
                    window.name = '';

                } catch (err) {
                    OnionIDLog("Microsoft live: Unable to access credentials from window.name for submission.");
                    OnionIDLog(err.stack);
                }
            }
            if (typeof password === 'undefined' && winName) {
                password = winName.password;
            }

            setTimeout(function() {
                passwordField = $('input[name ="passwd"]');
                submitButton = $('.btn.btn-block.btn-primary');

                OnionIDLog('Login elements -> #password: ' + passwordField.length + ', #submit: ' + submitButton.length);

                passwordField.val(password);
                passwordField.focus();
                passwordField.blur();
                passwordField.trigger('input');

                submitButton.click();
            }, 1500);

            setTimeout(function() {
                passwordField = $('input[name ="passwd"]');
                submitButton = $('.btn.btn-block.btn-primary');

                OnionIDLog('Login elements -> #password: ' + passwordField.length + ', #submit: ' + submitButton.length);

                passwordField.val(password);
                passwordField.focus();
                passwordField.blur();
                passwordField.trigger('input');

                submitButton.click();
            }, 3000);

            return true;
        case 'account.box.com': // fall-through
        case 'box':
            OnionIDLog('Custom login submission for app.box.com');
            OnionIDLog('window.name: ' + window.name);

            usernameField = $('input#login-email');
            passwordField = $('input#password-login');

            OnionIDLog('box.com login elements -> #username: ' + usernameField.length + ', #password: ' + passwordField.length);

            // Submit username & pass as two separate page-form submissions
            if (usernameField.length && !window.name) {
                OnionIDLog("box.com: Saving credentials to window.name and submitting email");
                window.name = JSON.stringify({"app": "box", "username": username, "password": password });

                usernameField.val(username);
                usernameField.trigger('input');
                usernameField.focus();
                usernameField.blur();

                submitButton = $('button#login-submit');
                submitButton.click();
            } else if (passwordField.length && window.name) {
                OnionIDLog("box.com: Submitting password from window.name");
                try {
                    var winName = JSON.parse(window.name);
                    window.name = '';

                    passwordField.val(winName.password);
                    passwordField.focus();
                    passwordField.blur();
                    passwordField.trigger('input');

                    captchaField = $('#recaptcha-anchor > div.recaptcha-checkbox-border');
                    if (captchaField.length) {
                        OnionIDLog('Clicking captcha checkbox');
                        captchaField.click();
                    }
                    submitButton = $('button#login-submit-password');
                    submitButton.click();
                } catch (err) {
                    OnionIDLog("Box.com: Unable to access credentials from window.name for submission.");
                    OnionIDLog(err.stack);
                }
            }
            return true;

        case 'onelogin':    // Identify first two-step login via xhr - OG-1060
            OnionIDLog('Custom login submission for onelogin.com');

            setTimeout(() => loginInputSubmit('input#username', username, () => () => $('form button').first(), 2), 0);
            setTimeout(() => loginInputSubmit('input#password', password, () => () => $('form button').eq(1), 5), 1000);

            return true;

        case 'jumpcloud':
            OnionIDLog('Custom login submission handler for app Jumpcloud');

            // Do autologin only if Admin Portal login page is loaded. #OG-628
            // Login swap button: $('button.Login__swapClientTypeButton').
            if ($('.AdminLogin__container').length) {
                OnionIDLog('Jumpcloud Admin Portal login page found.');

                usernameField = $('input[type="email"]');
                passwordField = $('input[type="password"]');

                OnionIDLog('Jumpcloud login elements -> #username: ' + usernameField.length + ', #password: ' + passwordField.length);

                usernameField.val(username);
                passwordField.val(password);
                submitIsATag = false;
                $('button.LoginActionButton__button').click();

                setTimeout(function() {
                    OnionIDLog('Retrying jumpcloud submission');
                    $('button.LoginActionButton__button').click();
                }, 1500);
            }
            return true;

        case 'airbnb':
            OnionIDLog("Custom login form submission for Airbnb app.");
            airbnbAutologin(username, password);
            return true;

        // Zipongo - Athenahealth.com. OG-732
        case 'preview.athenahealth.com':
        case 'athenanet.athenahealth.com':
            OnionIDLog('Custom login submission for Athenahealth.com');

            usernameField = $('input#USERNAME');
            passwordField = $('input#PASSWORD[type="PASSWORD"]');
            submitButton = $('input#loginbutton[type="submit"]');

            OnionIDLog('Athenahealth login elements -> #username: ' + usernameField.length + ', #password: ' + passwordField.length + ', #submit: ' + submitButton.length);

            usernameField.val(username);
            passwordField.val(password);
            submitIsATag = false;

            fire_all_events();
            submit_form();
            return true;

        case 'okta':    // #192487 - OKTA login
            OnionIDLog('Custom login submission for okta');

            var inputField = document.querySelector('input#okta-signin-username');
            var ev = new Event('input', {bubbles: true});
            ev.simulated = true;
            inputField.value = username;
            inputField.defaultValue = username;
            inputField.dispatchEvent(ev);

            var inputField = document.querySelector('input#okta-signin-password');
            var ev = new Event('input', {bubbles: true});
            ev.simulated = true;
            inputField.value = password;
            inputField.defaultValue = password;
            inputField.dispatchEvent(ev);

            return false;

/*
        case 'exvm-corp-epo:8443':  // Extra.com - Correctly identify McAfee app

            if ($('input[name="j_username"]').length && $('input[name="j_password"]').length) 
                return false;
            else
                return true;
*/
        case '192.168.49.129:11880':    // Extra.com SFTP app
            usernameField = $('#username');
            passwordField = $('#password');
            submitButton = $('#submit-btn');

            usernameField.val(username);
            passwordField.val(password);
            submitIsATag = true;

            fire_all_events();
            submit_form();
            return true;

        case '192.168.247.1':  // Extra.com - Correctly identify Fortigate firewall app
            document.getElementById('username').value = username;
            document.getElementById('secretkey').value = password;
            document.getElementById("login_button").click();
            return true;

        case 'credentialsmart':    // OG-1182 - Zipongo Credentialsmart Aperture telenutrition
            OnionIDLog('Custom login submission for credentialsmart.net');
            usernameField = $('input[name="login"]');
            passwordField = $('input[name="password"]');
            submitButton = $('button[name="submitBtn"]');
            OnionIDLog('Credentialsmart login elements -> #username: ' + usernameField.length + ', #password: ' + passwordField.length + ', #submit: ' + submitButton.length);

            usernameField.val(username);
            passwordField.val(password);

            submitButton.click();

            return true;

        case 'whitefishcu_ss':    // AzureDevops 190469
            OnionIDLog('Whitefish Credit Union select correct Domain before default login submission.');
            $("#LoginUserControl1_DomainDropDownList option:contains('Whitefish Credit Union')").attr('selected', 'selected');

            //submitButton = $('button#LoginUserControl1_LoginButton');  // Default submission already use this submit.

            return false;

        default:
            // Return false to proceed to default login method
            return false;
    }
}


/*
 * Custom input field submission function for sites like onelogin.com - OG-1060
 * usage: loginInputSubmit('input#username', username, () => () => $('form button').first(), 2);
 */
function loginInputSubmit(elementSelector, elementValue, submitButton, attempts) {
    OnionIDLog(`loginInputSubmit(${elementSelector}, ${submitButton}, ${attempts})`);

    try {
        if (document.querySelector(elementSelector)) {
            OnionIDLog(`Submitting element ${elementSelector}. 'Attempts': ${attempts}`);
            var inputField = document.querySelector(elementSelector);
            var ev = new Event('input', {bubbles: true});
            ev.simulated = true;
            inputField.value = elementValue;
            inputField.defaultValue = elementValue;
            inputField.dispatchEvent(ev);
            submitButton()().click();
        } else {
            if (attempts - 1 > 0)
                setTimeout(() => {
                    OnionIDLog(`loginInputSubmit: Retry submit ${elementSelector}`);
                    loginInputSubmit(elementSelector, elementValue, submitButton, attempts - 1)
                }, 500);
        }
    } catch (e) {
        OnionIDLog("loginInputSubmit(): Login submission error: " + e.message);
    }
}

// Custom login form submission for Airbnb app. OG-661
function airbnbAutologin(username, password) {

    if ($('input#phoneNumber').length) {
        OnionIDLog("Autologin not supported for phone no.");
        return true;
    } else {
        OnionIDLog("Airbnb login method is not phone number. Proceeding with autologin.")
        // Switch to proper email based login form
        if ($('._18m31f1b').length)
            $('._18m31f1b').click();
    }
    usernameField = $('input[type=email]');

    if (usernameField.length) {
        OnionIDLog(`Setting Airbnb username email as '${username}'`);
        usernameField.val(username);
        usernameField.click();
        usernameField.focus();
        usernameField.addClass('focus-visible');
        usernameField.attr("data-focus-visible-added");
        usernameField.trigger('input');
        usernameField.val(username);
        usernameField.trigger('input');
        usernameField.focus();
        usernameField.blur();
    }

    passwordField = $('input[name=password]');
    passwordField.val(password);
    passwordField.click();
    passwordField.focus();
    passwordField.addClass('focus-visible');
    passwordField.attr("data-focus-visible-added");
    passwordField.trigger('input');
    passwordField.val(password);
    passwordField.trigger('input');
    passwordField.focus();
    passwordField.blur();

    setTimeout(() => $('form[action="/authenticate"] button[type=submit]').first().click(), 2000);
    return true;
}


// Fill & submit username/password of atlassian login form - OG-710
function atlassianAutologin(username, password) {
    OnionIDLog(`Atlassian login submit(${username}, ${password})`);
    // Fill in username and submit
    if ($('input#username[type=email]').length) {
        OnionIDLog(`Atlassian set username(${username}) and click.`);
        usernameField = $('input#username[type=email]');
        usernameField.val(username);
        submitButton = $('button#login-submit');
        fire_input_events();
        fire_all_events();
        submit_form();

    }

    // Fill in password and submit after waiting for pass page to load
    setTimeout(() => {
        OnionIDLog(`Atlassian submiting pass: ${password})`);
        if ($('input#password[type=password]').length) {
            OnionIDLog(`Atlassian set pass(${password}) and click.`);
            passwordField = $('input#password[type=password]');
            passwordField.val(password);
            submitButton = $('button#login-submit');
            fire_input_events();
            fire_all_events();
            submit_form();
        }
    }, 2000);
}



//Find the proper login form and its fields, fill the values and submit
function do_login(username, password, extra = "", extra2 = "") {
    OnionIDLog(`do_login().username: ${username}`);
    loginForm="";
    usernameField="";
    submitIsATag = false;

    //OnionIDLog("the username ISSSSS " + username);
    
    saveAppUsername(username, currentUrl);

    if(findApp(currentUrl) == 'cloudflare') {
        login_to_cloudflare(username, password);
        return;
    }
 
    if(findApp(currentUrl) == 'godaddy') {
        login_to_godaddy(username, password);
        return;
    }

     if(findApp(currentUrl) == 'instagram') {
        login_to_instagram(username, password);
        return;
    }


    if(findApp(currentUrl) == 'google') {
        login_to_google(username, password);
        return;
    }

    // skip training field check and do normal login for amazon
    if(findApp(currentUrl) == 'amazon') {
        OnionIDLog('login for amazon');
        find_form();
        find_input_fields(username, password);
        submit_form();
        return;
    }

    var internalApp = getInternalAppNameHack(currentUrl);
    OnionIDLog(`do_login().getInternalAppNameHack(${currentUrl}) -> internalApp: ${internalApp}`);

    // Special login for internal apps
    if (internalApp != '') {
        // Return if login is done, otherwise use default login methods
        if (login_to_internal_app(username, password, internalApp, currentUrl)) {
            return;
        }
    }
    OnionIDLog(`do_login() - Proceeding with login attempt after login_to_internal_app()`);

    if (trainingFields.length == 0) {

        if (findApp(currentUrl) == "forti") {
            login_to_forti(username, password);
            return;
        }

        if ((currentUrl.indexOf("https://vpn.zipongo.com") > -1)){
            login_to_vpn_zipongo(username, password);
            return;
        }

        if (findApp(currentUrl) == "trello"){
            login_to_trello(username, password);
            return;
        }

        if (findApp(currentUrl).indexOf("hostedcafe") > -1 && findApp(currentUrl).indexOf("servicedesk") == -1 ) {
          if (currentUrl == "https://health.hostedcafe.com/phoenix/login-html.jsf"
           || currentUrl == "https://health.dev.hostedcafe.com/phoenix/login-html.jsf"
           || currentUrl == "https://health-dev.hostedcafe.com/phoenix/login-html.jsf") {
            login_to_hostedcafe_html(username, password, extra, extra2);
          }
          else {
            login_to_hostedcafe(username, password, extra, extra2);
          }
          return;
        }
        
        if (findApp(currentUrl) == "airbnb"){
            airbnbAutologin(username, password);
            return;
        }

        // Custom login submission for Atlassian - OG-710
        if (findApp(currentUrl) == "atlassian") {
            OnionIDLog(`Atlassian custom login submit.`);
            atlassianAutologin(username, password);
            return;
        }

        
        OnionIDLog("Find the form");
        find_form();
        OnionIDLog("Fill fields");
        find_input_fields(username, password);
        OnionIDLog("Submit");
        if(appNeedsTimeout()) {
            setTimeout(function() {
                fire_all_events();
                submit_form();
            }, 5000);
        }
        else {
            submit_form();

            // Login submit is AJAX, there is no page reload so we should close the OnionID popups after form submit
            if (findApp(currentUrl) == "semrush" || findApp(currentUrl) == "ahrefs") {
                removePopups();
            }
        }

    }
    else {
        if (findApp(currentUrl).indexOf("hostedcafe") > -1 && findApp(currentUrl).indexOf("servicedesk") == -1) {
          if (currentUrl == "https://health.hostedcafe.com/phoenix/login-html.jsf"
           || currentUrl == "https://health.dev.hostedcafe.com/phoenix/login-html.jsf"
           || currentUrl == "https://health-dev.hostedcafe.com/phoenix/login-html.jsf") {
            login_to_hostedcafe_html(username, password, extra, extra2);
          }
          else {
            login_to_hostedcafe(username, password, extra, extra2);
          }
          return;
        }

        fill_and_submit_training_fields(username, password);

    }
}

//Itterates all fields available via the training process and submits available values from user's credentials
function fill_and_submit_training_fields(username, password) {
    $.each(trainingFields, function (key, trainingField) {
        if(trainingField.type == "username") {
            var usernameField = findInput(trainingField.html_source);
            OnionIDLog(usernameField);
            OnionIDLog(username);
            usernameField.val(username);
        }

          if(trainingField.type == "extra") {
            var extraField = findInput(trainingField.html_source);
            OnionIDLog(extraField);
            theProperAuthenticationField = decideOnAuthenticationField(trainingField);
            OnionIDLog(theProperAuthenticationField);
            extraField.val(theProperAuthenticationField);
        }

        if(trainingField.type == "password") {
            var passwordField = findInput(trainingField.html_source);
            OnionIDLog(passwordField);
            passwordField.val(password);
        }
        if(trainingField.type == "submit") {
            submitButton = findInput(trainingField.html_source);
            OnionIDLog(submitButton);
        }
    });
    submitButton.click();
}

//If we have extra fields we parse the generic authentication fields to see which field they correspond to.
//Convention >>>>> splits field name with user field value.
function decideOnAuthenticationField(trainingField) {
    extraAuthenticationParts1 = extraAuthenticationField.split('>>>>>');
    extraAuthenticationParts2 = extraAuthenticationField2.split('>>>>>');

    if(trainingField.extra_field_name == extraAuthenticationParts1[0]) {
        return extraAuthenticationParts1[1];
    }

    if(trainingField.extra_field_name == extraAuthenticationParts2[0]) {
        return extraAuthenticationParts2[1];
    }
}

function urlIsForNetdefend(url) {
  if (url == "https://health.hostedcafe.com/phoenix/login.jsf"
   || url == "https://health.hostedcafe.com/phoenix/login-html.jsf"
   || url == "https://health-dev.hostedcafe.com/phoenix/login.jsf"
   || url == "https://health-dev.hostedcafe.com/phoenix/login-html.jsf"
   || url == "https://health.dev.hostedcafe.com/phoenix/login-html.jsf"
   || url == "https://health.dev.hostedcafe.com/phoenix/login.jsf")
    return true;

  return false;
}

function urlIsForSecretServer(url) {
  if (url == "https://ivstg10101.corp.intervision.com/SecretServer/login.aspx"
   || url == "http://ivstg10101.corp.intervision.com/SecretServer/login.aspx")
    return true;

  return false;
}

//Show OnionId Register Form
function showRegisterForm(type) {
    removePopups();
    registerTemplate = 'html/onionid-credentials-popup.html';

    //if we are in trained mode and have extra fiels, show a form containing extra fields too
    if(trainingFields.length > 3)
        registerTemplate = 'html/onionid-credentials3-popup.html';
    if(trainingFields.length > 4)
        registerTemplate = 'html/onionid-credentials4-popup.html';

    if (urlIsForNetdefend(currentUrl))
       registerTemplate = 'html/onionid-credentials4-netdefend-popup.html';

    $.get(chrome.extension.getURL(registerTemplate), function(result) {
        $('body').append(result);
        if(trainingFields.length > 3) {
            fixNamingOfFieldsAndAssociateData();
        }

        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        //$('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.gif"));
        $('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        $('.theAppName').html(window.location.host);

        OnionIDLog("Training fields length is " + trainingFields.length);

        OnionIDLog("The allow_personal is " + allow_personal);
        if(!allow_personal)
            $('#onionID_personalAccountDiv').html('Personal accounts are not recommended. This account will not be secured by Thycotic Access Controller.');

        if(!login_found_register() && type=="wrong") {
            $('#onionIDnote').css("display","block");
            addBypassButton();
        }

        $('#onionID_credentials_popup').draggable({
                start: function() {
                    $('#onionID_overlay').remove();
                }
            }
        );

        $('#onionID_credentials_popup').css('cursor','move');
        addBypassButton();

        $("#onionRegisterCredentialsSubmit").on('click',function() {
            var username = $('#onionIDusername').val();
            var password = $('#onionIDpassword').val();
            var extra = $('#onionIDextra1').attr('data-onionid-extra') + '>>>>>' + $('#onionIDextra1').val();
            var extra2 = $('#onionIDextra2').attr('data-onionid-extra') + '>>>>>' + $('#onionIDextra2').val();
            var url = $('#onionIDurl').val();

            var isPersonal = $("#personal_ac").is(':checked') == true ? 1 : 0;
            OnionIDLog("is Personal: " + isPersonal);


            if(type == "wrong") {
                var onionIdRegisterRequest = {
                    "username": username,
                    "password": password,
                    "personal": isPersonal,
                    "extra": extra,
                    "extra2": extra2,
                    "account" : account,
                    "sdcode": sdcode,
                    "url": currentUrl,
                    "full_domain": window.location.host,
                    "type": "Chrome Update Account"
                };
            }
            else {
                var onionIdRegisterRequest = {
                    "username": username,
                    "password": password,
                    "extra": extra,
                    "extra2": extra2,
                    "personal": isPersonal,
                    "sdcode": sdcode,
                    "url": currentUrl,
                    "full_domain": window.location.host,
                    "type": "Chrome Register Credentials"
                };
            }

            //OnionIDLog(onionIdRegisterRequest);
            $.ajax({
                type: "POST",
                url: theServer,
                dataType: "json",
                data: JSON.stringify(onionIdRegisterRequest),
                context: document.body,
                success: function (response) {

                    if(response.message == "Username Already Exists") {
                        //OnionIDLog(response);
                        $('#onionIDnote').css("display","block");
                    } else {
                        OnionIDLog(response);
                        //OnionIDLog(response.username);
                        //OnionIDLog(response.password);
                        //TODO return the extra field inside the response from api like username and password
                        //it's safe like this because only if the response is succesfull we attempt a login
                        if (findApp(currentUrl).indexOf("hostedcafe") > -1 && findApp(currentUrl).indexOf("servicedesk") == -1){
                          //from version 2.9.5 every hosted cafe registration require 4 field
                          //but we also support login with three because of customer who
                          //are already registered
                          if (extra2 == null) {
                              do_login(response.username, response.password, extra);
                          }
                          else {
                            do_login(response.username, response.password, extra, extra2);
                          }
                        }
                        else {
                          do_login(response.username, response.password);
                        }
                    }

                }
            });

        });

        $("#onionReload").on('click',function() {
                removePopups();
                attempts_count = 0;
                startAuthenticationProcess(sdcode, true);
        });

        $("#onionIDpassword").keyup(function(event){
            if(event.keyCode == 13){
                $("#onionRegisterSubmit").click();
            }
        });

    });

}

function fixNamingOfFieldsAndAssociateData() {
    counter=1;
    $.each(trainingFields, function (key, trainingField) {
        OnionIDLog(trainingField);
        if(trainingField.type == "extra") {
            $('#onionIDextra'+counter).attr('placeholder', 'Enter ' + trainingField.extra_field_name + ' field');
            $('#onionIDextra'+counter).attr('data-onionid-extra', trainingField.extra_field_name);
            counter++;
        }
    });

}

function deleteAccount() {

    var onionIdAccountDeleteRequest = {
        "account" : account,
        "sdcode": sdcode,
        "url": currentUrl,
        "full_domain": window.location.host,
        "type": "Chrome Delete Account"
    };


    //OnionIDLog(onionIdAccountDeleteRequest);
    $.ajax({
        type: "POST",
        url: theServer,
        dataType: "json",
        data: JSON.stringify(onionIdAccountDeleteRequest),
        context: document.body,
        success: function (response) {
            OnionIDLog('reloading page');
            location.reload();
        }
    });
}


//Show OnionId verify credentials form
function verifyCredsPopup() {
    OnionIDLog("Verify credentials popup");
    $.get(chrome.extension.getURL('html/onionid-verify-credentials-popup.html'), function(result) {
        $('body').append(result);
        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        addBypassButton();

        $('#onionID_credentials_popup').draggable({
                start: function () {
                }
            }
        );

        $('#onionID_credentials_popup').css('cursor', 'move');

        $("#onionVerify").on('click', function () {

            var onionIdVerifyRequest = {
                "sdcode": sdcode,
                "url": currentUrl,
                "type": "Chrome Update Credentials"
            };

            $.ajax({
                type: "POST",
                url: theServer,
                dataType: "json",
                data: JSON.stringify(onionIdVerifyRequest),
                context: document.body,
                success: function (response) {
                    $('#onionID_credentials_popup').remove();
                }
            });

        });

        $("#onionWrong").on('click', function () {
            $('#onionID_credentials_popup').remove();
            showRegisterForm("wrong");
        });
    });

}

//Find Application from url
function findApp(theRequestUrl) {

    // Extra.com Fortigate internal-private app
    if (theRequestUrl.indexOf('exvm-corp-epo:8443') > -1) { // Extra.com
        return 'exvm-corp-epo:8443';
    }

    if(appNeedsHack(theRequestUrl)) {
        return appFindHack(theRequestUrl);
    }

    // For url belongs to netdefend app we need to keep the whole name
    // so the health.hostedcafe is different from servicedesk.hostedcafe
    if (urlIsForNetdefend(theRequestUrl)) {
      theRequestUrl = theRequestUrl.split(".com")[0];
      theRequestUrl = theRequestUrl.split("//")[1];
    }
    else if (urlIsForSecretServer(theRequestUrl)) {
      theRequestUrl = theRequestUrl.split(".com")[0];
      theRequestUrl = theRequestUrl.split("//")[1];
    }
    else {
      theRequestUrl = window.location.host;

      if(theRequestUrl.indexOf(".co.uk") > -1 ) {
          theRequestUrl = theRequestUrl.split(".uk")[0];
      }

      if(theRequestUrl.indexOf(".co.jp") > -1 ) {
          theRequestUrl = theRequestUrl.split(".jp")[0];
      }

      theRequestUrl = theRequestUrl.split(".");
      theRequestUrl.pop();
      theRequestUrl = theRequestUrl.pop();
    }
    return theRequestUrl;
}

function appNeedsHack(theRequestUrl) {

    if(theRequestUrl.indexOf("tsukaeru") > -1) {
        return true;
    }

    //this is also on netdefend app but because it has a regular login form
    //does not belong on urlIsForNetdefend
    if(theRequestUrl.indexOf("servicedesk") > -1 && theRequestUrl.indexOf("hostedcafe.com") > -1) {
      return true;
    }

    if (getInternalAppNameHack(theRequestUrl) != '') {
        return true;
    }
}

function appFindHack(theRequestUrl) {

    if(theRequestUrl.indexOf("tsukaeru") > -1) {
        return "tsukaeru";
    }

    if ((theRequestUrl.indexOf("servicedesk") > -1) && (theRequestUrl.indexOf("hostedcafe.com") > -1)) {
      return "servicedesk.hostedcafe";
    }

    var internalApp = getInternalAppNameHack(theRequestUrl);
    if (internalApp != '') {
        return internalApp;
    }
}


function onionIdSystemMessage(message) {

    removePopups();
    $.get(chrome.extension.getURL('html/onionid-top-error-banner.html'), function(result) {
        $('body').append(result);
        OnionIDLog("It works");
        $('#onionID_top_error_bar_message').html(message);
        addBypassButton();
    });

}

function onionIdBlockMessage(message) {
    if(window.isTop) {
        $.get(chrome.extension.getURL('html/onionid-top-block-banner.html'), function(result) {
            $('body').append(result);
            OnionIDLog("It works");
            addBypassButton();
            $('#onionID_top_block_bar').click(function() {
                stopChecking = true;
                removePopups();
                startAuthenticationProcess(sdcode, false, true)
            });
        });
    }
}

function authenticateElements() {
    removePopups();
    $('.onionID_blockelement_overlay').remove();
    $.each(theElementList, function(index, element) {

        if (!element) {
            return;
        }

        element.unbind('click');
        if(savedHtmls[index] != "") {
            element.html(savedHtmls[index]);
        }
        if(element.css('opacity') == 0) {
            element.css('opacity', 1);
        }
        if(element.attr('title') == "Protected by Onion ID" || element.attr('title') === "Protected by Thycotic Access Controller")
            element.attr('title', "");
        element.css("pointer-events", "auto");
    });
    if(foundRestrictedElement) {
        showRequestAccessBar("Thycotic Access Controller: There are still blocked resources in this page. If you want to request access, click here.");
    }
}


function startAuthenticationProcess(sdcode, checkLogin, blockElements,isForBlockedUrl) {
    OnionIDLog(`startAuthenticationProcess(${sdcode}, ${checkLogin})`);
    //get location coords
    chrome.runtime.sendMessage ( {command: "geoloc"}, function (response) {
        if(response != "geolocation error") {
            theGeo = response.coords;
            OnionIDLog(`geoloc lookup response: `);
            OnionIDLog(response);
            chrome.runtime.sendMessage({command: "geoip"}, function (response) {

                OnionIDLog(response);
                if(response) {
                    var city = response.geoip.city;
                    var region = response.geoip.regionName;
                    var country = response.geoip.country;
                    var ip = response.geoip.query;
                }
                else {
                    var city = "";
                    var region = "";
                    var country = "";
                    var ip = "";
                }

                OnionIDLog(`startAuthenticationProcess().checkLogin: ${checkLogin} -> checkForLoginForm()`);
                //begin the OID process
                if(checkLogin)
                    checkForLoginForm(false, 2000, sdcode, theGeo, city, region, country, ip);
                else {
                    if(isForBlockedUrl){
                        //here we want not to authenticate but just to insert into
                        //the database the attempt of user to visit a blocked url
                        BlockedUrl(false, 2000, sdcode, theGeo, city, region, country, ip);
                    }
                    else{
                      if(blockElements) {
                          blockPageElements(false, 2000, sdcode, theGeo, city, region, country, ip);
                      }
                      else {
                          banPage(false, 2000, sdcode, theGeo, city, region, country, ip);
                      }
                    }
                }
            });
        }
        else {
            OnionIDLog('Google Geolocation API has failed us');
            //onionIdSystemMessage('We cannot establish a network connection to validate your location at this time. Please try again later. If the problem persists, please contact your network administrator.');
        }
    });
}

function BlockedUrl(credsChecked, timeout, obj, theCoords, city, state, country, ip){
  chrome.storage.local.get(['saveBanned'], function(result) {
    var bannedUrl = result.saveBanned;
    chrome.storage.sync.get( "sdcode", function (obj) {
      sdcode=obj.sdcode.val;
      chrome.storage.local.get( "bannedUrlId" , function (obj) {
        bannedUrlId = obj.bannedUrlId;

        var policyRequest = {
            "urlId": bannedUrlId,
            "url": bannedUrl,
            "full_domain": window.location.host,
            "type": "AddBockedUrlAccessAttempt",
            "sdcode": sdcode,
            "coords": theCoords,
            "city": city,
            "country": country,
            "state": state,
            "ip": ip,
            "agent": navigator.appVersion
        };
        sendPolicyRequest(policyRequest, sdcode, true);
     });
   });
 });
}

function checkForLoginForm(credsChecked, timeout, obj, theCoords, city, state, country, ip) {
    var application = findApp(currentUrl);
    OnionIDLog(`checkForLoginForm(). application: ${application}, currentUrl: ${currentUrl}`);
    var policyRequest = {
        "url": application,
        "full_url":currentUrl,
        "full_domain": window.location.host,
        "type": "Chrome Find Policy 2",
        "sdcode": sdcode,
        "coords": theCoords,
        "city": city,
        "country": country,
        "state": state,
        "ip": ip,
        "agent": navigator.appVersion
    };

    if(login_found() || login_found_hack()) {

        if (findApp(currentUrl) == 'airbnb')
            airbnbSwitchTheme();

        chrome.runtime.sendMessage ( {command: "setUninstallUrl", sdcode: sdcode, ip: ip, city: city, country: country}, function (response) {
        });
        OnionIDLog(`login_found_ sendPolicyRequest ` + JSON.stringify(policyRequest));
        sendPolicyRequest(policyRequest, sdcode, false);
    }
    else {
        if(!stopChecking)
        setTimeout( function() {checkForLoginForm(true, timeout)}, timeout)
    }
}

function blockPageElements(credsChecked, timeout, obj, theCoords, city, state, country, ip) {
    var policyRequest = {
        "url": currentUrl,
        "full_domain": window.location.host,
        "type": "Chrome Find Policy 2",
        "sdcode": sdcode,
        "coords": theCoords,
        "city": city,
        "country": country,
        "state": state,
        "ip": ip,
        "agent": navigator.appVersion
    };
    sendPolicyRequest(policyRequest, sdcode, false, true);
}

//Send the Find Policy request to the server and parse the response
function sendPolicyRequest(policyRequest, sdcode, special_url, blockedElement) {
    if( !blockedElement ) blockedElement = false;
    OnionIDLog("sendPolicyRequest(): About to send policy");
    $.ajax({
        type: "POST",
        url: theServer,
        dataType: "json",
        data: JSON.stringify(policyRequest),
        timeout: globalTimeout,
        success: function (response) {

            OnionIDLog(`sendPolicyRequest().response: ` + JSON.stringify(response));
            
            if(response.fields) {
                trainingFields = response.fields;
            }

            if(response.fallback) {
                fallback = response.fallback;
                OnionIDLog("FALLBACK ENABLED: " + response.fallback );
                if(fallback == 1 ) fallback = true;
                else fallback = false;
            }
            else {
                fallback = false;
            }

            if(response.allow_personal) {
                allow_personal = 1;
            }
            else {
                allow_personal = 0;
            }

            if(response.accounts)
                accounts = response.accounts;
            else
                accounts = [];

            if (response.policy) {
                popups = response.policy;
                popups = popups.split(" ");
                popups.pop();
                OnionIDLog(popups.length);
                geoproximity = response.geoproximity;
                geofencing = response.geofencing;

                if(response.masterpass == 1) {
                    masterpass = true;
                }

                if(response.display_name) {
                    OnionIDLog("Custom display name " + response.display_name);
                    displayName = response.display_name;
                } else {
                    displayName = window.location.host;
                }

                if(response.autologin)
                    autologin = response.autologin;
                else
                    autologin = 0;

                // Override Yubikey with TouchId/Masterpass. OG-944
                if (popups[0] == 7 && !response.has_yubikey && fallback)
                    popups[0] = 1;

                if(popups[0] == 6) {
                    OnionIDLog(`popups[0] 6 -> showMasterPassPopupWithAccounts`);
                    showMasterPassPopupWithAccounts(accounts);
                } else if (popups[0] == 7) { // Yubikey
                    var has_client_yubikey_id = response.has_yubikey == 1
                    yubikey_policy(has_client_yubikey_id, accounts, special_url, blockedElement, autologin)
                }
                else {

                    if(special_url) {
                        $('html').css('display','block');
                        $.get(chrome.extension.getURL('html/onionid-ban.html'), function(result) {
                            thePageHtml = $('html').html();
                            $('html').html(result);
                            //$('#onionid_logo_big').attr('src', chrome.extension.getURL("img/onionid_logo_big.png"));
                            //$('#onionid_logo_big').attr('src', chrome.extension.getURL("../img/popupicon.svg"));
                            //$('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("../img/thycotic-all-white.svg"));
                        });
                    }
                    var popup_delay = parseInt(response.popup_delay);
                    OnionIDLog("Popup delay for CAPTCHA: " + popup_delay);
                    if(!popup_delay || popup_delay == 'undefined' || popup_delay == 0) {
                        OnionIDLog('authNext() !popup_delay - popups: ' + JSON.stringify(popups) + ', accounts: ' + JSON.stringify(accounts));
                        authNext(popups, accounts, displayName, geofencing, geoproximity, sdcode, autologin, special_url, blockedElement);
                    } else {
                        showTopDelayBanner();
                        popupDelayCountdown(popup_delay);
                        setTimeout(function() {
                            authNext(popups, accounts, displayName, geofencing, geoproximity, sdcode, autologin, special_url, blockedElement);
                        }, (popup_delay+1) * 1000);
                    }

                }
            }
            else {
                $('html').css('display','block');
                OnionIDLog(response.message);
                if(response.message == "Policy does not include IP")
                    $.get(chrome.extension.getURL('html/onionid-message.html'), function(result) {
                        $('body').append(result);
                        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
                        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
                        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
                        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
                        addBypassButton();
                    });
            }
        },
        error: function (x, t, m) {
            if (t === "timeout") {
                onionIdSystemMessage('Network Error. Please, verify your network connection.');
                OnionIDLog("Policy Fetch Timeout!");
            } else {
                onionIdSystemMessage('Network Error. Please, verify your network connection.');
            }
        }
    });
}

// Yubikey functions start:
function yubikey_policy(has_client_yubikey_id, accounts, special_url, blockedElement, autologin) {
    if(has_client_yubikey_id === true) {
        show_yubikey_authentation(accounts, special_url, blockedElement, autologin)
    } else {
        show_yubikey_register_popup(accounts, special_url, blockedElement, autologin)
    }

}

function show_yubikey_register_popup(accounts, special_url, blockedElement, autologin) {
    $.get(chrome.extension.getURL('html/onionid-yubikey-register.html'), function(result) {
        $('body').append(result);
        $('body').append(overlay);
        //Toggle comment if you want masterpass popup to disappear or not.
        //setTimeout(function() { removePopups(); }, 30 * 1000);

        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        $('#onionIDupdateMasterPass').css('cursor','pointer');
        addBypassButton();
        $('#onionID_policy_popup').draggable({
                start: function () {
                }
            }
        );
        // on form submit:
        $("#onionIDRegisterYubikey").on('click', function() {
            var yubikey_client_id = $('#yubikey_client_id').val();
            var yubikey_client_otp = $('#yubikey_client_otp').val();
            // check for empty fields:
            if(yubikey_client_otp.length === 0){
                $('#errorMessage').html('Please, provide a one time passoword from your Yubikey.');
                $('#errorMessage').css("visibility", "visible");
                return
            }

            if(yubikey_client_id.length === 0){
                $('#errorMessage').html('Please, provide the client id from the Yubico.');
                $('#errorMessage').css("visibility", "visible");
                return
            }

            var onionIdYubikeyRequest = {
                "yubikey_client_id": yubikey_client_id,
                "yubikey": yubikey_client_otp,
                "sdcode": sdcode,
                "type": "Register Yubikey Client ID"
            };

            OnionIDLog("onionIdYubikeyRequest: " + JSON.stringify(onionIdYubikeyRequest));
            $.ajax({
                type: "POST",
                url: theServer,
                dataType: "json",
                data: JSON.stringify(onionIdYubikeyRequest),
                context: document.body,
                success: function (response) {
                    if(response.response == "Yubikey id succesfully registered"
                        /*|| response.response == "Yubikey already registered"*/){
                        OnionIDLog("Yubikey Client ID Stored");
                        // remove popus:
                        removePopups();
                        // start authentication with yubikey
                        show_yubikey_authentation(accounts, special_url, blockedElement, autologin)
                    }
                    else {
                        $('#errorMessage').html(response.message);
                        $('#errorMessage').css("visibility", "visible");
                    }
                }
            });

        });

        $("#yubikey_client_id").keyup(function(event){
            if(event.keyCode == 13){
                $("#onionIDRegisterYubikey").click();
            }
        });
        // handle accounts:
        OnionIDLog("The accounts length is " + accounts.length);
        if(accounts.length > 0) {
            $.each(accounts, function (key, account) {
                if(account.username.length>20) {
                    wellFormedAccount = account.username.substring(0,19);
                    wellFormedAccount+="...";
                }
                else {
                    wellFormedAccount = account.username;
                }
                $('#onionID_choose_account select').append('<option value="' + account.id + '">' + wellFormedAccount + '</option>')
            });
            account = $( "#onionID_choose_account select option").first().val();
            $( "#onionID_choose_account select" ).change(function () {
                account = $( "#onionID_choose_account select option:selected" ).val();
            });

            $("#onionID_policy_popup").on("change", "#onionID_choose_action select",function () {
                action = $( "#onionID_choose_action select option:selected" ).val();
                actionInt = parseInt(action);
                OnionIDLog("Action changed to " + actionInt);
                //If autologin don't change the message and keep countdown
                if(autologin)
                    actionInt = 0;

                switch(actionInt) {
                    case 1:
                        $('.onionID_message').html('Waiting for Yubikey input...');
                        $('.onionID_message').css('color','black');
                        break;
                    case 2:
                        $('.onionID_message').html('Authenticate with your Yubikey to add an account');
                        $('.onionID_message').css('color','#2ECC40');
                        break;
                    case 3:
                        $('.onionID_message').html('Authenticate with your Yubikey to update the account');
                        $('.onionID_message').css('color','#2ECC40');
                        break;
                    case 4:
                        $('.onionID_message').html('Authenticate with your Yubikey to delete the account');
                        $('.onionID_message').css('color','#FF4136');
                        break;
                    default:
                        break;
                }
            });

        }
        else {
            $('#onionID_choose_account').css('display','none');
            $('#onionID_choose_action').css('display','none');
            $('#onionID_choose_account').remove();
            $('#onionID_choose_action').remove();
        }

    });
}

function show_yubikey_authentation(accounts, special_url, blockedElement, autologin) {
    $.get(chrome.extension.getURL('html/onionid-yubikey-authenticate.html'), function(result) {
        $('body').append(result);
        $('body').append(overlay);
        //Toggle comment if you want masterpass popup to disappear or not.
        //setTimeout(function() { removePopups(); }, 30 * 1000);

        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        $('.onionID_yubikey_image').attr('src', chrome.extension.getURL("img/yubikey.png"))
        $('#onionIDupdateMasterPass').css('cursor','pointer');
        addBypassButton();
        // add accounts:
        if(accounts.length > 0) {
            $.each(accounts, function (key, account) {
                if(account.username.length>20) {
                    wellFormedAccount = account.username.substring(0,19);
                    wellFormedAccount+="...";
                }
                else {
                    wellFormedAccount = account.username;
                }
                $('#onionID_choose_account select').append('<option value="' + account.id + '">' + wellFormedAccount + '</option>')
            });
            account = $( "#onionID_choose_account select option").first().val();
            $( "#onionID_choose_account select" )
            .change(function () {
                account = $( "#onionID_choose_account select option:selected" ).val();
            });

            $( "#onionID_choose_action select" )
            .change(function () {
                action = $( "#onionID_choose_action select option:selected" ).val();
                actionInt = parseInt(action);
                OnionIDLog("Action changed to " + actionInt);
            });
        }

        $('#yubikey_lost').on('click', function(e){
            e.preventDefault();
            var reset_yubikey_request = {
                "sdcode": sdcode,
                "type": "Reset Yubikey Request"
            }
            $.ajax({
                type: "POST",
                url: theServer,
                dataType: "json",
                data: JSON.stringify(reset_yubikey_request),
                context: document.body,
                success: function (response) {
                    if (response.response = "Yubikey Reset Request Sent") {
                        $('#errorMessage').html('Your request has been submitted and an admin will contact you.');
                        $('#errorMessage').css("visibility", "visible");
                    }
                }
            });
        }); // end of yubikey_lost on click

        $("#onionSubmitYubikeyPass").on('click', function(event) {
            var otp = $('#yubikeyPassword').val();
            var onionIdYubikeyAuthenticateRequest = {
                "yubikey": otp,
                "sdcode": sdcode,
                "url": currentUrl,
                "full_domain": window.location.host,
                "type": "Authenticate Yubikey Password"
            };
            OnionIDLog(JSON.stringify(onionIdYubikeyAuthenticateRequest))
            $.ajax({
                type: "POST",
                url: theServer,
                dataType: "json",
                data: JSON.stringify(onionIdYubikeyAuthenticateRequest),
                context: document.body,
                success: function (response) {
                    // if success: {"response": "successfull authentication"}
                    if(response.response == "successfull authentication"){
                        OnionIDLog(response);
                        var authenticate_request = {
                            "url": currentUrl,
                            "sdcode": sdcode,
                            "account": account,
                            "full_domain": window.location.host,
                            "type": "Chrome Authenticate Account"
                        };
                        OnionIDLog("authenticate_request:\n" + JSON.stringify(authenticate_request))
                        $.ajax({
                            type: "POST",
                            url: theServer,
                            dataType: "json",
                            data: JSON.stringify(authenticate_request),
                            context: document.body,
                            timeout: globalTimeout,
                            success: function (response) {
                                OnionIDLog(JSON.stringify(response))
                                if(response.extra) {
                                    extraAuthenticationField = response.extra;
                                }

                                if(response.extra2) {
                                    extraAuthenticationField2 = response.extra2;
                                    OnionIDLog("The extra auth field 2" + extraAuthenticationField2);
                                }

                                if (response.status != "Waiting for Authentication" && blockedElement) {
                                    authenticateElements();
                                    return;
                                }

                                if (response.message == "register") {
                                    showRegisterForm();
                                    stop = true;
                                }
                                else if (response.status == "Waiting for Authentication") {

                                    if(attempts_count == kill_popup_limit) {
                                            stop = true;
                                            removePopups();
                                    }
                                    var request = {
                                        "url": application,
                                        "sdcode": sdcode,
                                        "account": account,
                                        "full_domain": window.location.host,
                                        "type": "Chrome Authenticate Account"
                                    };
                                    authenticateAttempt(globalTimeout, request, special_url, autologin, accounts, blockedElement)
                                }
                                else if (response.message == "canceled") {
                                    OnionIDLog('canceled');
                                    removePopups();
                                }
                                else if(!masterpass) {
                                  if(action==1) {
                                        if(!special_url) {
                                            stop = true;
                                            do_login(response.username, response.password);
                                            setTimeout(function() {removePopups();}, 2000);
                                        }
                                        else {
                                            stop = true;
                                            removePopups();
                                            window.location.href = currentUrl;
                                        }
                                    }
                                    else if (action==2) {
                                        showRegisterForm();
                                    }
                                    else if (action==3) {
                                        showRegisterForm("wrong");
                                    }
                                    else if (action==4) {
                                        deleteAccount();
                                    }
                                    //OnionIDLog(response);
                                }
                                else {
                                   showMasterPassPopup(response.username, response.password);
                                }
                            },
                            error: function(x, t, m) {
                                if (t === "timeout") {
                                    authenticateAttempt(timeout, request, false, accounts, blockedElement);
                                    OnionIDLog("Auth Attempt Timeout!");
                                } else {
                                }
                            }
                        });
                    } else {
                        $('#errorMessage').html(response.response);
                        $('#errorMessage').css("visibility", "visible");
                    }
                },
                error: function(x, t, m) {
                    OnionIDLog('error: ' + JSON.stringify(x));
                    if (t === "timeout") {
                        OnionIDLog("Auth Attempt Timeout!");
                    }else if(x.responseJSON !== undefined && x.responseJSON.response !== undefined) {
                        $('#errorMessage').css("visibility", "visible");
                        switch (x.responseJSON.response) {
                            case 'BAD_OTP':
                                $('#errorMessage').html('The OTP is invalid format.');
                                break;
                            case 'REPLAYED_OTP':
                                $('#errorMessage').html('The OTP has already been seen by the service.');
                                break;
                            default:
                                $('#errorMessage').html(x.responseJSON.response);
                        }

                    }
                }
            });
        });
        // enter automatically pressed by Yubikey
        $("#yubikeyPassword").keyup(function(event){
            if(event.keyCode == 13){
                $("#onionSubmitYubikeyPass").click();
            }
        });
    });
    return;
}

// Yubikey functions end

//This method works to authenticate using the next auth method. Now that we allow one, it's not that useful.
function authNext(popups, accounts, displayName, geofencing, geoproximity, sdcode, autologin, special_url, blockedElement) {
    OnionIDLog(`authNext() popups: ` + JSON.stringify(popups));
    //Fetch saved sdcode
    var application = findApp(currentUrl);
    var request = {
        "url": application,
        "sdcode": sdcode,
        "account": account,
        "full_domain": window.location.host,
        "type": "Chrome Authenticate Account"
    };

    currentPopup = popups[0];

    makePolicyPopup(currentPopup, accounts, displayName, request, authenticateAttempt, autologin, special_url, blockedElement);
    /*
     if(geoproximity == 1) {
     $('#onionIDExtraAuth').css("display","block");
     $('#onionIDgeoproximity').css("display","block");
     }

     if(geofencing == 1) {
     $('#onionIDExtraAuth').css("display","block");
     $('#onionIDgeofencing').css("display","block");
     }
     */


}

function registerExtension() {

    OnionIDLog('clicked!!!!');
    phoneNumber = $('#onionIdPhone').val();
    email = $('#onionIDemail').val();

    var onionIdRegisterRequest = {
        "email": email,
        "phone": phoneNumber,
        "type": "Chrome Register Phone"
    };
    $.ajax({
        type: "POST",
        url: cloudServiceUrl,
        dataType: "json",
        data: JSON.stringify(onionIdRegisterRequest),
        context: document.body,
        timeout: globalTimeout,
        success: function (response) {
            stopClick = false;
            OnionIDLog(response);
            if (response.message == "ok") {
                chrome.storage.local.set({"phone": {'val': phoneNumber}}, function () { });
                chrome.storage.local.set({"email": {'val': email}}, function () { });
                validatePhoneForm("new",email);
            }
            else if(response.message == "The user already has a pin"){
                validatePhoneForm("old",email);
            }
            else {
                $('#errorMessage').html(response.message);
                $('#errorMessage').css("visibility", "visible");
            }
        },
        error: function (x, t, m) {
            stopClick = false;
            if (t === "timeout") {
                //onionIdSystemMessage('Network connectivity cannot be established at this time. Please try again. If the problem persists, please contact your network administrator.');
                OnionIDLog("Register Phone Timeout!");
            }
        }
    });
}



function setMasterPassword(theSdcode) {
    $.get(chrome.extension.getURL('html/onionid-register-masterpass-popup.html'), function(result) {
        removePopups();
        $('body').append(result);
        addBypassButton();
        $('#welcomeMessage').html('Congratulations, as a last step, please set a Master Password to get access to resources that have a Master password policy.');

        $('#onionID_register_pin_popup').css('cursor','move');
//        $('.onionID_blue_popup').css('background-image', 'url('+chrome.extension.getURL("img/background.jpg")+')' )
//        $('.onionID_logo_centered').attr('src', chrome.extension.getURL("img/logo_centered.png"));
        $('.onionID_logo_centered').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionID_blue_popup').css('background-color', '#081f2c');
        
         $('#onionID_register_masterpass_popup').draggable({
                start: function () {
                }
            }
        );

        $("#masterPass").on('click', function () {

                theMasterPass = $('#onionIdMasterPass').val();
                var onionIdMasterPassRequest = {
                    "sdcode": theSdcode,
                    "masterpass": theMasterPass,
                    "type": "Chrome Register Master Password"
                };

                if(theMasterPass == null) {
                    OnionIDLog("password cannot be empty!");
                    $('#errorMessage').css("visibility", "visible");
                    $('#errorMessage').html("Password cannot be empty!");
                } else if ($('#onionIdMasterPassConfirm').val() != theMasterPass) {
                    OnionIDLog("passwords must match!");
                    $('#errorMessage').css("visibility", "visible");
                    $('#errorMessage').html("Passwords must match!");
                } else {
                    sendMasterPassToServer(onionIdMasterPassRequest);
                }

        });

        $("#onionIdMasterPassConfirm").keyup(function(event){
            if(event.keyCode == 13){
                $("#masterPass").click();
            }
        });

    });
}

function sendMasterPassToServer(onionIdMasterPassRequest, autoInstallBE = false) {
    $.ajax({
        type: "POST",
        url: theServer,
        dataType: "json",
        data: JSON.stringify(onionIdMasterPassRequest),
        context: document.body,
        timeout: globalTimeout,
        success: function (response) {
            OnionIDLog(response);
            if (response.response == "Masterpass Inserted") {
                OnionIDLog("Masterpass has been inserted");
                chrome.storage.sync.set( {endpoint: theServer}, function (obj) {
                    OnionIDLog(`Endpoint ${theServer} has been stored in BE`);
                    if (typeof theSdcode == 'undefined')
                        var theSdcode = onionIdMasterPassRequest.sdcode;
                    chrome.storage.sync.set({"sdcode": {'val': theSdcode}}, function () {
                        OnionIDLog('Endpoint and sdcode settings saved');
                        OnionIDLog(`autoInstallBE value is: ${autoInstallBE}`);
                        if (!autoInstallBE) {
                            $('#welcomeMessage').html('<span>Congratulations! Thycotic Access Controller has been activated. Please keep your Registration Code for future reference.</span><br/><br/><br><br>' +
                                    '<div id="masterPass"  class="Rectangle-3" style=" cursor: pointer; ">'+
                                    '<span id="onionID_continue" class="tacButton"  style="font-size:13px !important; margin-left: 10px !important;">CONTINUE</span></div>');
                            $('#errorMessage').css("visibility", "hidden");
                            $('#onionRegisterExtension').css('display','none');
                            $('#onionID_continue').click(function () {
                                location.reload();
                            });
                        } else {
                            OnionIDLog(`autoInstallBE complete - Reloading page to initiate mfa`);
                            location.reload();
                        }
                    });
                });
            }
            else {
                OnionIDLog(response);
            }
        },
        error: function (x, t, m) {
            if (t === "timeout") {
                //onionIdSystemMessage('Network connectivity cannot be established at this time. Please try again. If the problem persists, please contact your network administrator.');
                OnionIDLog("Master Pass Set Request Timeout!");
            }
        }
    });
}

function getAppList(callback) {
    OnionIDLog("getAppList()");
    chrome.storage.local.get( "appsCache", function (obj) {
        if (!jQuery.isEmptyObject(obj)) {
            currentTime = Date.now();
            timeDiff = currentTime -  obj.appsCache.val;
            OnionIDLog("The apps Cache object "  + obj.appsCache.val);
            OnionIDLog("The timediff " + timeDiff);
            if (timeDiff < 1800000) {
                OnionIDLog("Getting cached!");
                chrome.storage.local.get( "appList", function (obj) {
                    appList = obj.appList;
                    callback();
                });
            }
            else {
                getAppListFromServer(callback);
            }
        }
        else {
            OnionIDLog("empty object app list cache");
            getAppListFromServer(callback);
        }
    });
}

function getAppListFromServer (callback) {

    appListRequest =  {
        "url": currentUrl,
        "sdcode": sdcode,
        "type": "Chrome Fetch App List"
    };

    $.ajax({
        type: "POST",
        url: theServer,
        dataType: "json",
        data: JSON.stringify(appListRequest),
        context: document.body,
        timeout: globalTimeout,
        success: function (response) {
            OnionIDLog(response.response);
            appList = response.response;
            currentTime = Date.now();
            OnionIDLog("The current Time is " + currentTime);
            chrome.storage.local.set( {appList: appList}, function (obj) {
                chrome.storage.local.set( {"appsCache": {'val': currentTime}}, function (obj) {
                    callback();
                });
            });
        },
        error: function(jqXHR, t, m) {
            if (t === "timeout") {
                chrome.storage.local.get( "appList", function (obj) {
                    appList = obj.appList.val;
                    callback();
                });
                OnionIDLog("Fetch App List Timeout!");
            } else {
            }

            /* if (jqXHR.status === 0) {
                onionIdSystemMessage('OnionID Error: Not connected. Verify your Network Connection.');
            } else if (jqXHR.status == 404) {
            } else if (jqXHR.status == 500) {
                onionIdSystemMessage('OnionID Error: Internal Server Error.');
            } else if (exception === 'parsererror') {
                onionIdSystemMessage('OnionID Error: Parse Error.');
            } else if (exception === 'timeout') {
                onionIdSystemMessage('OnionID Error: Timeout.');
            } else if (exception === 'abort') {
                onionIdSystemMessage('OnionID Error: Connection aborted. Verify your Network Connection.');
            } else {
            } */
        }
    })
}


function appIsInAppList(appList) {
    appList = appList.split(",");
    OnionIDLog("The currentApp name");
    currentApp = findApp(currentUrl);
    OnionIDLog(currentApp);
    OnionIDLog("The currentApp hash");
    currentHash = CryptoJS.SHA1(currentApp).toString(CryptoJS.enc.Hex);
    OnionIDLog(currentHash);
    if($.inArray(currentHash, appList) != -1)
        return true;
    else {
        currentHash = CryptoJS.SHA1(window.location.host).toString(CryptoJS.enc.Hex);
        if($.inArray(currentHash, appList) != -1){
            OnionIDLog("via hostname hash");
            return true;
        }
        else
            return false;
    }
}

function logCurrentApp() {
    OnionIDLog("logCurrentApp().findApp: " + findApp(currentUrl));
    chrome.storage.local.get( { appsLog: [] }, function (obj) {
        var appsLog = obj.appsLog;
        currentApp = findApp(currentUrl);
        notHere = true;
        appsLog.forEach(function (element) {
            if(element.app == currentApp) {
                element.occurences++;
                notHere = false;
            }
        });
        if(notHere)
            appsLog.push({"app": findApp(currentUrl), "occurences": 1});

        chrome.storage.local.set({appsLog: appsLog}, function () {
            OnionIDLog(appsLog);
        });
    });
}

function showMasterPassPopup(username, password) {
    removePopups();
    $.get(chrome.extension.getURL('html/onionid-masterpass-popup.html'), function(result) {
        $('body').append(result);
        $('body').append(overlay);
        //Toggle comment if you want masterpass popup to disappear or not.
        //setTimeout(function() { removePopups(); }, 30 * 1000);

        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        $('#onionIDupdateMasterPass').css('cursor','pointer');
        addBypassButton();

        $('#onionID_masterpass_update_popup').draggable({
                start: function () {
                }
            }
        );

        updateAllowedOrNot();

        $('#onionIDupdateMasterPass').on('click',function() {
            removePopups();
            $.get(chrome.extension.getURL('html/onionid-masterpass-update-popup.html'), function(result) {
                $('body').append(result);
                $('body').append(overlay);
                //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
                $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
                $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
                $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
                addBypassButton();

            $('#onionRegisterCredentialsSubmit').on('click',function() {

                theMasterPass = $('#newOnionIDpassword').val();
                var onionIdMasterPassRequest = {
                    "sdcode": sdcode,
                    "masterpass": theMasterPass,
                    "type": "Chrome Register Master Password"
                }

                OnionIDLog("Masterpass Verified");

                if($('#newOnionIDpassword').val() == $('#confirmOnionIDpassword').val() ) {
                    OnionIDLog("Password Match");
                    $.ajax({
                        type: "POST",
                        url: theServer,
                        dataType: "json",
                        data: JSON.stringify(onionIdMasterPassRequest),
                        context: document.body,
                        success: function (response) {
                            OnionIDLog("Updated Passwords");
                            if(action==1) {
                                stop = true;
                                do_login(username, password);
                                setTimeout(function() {removePopups();}, 2000);
                            }
                            else if (action==2) {
                                showRegisterForm();
                            }
                            else if (action==3) {
                                showRegisterForm("wrong");
                            }
                            else if (action==4) {
                                deleteAccount();
                            }
                                }
                        });
                }
                else {
                    OnionIDLog("password missmatch");
                    $('#errorMessage').html("Passwords do not match");
                    $('#errorMessage').css("visibility", "visible");
                }

            });
        });
        });

        $("#onionSubmitMasterPass").on('click',function() {
            var masterpass = $('#onionIDpassword').val();
            var onionIdMasterPassRequest = {
                    "masterpass": masterpass,
                    "sdcode": sdcode,
                    "url": currentUrl,
                    "type": "Chrome Verify Master Password"
                };

            OnionIDLog(onionIdMasterPassRequest);
            $.ajax({
                type: "POST",
                url: theServer,
                dataType: "json",
                data: JSON.stringify(onionIdMasterPassRequest),
                context: document.body,
                success: function (response) {
                    if(response.response == "Masterpass Verified"){
                        if(action==1) {
                                stop = true;
                                do_login(username, password);
                                setTimeout(function() {removePopups();}, 2000);
                            }
                            else if (action==2) {
                                showRegisterForm();
                            }
                            else if (action==3) {
                                showRegisterForm("wrong");
                            }
                            else if (action==4) {
                                deleteAccount();
                            }
                    }
                    else {
                        $('#errorMessage').html(response.message);
                        $('#errorMessage').css("visibility", "visible");
                    }
                }
            });

        });

        $("#onionIDpassword").keyup(function(event){
            if(event.keyCode == 13){
                $("#onionSubmitMasterPass").click();
            }
        });

    });

}

function showMasterPassPopupWithAccounts(accounts, blockedElement) {
    OnionIDLog(`showMasterPassPopupWithAccounts() accounts: ` + JSON.stringify(accounts));
    removePopups();
    $.get(chrome.extension.getURL('html/onionid-masterpass-accounts-popup.html'), function(result) {
        $('body').append(result);
        $('body').append(overlay);
        //Toggle comment if you want masterpass popup to disappear or not.
        //setTimeout(function() { removePopups(); }, 30 * 1000);

        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        $('#onionIDupdateMasterPass').css('cursor','pointer');
        addBypassButton();

        if(accounts.length > 0 && !blockedElement) {
            $.each(accounts, function (key, account) {
                if(account.username.length>20) {
                    wellFormedAccount = account.username.substring(0,19);
                    wellFormedAccount+="...";
                }
                else {
                    wellFormedAccount = account.username;
                }
                $('#onionID_choose_account select').append('<option value="' + account.id + '">' + wellFormedAccount + '</option>')
            });
            account = $( "#onionID_choose_account select option").first().val();
            $( "#onionID_choose_account select" )
            .change(function () {
                account = $( "#onionID_choose_account select option:selected" ).val();
            });

            $( "#onionID_choose_action select" )
            .change(function () {
                action = $( "#onionID_choose_action select option:selected" ).val();
                actionInt = parseInt(action);
                OnionIDLog("Action changed to " + actionInt);
            });

        }
        else {
            $('#onionID_choose_account').css('display','none');
            $('#onionID_choose_action').css('display','none');
        }

        if(accounts.length <= 1) {
            $('#onionID_choose_account').css('display','none');
        }

        $('#onionID_masterpass_update_popup').draggable({
                start: function () {
                }
            }
        );

        $('#onionID_masterpass_popup').draggable({
                start: function () {
                }
            }
        );

        updateAllowedOrNot();

        $("#onionSubmitMasterPass").on('click',function() {
            OnionIDLog(`#onionSubmitMasterPass.click() : "Chrome Verify Master Password Account"`);
            var masterpass = $('#onionIDpassword').val();
            var onionIdMasterPassRequest = {
                    "masterpass": masterpass,
                    "sdcode": sdcode,
                    "url": currentUrl,
                    "account": account,
                    "type": "Chrome Verify Master Password Account"
                };

            $.ajax({
                type: "POST",
                url: theServer,
                dataType: "json",
                data: JSON.stringify(onionIdMasterPassRequest),
                context: document.body,
                success: function (response) {
                    OnionIDLog(`#onionSubmitMasterPass.click().response: ` + JSON.stringify(response) + `, 'action': ${action}`);
                    if(response.response == "Masterpass Verified"){

                        if(blockedElement) {
                            authenticateElements();
                            return;
                        }

                        if(response.message == "register") {
                            showRegisterForm();
                        }
                        else {
                            if(action==1) {
                                stop = true;
                                OnionIDLog(`#onionSubmitMasterPass.click().do_login()`);
                                do_login(response.username, response.password);
                                setTimeout(function() {removePopups();}, 2000);
                            }
                            else if (action==2) {
                                showRegisterForm();
                            }
                            else if (action==3) {
                                showRegisterForm("wrong");
                            }
                            else if (action==4) {
                                deleteAccount();
                            }
                        }
                    }
                    else {
                        $('#errorMessage').html(response.message);
                        $('#errorMessage').css("visibility", "visible");
                    }
                }
            });

        });

        $("#onionIDpassword").keyup(function(event){
            if(event.keyCode == 13){
                $("#onionSubmitMasterPass").click();
            }
        });

        $('#onionIDupdateMasterPass').on('click',function() {
            removePopups();
            $.get(chrome.extension.getURL('html/onionid-masterpass-update-email-popup.html'), function(result) {
                $('body').append(result);
                $('body').append(overlay);
                //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
                $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
                $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
                $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
                addBypassButton();

            $('#onionRegisterCredentialsSubmit').on('click',function() {
                theMasterPass = $('#newOnionIDpassword').val();
                var onionIdMasterPassRequest = {
                    "sdcode": sdcode,
                    "type": "Chrome Reset Master Password"
                }

                OnionIDLog("Masterpass Verified");

                $.ajax({
                    type: "POST",
                    url: theServer + "/v1/user/update/masterpass",
                    dataType: "json",
                    data: onionIdMasterPassRequest,
                    context: document.body,
                    success: function (response) {
                            OnionIDLog("Masterpass updated!");
                            $('#errorMessage').html("An email has been sent.");
                            $('#errorMessage').css("color", "green");
                            $('#errorMessage').css("visibility", "visible");
                    },
                    error: function(err) {
                        $('#errorMessage').html("Could not update masterpass.");
                        $('#errorMessage').css("color", "red");
                        $('#errorMessage').css("visibility", "visible");
                    }
                });
            });
        });
        });

    });
}

function updateAllowedOrNot() {
     chrome.storage.local.get("global_masterpass", function (obj) {
            if(!jQuery.isEmptyObject(obj)) {
                OnionIDLog("The global masterpass flag is " + obj.global_masterpass);
                if(obj.global_masterpass === 1) {
                    $('#onionIDupdateMasterPass').css('display','none');
                }
            }
            else {
            }
    });
}


function makePolicyPopup(policy, accounts, displayName, request, callback, autologin, special_url, blockedElement) {
    OnionIDLog(`makePolicyPopup() policy: ` + JSON.stringify(policy));
    $('body').append(overlay);

    var application_popup_file = 'html/onionid-application-popup.html';
    var policy_popup_url = 'html/onionid-policy-popup-new.html';

    // Only for cloudflare
    if (findApp(currentUrl) == 'cloudflare') {
        application_popup_file = 'html/onionid-application-popup-svg.html';
        policy_popup_url = 'html/onionid-policy-popup-new-svg.html';
    }

    $.get(chrome.extension.getURL(application_popup_file), function (result) {
        $('body').append(result);

        // Only for cloudflare
        if (findApp(currentUrl) == 'cloudflare') {
            addSvgImageCode('onionID_logo');
            addSvgImageCode('onionIDBypass');
        }

        if (autologin == 1) {
            $('.onionID_message').html('Logging you in automatically in ' + autologin_seconds + ' seconds... (press space to skip, or h to halt the process)');
            autologinCountdown(autologin_seconds);
        }
        $('.onionID_website').html(displayName);
        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        //$('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.gif"));
        $('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.svg"));
    });

    $.get(chrome.extension.getURL(policy_popup_url), function(result) {
        $('body').append(result);
        currentPolicy = parseInt(policy);
        switch(currentPolicy) {
            case 1:
                //$('.onionID_policy_image').attr('src', chrome.extension.getURL("img/TouchID.png"));
                $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/fingerprint-24px.svg"));
                $('.onionID_policy_text').html('Use TouchID');
                $('.onionID_policy_image').attr('title', 'TouchID authenticates users by their fingerprint (applies only to iPhones 5S and later).');
                $('.onionID_policy_text').attr('title', 'TouchID authenticates users by their fingerprint (applies only to iPhones 5S and later).');
                $('.onionID_policy_text').attr('class', 'policy_text_white');
                
                // Only for cloudflare
                if (findApp(currentUrl) == 'cloudflare') {
                    //addSvgImageCode('onionID_policy_image', 'touchid');   // Commenting: new touchId svn img found
                    $('.onionID_policy_image_imgtag').attr('src', chrome.extension.getURL("img/fingerprint-24px.svg"));                    
                } else {
                    // No tooltip for cloudflare as it affects login
                    $('.onionID_policy_image').tooltip({
                        track: true
                    });
                    $('.onionID_policy_text').tooltip({
                        track: true
                    });
                }
                break;
            case 2:
                $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/AirSign.png"));
                $('.onionID_policy_text').html('use Airshake');
                $('.onionID_policy_text').attr('class', 'policy_text_white');
                
                // Only for cloudflare
                if (findApp(currentUrl) == 'cloudflare') {
                    addSvgImageCode('onionID_policy_image', 'airsign');
                }
                break;
            case 4:
                $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/GeoFencing.png"));
                $('.onionID_policy_text').html('use GeoFencing');
                $('.onionID_policy_text').attr('class', 'policy_text_white');
                $('.onionID_info').attr('src', chrome.extension.getURL("img/download.png"));
                $('.onionID_info').css('display', 'inline');
                $('.onionID_policy_image').attr('title', 'Geofencing validates that users are within a predefined geological area.');
                $('.onionID_policy_text').attr('title', 'Geofencing validates that users are within a predefined geological area.');
                $('.onionID_info').attr('title', 'Geofencing validates that users are within a predefined geological area.');

                // Only for cloudflare
                if (findApp(currentUrl) == 'cloudflare') {
                    addSvgImageCode('onionID_policy_image', 'geofencing');
                    addSvgImageCode('onionID_info');
                } else {
                    // No tooltip for cloudflare as it affects login
                    $('.onionID_info').tooltip({
                        track: true
                    });
                    $('.onionID_policy_image').tooltip({
                        track: true
                    });
                    $('.onionID_policy_text').tooltip({
                        track: true
                    });
                }
                break;
            case 5:
                $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/GeoProximity.png"));
                $('.onionID_policy_text').html('use GeoProximity');
                $('.onionID_policy_text').attr('class', 'policy_text_white');
                $('.onionID_info').attr('src', chrome.extension.getURL("img/download.png"));
                $('.onionID_info').css('display', 'inline');
                $('.onionID_policy_image').attr('title', 'Geoproximity uses the location of the phone to verify that users are next to their computer.');
                $('.onionID_policy_text').attr('title', 'Geoproximity uses the location of the phone to verify that users are next to their computer.');
                $('.onionID_info').attr('title', 'Geoproximity uses the location of the phone to verify that users are next to their computer.');
                
                // Only for cloudflare
                if (findApp(currentUrl) == 'cloudflare') {
                    addSvgImageCode('onionID_policy_image', 'geoproximity');
                    addSvgImageCode('onionID_info');
                } else {
                    // No tooltip for cloudflare as it affects login
                    $('.onionID_info').tooltip({
                        track: true
                    });
                    $('.onionID_policy_image').tooltip({
                        track: true
                    });
                    $('.onionID_policy_text').tooltip({
                        track: true
                    });
                }
                break;
            case 8:
                $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/duoLogo-web.png"));
                $('.onionID_policy_text').html('use Duo');
                $('.onionID_policy_text').attr('class', 'policy_text_white');
                $('.onionID_info').attr('src', chrome.extension.getURL("img/download.png"));
                $('.onionID_info').css('display', 'inline');
                $('.onionID_policy_text').attr('class', 'policy_text_white');
                // Only for cloudflare
                if (findApp(currentUrl) == 'cloudflare') {
                    addSvgImageCode('onionID_policy_image', 'duologo');
                    addSvgImageCode('onionID_info');
                }
                break;
            case 9:
                // Ping ID
                $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/PingID.svg"));
                $('.onionID_policy_text').html('use PingID');
                $('.onionID_policy_text').attr('class', 'policy_text_white');
                $('.onionID_info').css('display', 'none');
                
                /* 
                 * Set fallback limit to 1 min for PingID 
                 * API calls may delay the process
                 * If device is unreachable, there will be a second call for OTP auth
                 */
                fallback_limit = 60;

                // Only for cloudflare
                if (findApp(currentUrl) == 'cloudflare') {
                    addSvgImageCode('onionID_policy_image', 'pingid-logo');
                    addSvgImageCode('onionID_info');
                }
                break;
            case 11:
                // OKTA
                $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/okta-verify-logo.png"));
                $('.onionID_policy_text').html('use OKTA');
                $('.onionID_policy_text').attr('class', 'policy_text_white');
                $('.onionID_info').css('display', 'none');

                /*
                 * Set fallback limit to 1 min for OKTA
                 * API calls may delay the process
                 */
                fallback_limit = 60;
                break;
        }
        if (fallback && !autologin) {
            $('.onionID_message').html('Waiting for Mobile Authentication - Fallback in 30 seconds');
            $('.onionID_MainBody').append('<a id="onionID_masterpass_message"  class="thy_light_text"  href="#" title="Fall back allows you to login even if none of the above techniques are available on your phone - please enter you master password that you have registered with Thycotic Access Controller during the installation process">What is fallback?</a>');

            // No tooltip for cloudflare as it affects login
            if (findApp(currentUrl) != 'cloudflare') {
                $('#onionID_masterpass_message').tooltip({
                    track: true
                });
            }
        }

        // For cloudflare only
        if (findApp(currentUrl) == 'cloudflare') {
            //addSvgImageCode('onionID_logo');  // SVG format new logo available which can be used directly
            $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
            addSvgImageCode('onionID_loading_bar');
            addSvgImageCode('onionIDBypass');
        } else {
            //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
            $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
            $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
            //$('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.gif"));
            $('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.svg"));
            $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
            $('.onionID_info').attr('src', chrome.extension.getURL("img/download.png"));
        }

        addBypassButton();
        OnionIDLog("AUTOLOGIN IS " + autologin);
        if(autologin == 0) {
            setTimeout(function() {
                $('#onionID_application_popup').css('display','none');
                $('#onionID_application_popup').remove();
                $('#onionID_policy_popup').css('display','block');
                $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
            }, 2500)
        }


        if(autologin) {
            $('#onionID_choose_account').css('display','block');
            $('#onionID_choose_action').css('display','block');
        }

        OnionIDLog("The accounts length is " + accounts.length);
        if(accounts.length > 0 && !blockedElement) {
            $.each(accounts, function (key, account) {
                if(account.username.length>20) {
                    wellFormedAccount = account.username.substring(0,19);
                    wellFormedAccount+="...";
                }
                else {
                    wellFormedAccount = account.username;
                }
                $('#onionID_choose_account select').append('<option value="' + account.id + '">' + wellFormedAccount + '</option>')
            });
            account = $( "#onionID_choose_account select option").first().val();
            $( "#onionID_choose_account select" )
            .change(function () {
                account = $( "#onionID_choose_account select option:selected" ).val();
            });

            $( "#onionID_choose_action select" )
            .change(function () {
                action = $( "#onionID_choose_action select option:selected" ).val();
                actionInt = parseInt(action);
                OnionIDLog("Action changed to " + actionInt);
                //If autologin don't change the message and keep countdown
                if(autologin)
                    actionInt = 0;

                switch(actionInt) {
                    case 1:
                        $('.onionID_message').html('Waiting for Mobile Authentication...');
                        $('.onionID_message').css('color','white');
                        break;
                    case 2:
                        $('.onionID_message').html('Authenticate with your phone to add an account');
                        $('.onionID_message').css('color','#2ECC40');
                        break;
                    case 3:
                        $('.onionID_message').html('Authenticate with your phone to update the account');
                        $('.onionID_message').css('color','#2ECC40');
                        break;
                    case 4:
                        $('.onionID_message').html('Authenticate with your phone to delete the account');
                        $('.onionID_message').css('color','#FF4136');
                        break;
                    default:
                        break;
                }
            });

        }
        else {
            $('#onionID_choose_account').css('display','none');
            $('#onionID_choose_action').css('display','none');
            $('#onionID_choose_account').remove();
            $('#onionID_choose_action').remove();
        }

        if(accounts.length <= 1) {
            $('#onionID_choose_account').css('display','none');
        }

        $('#onionID_policy_popup').draggable({
                start: function () {
                }
            }
        );

        //if we have autologin let {autologin_seconds} seconds for user to choose account or do other action
        if(autologin) {
            callback(autologin_seconds * 1000, request, special_url, autologin, accounts, blockedElement);
            $(document).keypress(function(event) {
                OnionIDLog(event.which);
                if ( event.which == 32 ) {
                    OnionIDLog("PRESSED space");
                    callback(0, request, special_url, autologin, accounts, blockedElement);
                }
                if ( event.which == 104 ) {
                    OnionIDLog("PRESSED h");
                    stopLogin = true;
                    setTimeout(function() {
                    $('.onionID_message').html('<a id="OnionIDClickToVerify" style="cursor:pointer;"> Click when ready to perform your action </a>');
                    $('#OnionIDClickToVerify').click(function() {
                        stopLogin = false;
                        callback(0, request, special_url, autologin, accounts, blockedElement);
                    });
                    }, 500);
                    OnionIDLog(stopLogin);
                }
            });
            //theCallback = callback(0, request, special_url, autologin, accounts, blockedElement);
            //document.onkeydown = OnionIDAutologinKeyPress;
        }
        else
            callback(1000, request, special_url, autologin, accounts, blockedElement);

        if(fallback && !autologin) {
            fallbackCountdown(1000, accounts, blockedElement);
        }

    });
}

/**
 * Replace image in the given element with corresponding SVG image code
 *
 * @param {string} imageElementClass
 * @param {string} imageName
 * @returns {boolean}
 */
function addSvgImageCode(imageElementClass, imageName) {
    var svgImageFile = '';

    // Use files specific to each image
    switch (imageElementClass) {
        case 'onionID_logo':
            svgImageFile = 'html/svg/onionid-logo.html';
            break;

        case 'onionIDBypass':
            svgImageFile = 'html/svg/onionid-x-button.html';
            break;

        case 'onionID_policy_image':
            svgImageFile = 'html/svg/onionid-' + imageName + '.html';
            break;

        case 'onionID_info':
            svgImageFile = 'html/svg/onionid-download.html';
            break;

        case 'onionID_loading_bar':
            svgImageFile = 'html/svg/onionid-loading.html';
            break;

        default:
            break;
    }

    // Return if image file is not given
    if(svgImageFile == '') {
        return true;
    }

    $.get(chrome.extension.getURL(svgImageFile), function (image) {
        $('div.' + imageElementClass).html(image);
    });

    return true;
}

function fallbackCountdown(timeout, accounts, blockedElement) {
    fallback_seconds++;
    if(!stop) {
    setTimeout(
        function() {
            if(fallback_seconds == fallback_limit)
                showMasterPassPopupWithAccounts(accounts, blockedElement);
            else{
                var auth_form = ($('#onionOTPForm').length) ? 'OTP' : 'Mobile';
                $('.onionID_message').html('Waiting for ' + auth_form + ' Authentication - Fallback in ' + (fallback_limit - fallback_seconds) + ' seconds');
                fallbackCountdown(timeout, accounts, blockedElement);
            }
        }, timeout
        );
    }
}

function autologinCountdown(seconds) {
    if (seconds >= 0) {
        setTimeout( function() {
            if(!stopLogin) {
                $('.onionID_message').html('Logging you in automatically in ' + seconds + ' seconds... (press space to skip, or h to halt the process)');
                autologinCountdown(seconds - 1);
            }
        }, 1000);
    }
}

function popupDelayCountdown(seconds) {
    if (seconds >= 0) {
        setTimeout( function() {
            $('#onionID_top_bar_delay_message').html('Please fill in the CAPTCHA before proceeding to automatic login. You have ' + seconds + ' seconds remaining...');
            popupDelayCountdown(seconds - 1);
        }, 1000);
    } else {
        $('#onionID_top_bar').hide();
    }
}

function showTopDelayBanner() {
    $.get(chrome.extension.getURL('html/onionid-top-popup-delay-banner.html'), function(result) {
        $('body').append(result);
    });
}


function showInstallationChoice() {
    $.get(chrome.extension.getURL('html/onionid-installation-choice-popup.html'), function(result) {
        $('body').append(result);
        $('body').append(overlay);
//        $('.onionID_blue_popup').css('background-image', 'url('+chrome.extension.getURL("img/background.jpg")+')' )
//        $('.onionID_logo_centered').attr('src', chrome.extension.getURL("img/logo_centered.png"));
        $('.onionID_logo_centered').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));


        $("#onionInstallChoiceSubmit").on('click', function (event) {
            var bulk = $("#sdcode_exists").is(':checked') == true ? 1 : 0;
            if(!bulk)
                begin_register_process();
            else
                bulk_register_process();
        });
    });
}




//reCaptchaDaemon();

function reCaptchaDaemon() {
    OnionIDLog(window.location.href);
 setTimeout(function() {
        OnionIDLog("Check recaptcha");
        OnionIDLog($('#recaptcha-checkbox-checkmark'));
        $('#recaptcha-checkbox-checkmark').click();
        reCaptchaDaemon();
    }, 2000);
}

if(window.isTop) {
    OnionIDLog("THIS IS TOP FRAME");
}
else {
    OnionIDLog("This is not the TOP FRAME");
}

function setBlockedElementAttributes(blockedElement) {
    // Return if this is set once
    if (blockedElement.Custom != undefined) {
        return true;
    }
    blockedElement.Custom = {};
    try {
        let customAttrs = {
            "ElementXPath": "be-xpath",
            "ElementRegexId": "be-regex-id",
            "ElementRegexClass": "be-regex-class",
            "ElementDoContentMatch": "be-do-content-match",
            'ElementIgnoreId': "be-ignore-id",
            'ElementIgnoreHref': "be-ignore-href",
            'ElementIgnoreValue': "be-ignore-value",
            'ElementSearchMethod': "be-search-method",
        }
        for (let attr in customAttrs) {
            blockedElement.Custom[attr] = $(blockedElement.content).attr(customAttrs[attr]);
            if (blockedElement.Custom[attr] === undefined) {
                blockedElement.Custom[attr] = "";
            }
        }
        blockedElement.Custom.ElementId = blockedElement.id;
        blockedElement.Custom.ElementName = blockedElement.name;
        blockedElement.Custom.ElementType = blockedElement.type;

        blockedElement.Custom.Html = $(blockedElement.content).html();
        blockedElement.Custom.Text = $(blockedElement.content).text();
        if ($(blockedElement.content).prop("tagName")) {
            blockedElement.Custom.Tag = $(blockedElement.content).prop("tagName").toLowerCase();
        }
        blockedElement.Custom.Class = $(blockedElement.content).attr("class");
        blockedElement.Custom.Value = $(blockedElement.content).val();
        blockedElement.Custom.Type = $(blockedElement.content).attr("type");

        if (blockedElement.Custom.Class == undefined || blockedElement.Custom.Class == "") {
            blockedElement.Custom.Class = "";
        } else {
            let classes = (blockedElement.Custom.Class).split(/\s+/);
            blockedElement.Custom.Class = "";

            // Get each classname excluding extra spaces
            $.each(classes, function (index, cls) {
                cls = cls.trim();
                blockedElement.Custom.Class += (cls != "") ? ("." + cls) : "";
            });
        }
        blockedElement.Custom.Id = $(blockedElement.content).attr("id");

        // Set ID to empty if regex check is required
        if (blockedElement.Custom.Id == undefined || blockedElement.Custom.Id == "" || blockedElement.Custom.ElementIgnoreId == "true" || blockedElement.Custom.ElementRegexId != "") {
            blockedElement.Custom.Id = "";
        } else {
            blockedElement.Custom.Id = "#" + blockedElement.Custom.Id;
        }
        blockedElement.Custom.Href = $(blockedElement.content).attr("href");

        if (blockedElement.Custom.Href == undefined || blockedElement.Custom.Href == "" || blockedElement.Custom.ElementIgnoreHref == "true") {
            blockedElement.Custom.Href = "";
        } else {
            blockedElement.Custom.Href = '[href="' + blockedElement.Custom.Href + '"]';
        }
        if (blockedElement.Custom.Type == undefined || blockedElement.Custom.Type == "") {
            blockedElement.Custom.Type = "";
        } else {
            blockedElement.Custom.Type = '[type="' + blockedElement.Custom.Type + '"]';
        }
        if (blockedElement.Custom.Value == undefined || blockedElement.Custom.Value == "" || blockedElement.Custom.ElementIgnoreValue == "true") {
            blockedElement.Custom.Value = "";
        } else {
            blockedElement.Custom.Value = ':input[value="' + blockedElement.Custom.Value + '"]';
        }
    } catch (e) {
        OnionIDLog("Js exeception in function getBlockedElementAttributes");
        OnionIDLog(e.stack);
        OnionIDLog(blockedElement);
        OnionIDLog(blockedElement.Custom);
    }
    return true;
}

function searchElementWithAttributes(blockedElement, theQueryString) {
    let theDOMElement = null;
    let canDoContentMatch = false;
    if ((aggressiveHeuristic || blockedElement.Custom.ElementDoContentMatch == "true") && blockedElement.Custom.ElementDoContentMatch != "false") {
        canDoContentMatch = true;
    }
    try {
        let message = "";
        let tagAndClass = blockedElement.Custom.Tag + blockedElement.Custom.Class;
        let theQueryString = blockedElement.Custom.Tag + blockedElement.Custom.Id + blockedElement.Custom.Class + blockedElement.Custom.Href + blockedElement.Custom.Type + blockedElement.Custom.Value;
        // Query with tag and class only is too open. So, do content matching
        if (theQueryString == tagAndClass && canDoContentMatch) {
            theQueryString += ':contains("' + blockedElement.Custom.Text + '")';
        }
        // First round search
        theDOMElement = $('body').find(theQueryString);
        if (!theDOMElement || theDOMElement === null || theDOMElement.length === 0) {
            let elementId = (blockedElement.Custom.ElementIgnoreId != 'false') ? "" : blockedElement.Custom.Id;
            let elementHref = (blockedElement.Custom.ElementIgnoreHref != 'false') ? "" : blockedElement.Custom.Href;
            theQueryString = blockedElement.Custom.Tag + elementId + blockedElement.Custom.Class + elementHref + blockedElement.Custom.Type + blockedElement.Custom.Value;
            // Query with tag and class only is too open. So, do content matching
            if (theQueryString == tagAndClass && canDoContentMatch) {
                theQueryString += ':contains("' + blockedElement.Custom.Text + '")';
            }
            // Second round search
            theDOMElement = $('body').find(theQueryString);
        }
        if (theDOMElement && theDOMElement.length > 0) {
            blockedElement.Custom.ElementSearchMethod = 'attributes';
            OnionIDLog('Processing blocked element => ' + blockedElement.Custom.ElementName
                    + ': Located the element using attributes. AttributeQuery: ' + theQueryString + message
                    + '. Iteration: ' + blockedElement.Custom.ElementSearchIteration);
            return theDOMElement;
        }
    } catch (e) {
        OnionIDLog(blockedElement.Custom);
        OnionIDLog("Js exeception in function findElementWithAttributes. Element: " + blockedElement.Custom.ElementName);
        OnionIDLog(e.stack);
    }
    return null;
}

function searchElementWithRegex(blockedElement) {
    let theQueryString = blockedElement.Custom.Tag + blockedElement.Custom.Id + blockedElement.Custom.Class + blockedElement.Custom.Href + blockedElement.Custom.Type + blockedElement.Custom.Value;
    try {
        let theDOMElement = $(document).find(theQueryString);
        let message = "";
        if (!theDOMElement || theDOMElement === null || theDOMElement.length === 0) {
            return theDOMElement; // Return if no element found
        }
        try {
            // Check for 'id' match. if id regex is given
            if (blockedElement.Custom.ElementRegexId !== "") {
                let regex = new RegExp(blockedElement.Custom.ElementRegexId, 'ig');
                if (!$(theDOMElement).attr('id').match(regex)) {
                    return null;// iF no match is found, then return
                }
            }
            // Check for 'class' match. if id regex is given for ANY OF THE class
            if (blockedElement.Custom.ElementRegexClass !== "") {
                let classFound = false;
                let classes = $(theDOMElement).attr("class");
                let classNames = classes.split(/\s+/);
                let regex = new RegExp(blockedElement.Custom.ElementRegexClass, 'ig');
                for (let eachClass in classNames) {
                    if (eachClass.match(regex)) {
                        classFound = true;
                        break;
                    }
                }
                // If the specific class is not found, then return null
                if (!classFound) {
                    return null;
                }
            }
        } catch (e) {
            OnionIDLog(blockedElement.Custom);
            OnionIDLog("Js exeception in function doElementAttributeRegexMatch. Element: " + blockedElement.Custom.ElementName);
            OnionIDLog(e.stack);
            theDOMElement = null;
        }
        // If aggressiveHeuristic is set in BE or the custom attr be-do-content-match="true" is set in element code
        // We can use the custom attr be-do-content-match="false", to avoid the content check
        if ((aggressiveHeuristic || blockedElement.Custom.ElementDoContentMatch == "true") && blockedElement.Custom.ElementDoContentMatch != "false") {
            // Content mismatch
            if ($(theDOMElement).text().trim() != blockedElement.Custom.Text.trim()) {
                theDOMElement = null;
            } else {
                message = '. Content: ' + blockedElement.Custom.Html;
            }
        }
        if (theDOMElement !== null && theDOMElement && theDOMElement.length > 0) {
            blockedElement.Custom.ElementSearchMethod = 'regex';
            OnionIDLog('Processing blocked element => ' + blockedElement.Custom.ElementName
                    + ': Located the element using Regex. ElementRegexId: ' + blockedElement.Custom.ElementRegexId
                    + '. ElementRegexClass: ' + blockedElement.Custom.ElementRegexClass + message
                    + '. Iteration: ' + blockedElement.Custom.ElementSearchIteration);
        }
    } catch (e) {
        OnionIDLog(blockedElement.Custom);
        OnionIDLog("Js exeception in function findElementWithRegex. Element: " + blockedElement.Custom.ElementName);
        OnionIDLog(e.stack);
        theDOMElement = null;
    }
    return theDOMElement;
}

function searchElementWithXPath(blockedElement) {
    let theDOMElement = null;
    try {
        let XPath = blockedElement.Custom.ElementXPath;
        // If the custom attr be-do-content-match="true" is set in element code, check content also
        if (blockedElement.Custom.ElementDoContentMatch == "true") {
            XPath = (blockedElement.Custom.ElementXPath + "[contains(text(),'" + blockedElement.Custom.Text + "')]");
        }
        let XPathResult = document.evaluate(XPath, document, null, 5, null); // (XPathResult.ORDERED_NODE_ITERATOR_TYPE = 5)
        theDOMElement = $(XPathResult.iterateNext());
        if (theDOMElement !== null && theDOMElement && theDOMElement.length > 0) {
            blockedElement.Custom.ElementSearchMethod = 'xpath';
            OnionIDLog('Processing blocked element => ' + blockedElement.Custom.ElementName
                    + ': Located the element using XPath. XPath: ' + blockedElement.Custom.ElementXPath
                    + '. Iteration: ' + blockedElement.Custom.ElementSearchIteration);
        }
    } catch (e) {
        OnionIDLog(blockedElement.Custom);
        OnionIDLog("Js exeception in function findElementWithXPath. Element: " + blockedElement.Custom.ElementName);
        OnionIDLog(e.stack);
    }
    return theDOMElement;
}

function findTheBlockedElement(blockedElement, allow) {
    // If the window is not active, then, stop this iteration
    if (!windowIsVisible) {
        blockedElement = null;
        return;
    }
    let theDOMElement = null;
    if (blockedElement.id === undefined) {
        return;
    }
    setBlockedElementAttributes(blockedElement);
    OnionIDLog('Processing blocked element => ' + blockedElement.Custom.ElementName + '. Element is not yet located!. Using method: ' + blockedElement.Custom.ElementSearchMethod);
    if (blockedElement.Custom.ElementId === "") {
        return;
    }
    // Return, if element is found (iteration is locked)
    if (blockedElement.Custom.ElementSearchHit !== undefined) {
        return;
    }
    // Save search iteration value (needed for debugging)
    blockedElement.Custom.ElementSearchIteration = (blockedElement.Custom.ElementSearchIteration !== undefined) ? (parseInt(blockedElement.Custom.ElementSearchIteration) + 1) : 1;

    // Follow the search method (either set in saved element or automatically detected by the code in prev iteration)
    switch (blockedElement.Custom.ElementSearchMethod) {
        case 'xpath':
            theDOMElement = searchElementWithXPath(blockedElement);
            break;
        case 'attributes':
            theDOMElement = searchElementWithAttributes(blockedElement);
            break;
        case 'regex':
            theDOMElement = searchElementWithRegex(blockedElement);
            break;
        default:

            // Try with XPath first (unless the element was located with another method in previous search iteration)
            if (blockedElement.Custom.ElementXPath !== "") {
                theDOMElement = searchElementWithXPath(blockedElement);
            }

            // Try with attributes, if the element is not found with XPath
            if ((theDOMElement === null || theDOMElement.length === 0)) {
                theDOMElement = searchElementWithAttributes(blockedElement);
            }

            // Try with regex, if we didn't find the element with static attribute values
            if ((theDOMElement === null || theDOMElement.length === 0)) {

                // Check if it is an element with dynamic attribute values to be checked using regex
                if (blockedElement.Custom.ElementRegexId !== "" || blockedElement.Custom.ElementRegexClass !== "") {
                    theDOMElement = searchElementWithRegex(blockedElement);
                }
            }
            break;
    }

    // Do blocking actions if element is found and do it only once (The attribute 'be-blocked-id' is set, if actions are done once)
    if (theDOMElement !== null && theDOMElement.length > 0) {
        if ($(theDOMElement).attr('be-blocked-id') === undefined) {
            blockElementActions(theDOMElement, blockedElement, allow);
        }
        // Save the locked iteration value
        blockedElement.Custom.ElementSearchHit = blockedElement.Custom.ElementSearchIteration;
    }

    // If you did not find the element it might have been because it hasn't loaded or created yet.
    // Set delay to 1 second for dynamic elements, because there could an action involved and we can take some time to find it
    if (theDOMElement === null || theDOMElement.length === 0) {
        setTimeout(function () {
            findTheBlockedElement(blockedElement, allow);
        }, ((blockedElement.Custom.ElementSearchIteration > 1) ? 1000 : 500));
    }
    theDOMElement = null;
}

function blockElementActions(theElement, blockedElement, allow) {
    let savedHtml = "";
    setBlockedElementAttributes(blockedElement);
    try {
        let blockedElementType = blockedElement.Custom.ElementType;
        // Show blocked banner
        if (blockMessageShown == 0 && allow) {
            onionIdBlockMessage();
            blockMessageShown = 1;
        }
        // Allow element
        if (allow) {
            theElementList.push(theElement);
        }
        if (blockedElementType == "text") {
            savedHtml = theElement.html();
            theElement.html("Text protected by Thycotic Access Controller");
            foundAnElement(allow);
        } else if (isFormBlock(theElement)) {
            theElement.css('opacity', 0);
            addAnOverlay(theElement, allow);
            foundAnElement(allow);
        }
        if (allow) {
            savedHtmls.push(savedHtml);
        }
        if (blockedElementType == "button") {
            foundAnElement(allow);
            theElement.css("cursor", "default");
            theElement.attr('title', 'Protected by Thycotic Access Controller - Please click the black bar at the top of the page to request access, and then check your phone application for any MFA request on the Thycotic Access Controller app.');
            theElement.tooltip({
                track: true,
            });
            $(theElement).on('click, mousedown', function (e) {
                theElement.tooltip('close');
                e.preventDefault();
                e.stopPropagation();
                //do other stuff when a click happens
                alert("Element protected by Thycotic Access Controller");
            });
        }
        // Restart element find call, once the element is removed.
        $(theElement).on('DOMNodeRemovedFromDocument', function (e) {
            // Unset the locked iteration
            blockedElement.Custom.ElementSearchHit = undefined;
            setTimeout(function () {
                findTheBlockedElement(blockedElement, allow);
            }, 500);
        });

        $(theElement).attr('be-blocked-id', blockedElement.Custom.ElementId); // Add attr to DOM element itself. Checked before binding the blocking actions.
        $(theElement).attr('be-blocked-type', blockedElementType); // Add attr to DOM element itself. Checked on right click.
    } catch (e) {
        OnionIDLog(blockedElement.Custom);
        OnionIDLog("Js exeception in function blockElementActions. Element: " + blockedElement.Custom.ElementName);
        OnionIDLog(e.stack);
    }
}

function findInput(inputElement) {
    var inputHtml = $(inputElement).html();
    var inputTag = $(inputElement).prop("tagName").toLowerCase();
    var inputClass = $(inputElement).attr("class");
    OnionIDLog(inputClass);
     if(inputClass == null || inputClass == "") {
        inputClass = "";
    } else {
        inputClass = "." + inputClass.trim();
        inputClass = inputClass.replace(/ /g, ".");
        OnionIDLog("inputclass is " + inputClass);
    }
    inputId = $(inputElement).attr("id");
    if(inputId == null || inputId == "") {
        inputId = "";
    } else {
        inputId = "#" + inputId;
    }
    inputType = $(inputElement).attr("type");
    if(inputType == null || inputType == "") {
        inputType = "";
    } else {
        inputType = '[type="' + inputType + '"]';
    }
    inputHref = $(inputElement).attr("href");
    if(inputHref == null || inputHref == "") {
        inputHref = "";
    }
    else {
        inputHref = '[href="' + inputHref + '"]';
    }

    inputValue = $(inputElement).attr("value");
    if(inputValue == null || inputValue == "") {
        inputValue = "";
    }
    else {
        inputValue = ':input[value="'+ inputValue +'"]';
    }
    OnionIDLog(inputTag + inputId + inputClass + inputHref);
    var theInputElement = $('body').find(inputTag + inputId + inputClass + inputHref + inputType + inputValue);
    return theInputElement;
}

function foundAnElement(allow) {
    if(allow)
        foundAuthenticatableElement = true;
    else
        foundRestrictedElement = true;
}

function isTextBlock(theElement) {
    var tagName = theElement.prop("tagName").toLowerCase();
    if( tagName == "p" || tagName == "h1" || tagName == "h2"  || tagName == "h3"  || tagName == "h4"  || tagName == "h5"  || tagName == "h6") {
        return true;
    } else {
        return false;
    }
}

function isFormBlock(theElement) {
     var tagName = theElement.prop("tagName").toLowerCase();
     if( tagName == "form" ) {
        return true;
     } else {
        return false;
     }
}

function getBlockedElementsList() {

    FetchElementsRequest =  {
        "url": currentUrl,
        "sdcode": sdcode,
        "full_domain": window.location.host,
        "type": "Chrome Fetch Restricted Element List"
    };

    $.ajax({
        type: "POST",
        url: theServer,
        dataType: "json",
        data: JSON.stringify(FetchElementsRequest),
        context: document.body,
        timeout: globalTimeout,
        success: function (response) {
            OnionIDLog(response);
            currentTime = Date.now();
            if(response != null && response != []) {
                parseElementList(response);
            }
        },
        error: function(x, t, m) {
            if (t === "timeout") {
                OnionIDLog("Thycotic Access Controller: Element List Timeout!");
            } else {
                OnionIDLog(m);
            }
        }
    })

}

function parseElementList(restrictedElementList) {

    FetchElementsRequest =  {
        "url": currentUrl,
        "sdcode": sdcode,
        "full_domain": window.location.host,
        "type": "Chrome Fetch Element List"
    };

     $.ajax({
        type: "POST",
        url: theServer,
        dataType: "json",
        data: JSON.stringify(FetchElementsRequest),
        context: document.body,
        timeout: globalTimeout,
        success: function (response) {
            currentTime = Date.now();
            if(response != null) {
                var authenticatableElementList = response;

                //if only restricted elements exist show popup to request access
                /*if(authenticatableElementList.length == 0 && restrictedElementList.length != 0) {
                    OnionIDLog("here access bar");
                    showRequestAccessBar();
                } */

                var lookup = [];
                for (var i = 0, len = authenticatableElementList.length; i < len; i++) {
                    lookup.push(authenticatableElementList[i].id);
                }
                OnionIDLog(lookup);
                 $.each(restrictedElementList, function(index, element) {
                    if(lookup.indexOf(element.id) > -1)
                        findTheBlockedElement(element, true);
                    else
                        findTheBlockedElement(element, false);
                });
                 if(!foundAuthenticatableElement && foundRestrictedElement) {
                    OnionIDLog("here access bar");
                    showRequestAccessBar("Thycotic Access Controller: If you want to request access, click here.");
                 }
            }
            else {
            }
        },
        error: function(x, t, m) {
            if (t === "timeout") {
                OnionIDLog("Authenticatable Element List Timeout!");
            } else {
                OnionIDLog(m);
            }
        }
    })
}

function showElementSavePopup(type) {
    chrome.storage.local.get("lastRightClickedElement", function (obj) {
        lastRightClickedElement = obj.lastRightClickedElement;
        OnionIDLog(lastRightClickedElement);
        // Invalid element selection
        if (lastRightClickedElement === null) {
            alert("This element cannot be blocked!");
            return false;
        }
        wellFormedElement = lastRightClickedElement.substring(0,30);
        wellFormedElement+="...";
        $.get(chrome.extension.getURL('html/onionid-save-element-popup.html'), function(result) {
            $('body').append(result);
            $('#onionID_element_save').text("Element source: " + wellFormedElement);
            addBypassButton();
            //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
            $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
            $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
            $('#onionSubmitElement').click(function() {
                var errFields = $('#onionID_element_advanced_form:visible .onionID_field_error');
                if (errFields.length) {
                    $('#errorMessage').html('Please correct your inputs.');
                    $('#errorMessage').show();
                    return;
                }
                theElementName = $('#onionIDelementName').val();
                $('#onionID_element_save_popup').remove();
                sendElementToServer(type, lastRightClickedElement, theElementName);
                lockContext = false;
            });
        });
    });
}

function sendElementToServer(type, lastRightClickedElement, theElementName) {
    saveElementRequest =  {
            "url": currentUrl,
            "element": lastRightClickedElement,
            "element_name": theElementName,
            "full_domain": window.location.host,
            "sdcode": sdcode,
            "type": "Chrome Save Element"
    };
    if(type!="form") {
        saveElementRequest.element_type = type;
    }

    $.ajax({
        type: "POST",
        url: theServer,
        dataType: "json",
        data: JSON.stringify(saveElementRequest),
        context: document.body
    });
}

function createTheContextMenu() {
    chrome.runtime.sendMessage ( {command: "createMenus"}, function (response) {
        OnionIDLog("successfully created menus");
    });
}

function removeTheContextMenu() {
    chrome.runtime.sendMessage ( {command: "removeMenus"}, function (response) {
        OnionIDLog("successfully removed menus");
    });
}

function addAnOverlay(theElement, allow) {
    var theTop = theElement.offset().top;
    var theLeft = theElement.offset().left;
    var theWidth = theElement.width();
    var theHeight = theElement.height();
    var theImageUrl = chrome.extension.getURL("img/thycotic-protected.svg");
    if(allow)
        $('html').append('<div class="onionID_blockelement_overlay" style="left:' + theLeft + 'px; top:' + theTop + 'px; width:' + theWidth + 'px; height:' + theHeight + 'px; background-image:url(' + theImageUrl + ');"> </div>')
    else
        $('html').append('<div class="onionID_blockelement_overlay_restrict" style="left:' + theLeft + 'px; top:' + theTop + 'px; width:' + theWidth + 'px; height:' + theHeight + 'px; background-image:url(' + theImageUrl + ');"> </div>')
}

function addTransparentOverlay(theElement, allow) {
    transparentOverlayId++;
    var theTop = theElement.offset().top;
    var theLeft = theElement.offset().left;
    var theWidth = theElement.width();
    var theHeight = theElement.height();
    if(allow)
        $('html').append('<div id="transparentOverlay' + transparentOverlayId + '" class="onionID_blockelement_overlay" style="left:' + theLeft + 'px; top:' + theTop + 'px; width:' + theWidth + 'px; height:' + theHeight + 'px; "> </div>');
    else
        $('html').append('<div id="transparentOverlay' + transparentOverlayId + '" class="onionID_blockelement_overlay_restrict" style="left:' + theLeft + 'px; top:' + theTop + 'px; width:' + theWidth + 'px; height:' + theHeight + 'px;"> </div>');

    $('#transparentOverlay'+transparentOverlayId).attr('title', 'Protected by Thycotic Access Controller - Please click the black bar at the top of the page to request access, and then check your phone application for any MFA request on the Thycotic Access Controller app.');
    $('#transparentOverlay'+transparentOverlayId).tooltip({
                  track: true
    });

}

function saveAppUsername(username, url) {
    var app = findApp(url);
    
    chrome.storage.sync.get("appUsernameList", function (obj) {
        var appUsernameList = {};
        OnionIDLog("checking existing appUsernameList");
        OnionIDLog(obj);
        
        if (jQuery.isEmptyObject(obj)) {
            appUsernameList[app] = username;
        } else {
            appUsernameList = obj.appUsernameList;
            appUsernameList[app] = username;
        }
      
        chrome.storage.sync.set({"appUsernameList": appUsernameList});
    });
}

/**
 * Display the OTP popup
 * 
 * @param {string} auth_service
 * @param {string} login_attempt
 * @param {array} accounts
 * @param {boolean} blockedElement
 * @returns {undefined}
 */
function showOTPPopup(auth_service, login_attempt, accounts, blockedElement) {
    OnionIDLog('showOTPPopup(' + auth_service + ', ' + login_attempt + ', ' + JSON.stringify(accounts) + ',' + blockedElement + ')');
    removePopups();

    var account = 'none';
    $.get(chrome.extension.getURL('html/onionid-otp-popup.html'), function (result) {
        $('body').append(result);
        $('body').append(overlay);
        //Toggle comment if you want OTP popup to disappear or not.
        //setTimeout(function() { removePopups(); }, 30 * 1000);

        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));


        if (auth_service == 'PingId OTP') {
            $('#onionIdOTPMessage').html('Your mobile device is unreachable for login authentication.<br>Please enter the OTP generated in your <span style="font-weight: bold;">Pin<span style="font-family: Times New Roman; font-size: 15px;">g</span><span style="background: #b8232f; color: white; font-style: italics; padding: 2px; margin-left: 1px;">ID</span></span> mobile application:');
        } else if (auth_service == 'OKTA TOTP') {
            $('#onionIdOTPMessage').html('Please enter the OTP generated in your <br /><span style="font-weight: bold;"><span><img src="' + chrome.extension.getURL("img/okta-logo.png") + '" style="height: 13px !important; width: auto !important;"></span> Verify</span> mobile application.');
        }
        addBypassButton();

        if (accounts.length > 0 && !blockedElement) {
            $.each(accounts, function (key, account) {
                if (account.username.length > 20) {
                    wellFormedAccount = account.username.substring(0, 19);
                    wellFormedAccount += "...";
                } else {
                    wellFormedAccount = account.username;
                }
                $('#onionID_choose_account select').append('<option value="' + account.id + '">' + wellFormedAccount + '</option>')
            });
            account = $("#onionID_choose_account select option").first().val();
            $("#onionID_choose_account select")
                .change(function () {
                    account = $("#onionID_choose_account select option:selected").val();
                });

            $("#onionID_choose_action select")
                .change(function () {
                    action = $("#onionID_choose_action select option:selected").val();
                    actionInt = parseInt(action);
                    OnionIDLog("Action changed to " + actionInt);
                });
            $('#onionID_choose_account').css('display', 'block');
            $('#onionID_choose_action').css('display', 'block');
        } else {
            $('#onionID_choose_account').css('display', 'none');
            $('#onionID_choose_action').css('display', 'none');
        }

        if (accounts.length <= 1) {
            $('#onionID_choose_account').css('display', 'none');
        }

        $('#onionIdOTP').focus();
        //$('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.gif"));
        $('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.svg"));
        $('#onionID_otp_popup').css('cursor', 'grabbing');
        $('#onionID_otp_popup').draggable();

        if (fallback) {
            $('.onionID_message').html('Waiting for Mobile Authentication - Fallback in 30 seconds');
            $('.onionID_MainBody').append('<a id="onionID_masterpass_message" class="thy_light_text" href="#" title="Fall back allows you to login even if none of the above techniques are available on your phone - please enter you master password that you have registered with Thycotic Access Controller during the installation process">What is fallback?</a>');
        }

        var api_method = "Browser Verify " + auth_service;

        $("#onionSubmitOTP").on('click', function () {

            if ($('#onionSubmitOTP').html() != "SUBMIT") {
                return;
            }

            OnionIDLog("#onionSubmitOTP.click() : " + api_method);

            // Hide error box, submit button and show loader
            $('#errorMessage').hide();
            $('#onionSubmitOTP').hide();
            $('.onionID_loading_bar').show();

            var otp = $('#onionIdOTP').val();
            var onionIdOTPRequest = {
                "otp": otp,
                "sdcode": sdcode,
                "url": currentUrl,
                "account": account,
                "login_attempt": login_attempt,
                "type": api_method
            };

            $.ajax({
                type: "POST",
                url: theServer,
                dataType: "json",
                data: JSON.stringify(onionIdOTPRequest),
                context: document.body,
                success: function (response) {
                    OnionIDLog(`#onionSubmitOTP.click().response: ` + JSON.stringify(response) + `, 'action': ${action}`);
                    if (response.response == "OTP Verified") {
                        stop = true;

                        if (blockedElement) {
                            authenticateElements();
                            return;
                        }

                        if (response.message == "register") {
                            showRegisterForm();
                        } else {
                            if (action == 1) {
                                OnionIDLog('#onionSubmitOTP.click().do_login()');
                                do_login(response.username, response.password);
                                setTimeout(function () {
                                    removePopups();
                                }, 2000);
                            } else if (action == 2) {
                                showRegisterForm();
                            } else if (action == 3) {
                                showRegisterForm("wrong");
                            } else if (action == 4) {
                                deleteAccount();
                            }
                        }
                    } else {
                        var custom_messages = {
                            "SETTINGS_NOT_FOUND": "OKTA Integration Details are missing. Please contact your Thycotic Access Controller administrator to update the OKTA properties and try again.",
                            "FACTOR_NOT_FOUND": "The specific OKTA authentication factor is not active.",
                            "USER_NOT_FOUND": "OKTA user not found.",
                            "INVALID_OTP": "Invalid OKTA OTP. Please try again."
                        };

                        var error_message = 'Something went wrong. Please try again.';
                        if (response.message in custom_messages) {
                            error_message = custom_messages[response.message];
                        } else if (response.message !== null && response.message !== undefined) {
                            error_message = response.message;
                        }

                        // Set fallback in 5 seconds, if fallback is enabled
                        if (fallback && fallback_seconds && fallback_limit && (fallback_limit - fallback_seconds > 0)) {
                            fallback_seconds = fallback_limit - 5;
                            error_message += ". Fallback in 5 seconds.";
                        }

                        onionIdSystemMessage('Error: ' + error_message);
                        OnionIDLog('Error: ' + response.message);
                    }
                }
            });

        });

        $("#onionIdOTP").keyup(function (event) {
            if (event.keyCode == 13) {
                $("#onionSubmitOTP").click();
            }
        });
    });
}

function getElementXPath(element, xpath) {
    try {
        var tagName = $(element).prop("tagName");
        var parent = $(element).parent();
        if (tagName === undefined) {
            return xpath;
        }
        var siblings = $(parent).children(tagName);
        var indexSelector = (siblings.length > 1) ? ("[" + (siblings.index(element) + 1) + "]") : "";
        xpath = "/" + tagName.toLowerCase() + indexSelector + xpath;
        if (parent != undefined && !parent.is(document)) {
            xpath = getElementXPath(parent, xpath);
        }
    } catch (e) {
        xpath = "";
        OnionIDLog(element);
        OnionIDLog("Js exeception in function getElementXPath.");
        OnionIDLog(e.stack);
    }
    return xpath;
}

var bannedUrlId;
//this load the AccessBar only for ban page
var banElement = document.getElementById("onionid-bg-black");
if (typeof(banElement) != 'undefined' && banElement != null)
{
  chrome.storage.sync.get( "sdcode", function (obj) {
    sdcode=obj.sdcode.val;
    startAuthenticationProcess(sdcode,false,false,true);
    banElement.addEventListener("load", showRequestAccessBar("Thycotic Access Controller: If you want to request access, click here."));
  });
}

$(document).on("contextmenu", function(e){
    if(!lockContext) {
        lockContext = false;
        lastRightClickedElement = e.target;
        if(e.target.tagName.toLowerCase() == "input" || e.target.tagName.toLowerCase() == "textarea") {
            if(e.target.type.toLowerCase() == "text" || e.target.type.toLowerCase() == "email" || e.target.type.toLowerCase() == "password") {
                lastRightClickedElement = e.target.form;
            }
        }
        // If the element is an input field and there is no parent form tag
        if (!lastRightClickedElement || lastRightClickedElement == null || lastRightClickedElement.length == 0) {
            chrome.storage.local.set({'lastRightClickedElement': null}, function () { });
            return true;
        }

        // Block right click also, for blocked elements of type 'button' (click is blocked)
        if ($(lastRightClickedElement).attr('be-blocked-type') === 'button' || $(lastRightClickedElement).parents('[be-blocked-type="button"]').length) {
            return false;
        }

        var elementXPath = getElementXPath(lastRightClickedElement, "");
        $(lastRightClickedElement).attr('be-xpath', elementXPath);

        chrome.storage.local.set({'lastRightClickedElement': lastRightClickedElement.outerHTML}, function() {
        });
    }
});