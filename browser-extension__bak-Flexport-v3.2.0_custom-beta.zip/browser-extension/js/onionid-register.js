function bulk_register_process() {
    validatePhoneForm("old", "");
}

function validatePhoneForm(type, email) {
    OnionIDLog("SHOWING VALIDATE");
    var custom_endpoint = false;
    $.get(chrome.extension.getURL('html/onionid-register-pin-popup.html'), function(result) {
        $('#onionID_register_popup').remove();
        $('body').append(result);



        if(type=="new") {
            $('#welcomeMessage').html('A <span style="color:white !important"> Registration Code </span> has been sent to ' + email + '.  <br> Please enter it below and in your Thycotic Access Controller <br> iPhone or Android app to confirm registration.');
        }
        else {
            $('#welcomeMessage').html('You have received a <span style="color:white !important"> Registration Code</span>. Please enter it below and in your Thycotic Access Controller iPhone or Android app to confirm registration.');
        }
        $('#onionID_overlay').remove();
        $('#errorMessage').html("Wrong Registration Code!");
        $('#errorMessage').css("visibility", "hidden");
        $('#onionID_register_pin_popup').draggable({
                start: function() {
                    $('.overlay').remove();
                }
            }
        );

        $("#onionIdSdcode").keyup(function(event){
            if(event.keyCode == 13){
                $("#validateSdcode").click();
            }
        });

        addBypassButton();

        $('#onionID_register_pin_popup').css('cursor','move');
        //$('.onionID_blue_popup').css('background-image', 'url('+chrome.extension.getURL("img/background.jpg")+')' )
        $('.onionID_blue_popup').css('background-color', '#081f2c');
        //$('.onionID_logo_centered').attr('src', chrome.extension.getURL("img/logo_centered.png"));
        $('.onionID_logo_centered').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        stopClick = false;
        $("#validateSdcode").on('click', function (event) {
            if(stopClick) return;
            stopClick = true;
            event.stopPropagation();
            theSdcode = $('#onionIdSdcode').val();
            //OnionIDLog(theSdcode);
            if(theServer) {
                console.log("SERVER " + theServer)
                sendValidateRequest(theSdcode, "send");
            } else {
                getUserEndpoint(theSdcode, "send");
            }

        });

    });



}

function getUserEndpoint (theSdcode, sendMail, autoInstallBE = false) {
    var onionIdEndpointRequest = {
                "sdcode": theSdcode,
                "type": "Get Endpoint"
    };
    console.log("Getting user endpoint");

    $.ajax({
            type: "POST",
            url: theUrlServer,
            dataType: "json",
            data: JSON.stringify(onionIdEndpointRequest),
            context: document.body,
            timeout: globalTimeout,
            success: function (response) {
                stopClick = false;
                if (response.response == "Succesful registration of application") {
                        theServer = response.url;
                        OnionIDLog(`Successfully fetched user endpoint. Proceeding reg with auto install value: ${autoInstallBE}`);
                        sendValidateRequest(theSdcode, sendMail, autoInstallBE);
                }
                else {
                    $('#errorMessage').css("visibility", "visible");
                }
            },
            error: function (x, t, m) {
                if (t === "timeout") {
                    stopClick = true;
                    //onionIdSystemMessage('Network connectivity cannot be established at this time. Please try again. If the problem persists, please contact your network administrator.');
                    OnionIDLog("Validate Phone Timeout!");
                }
            }
    });
}

function sendValidateRequest(theSdcode, sendMail, autoInstallBE = false) {
    OnionIDLog(`sendValidateRequest(): registering be against api`);
    var onionIdValidateRequest = {
                "sdcode": theSdcode,
            };

    $.ajax({
            type: "POST",
            url: theServer + "/v1/user/register/extension",
            dataType: "json",
            data: onionIdValidateRequest,
            context: document.body,
            timeout: globalTimeout,
            success: function (response) {
                stopClick = false;
                console.log("Responsed with message " + response.message);
                if (response.message == "ok") {
                    //last step, set up a master password
                    if(response.admin) {
                        console.log("Is admin");
                        chrome.storage.sync.set({"admin": response.admin}, function () {
                        });
                    }
                    if(response.global_masterpass) {
                        console.log("Has global_masterpass");
                        chrome.storage.local.set({"global_masterpass": response.global_masterpass}, function () {
                        });
                    }

                    if (response.global_masterpass != 1) {
                        OnionIDLog("No global masterpass set");
                        // Set master pass and sdcode etc on auto install
                        if (autoInstallBE) {
                            OnionIDLog("autoInstallBE - Set masterpass.");
                            var onionIdMasterPassRequest = {
                                "sdcode": theSdcode,
                                "masterpass": theSdcode,
                                "type": "Chrome Register Master Password"
                            };
                            sendMasterPassToServer(onionIdMasterPassRequest, autoInstallBE);
                        } else {
                            OnionIDLog("Manual install BE - Set masterpass.");
                            setMasterPassword(theSdcode);
                        }
                    }
                    else {
                        chrome.storage.sync.set( {endpoint: theServer}, function (obj) {
                           chrome.storage.sync.set({"sdcode": {'val': theSdcode}}, function () {
                                OnionIDLog('Endpoint and sdcode settings saved.');
                                if (!autoInstallBE) {
                                    $('#welcomeMessage').html('<span>Congratulations! Thycotic Access Controller has been activated. Please keep your Registration Code for future reference.</span> <br/><div class="Rectangle-3" style="cursor: pointer; margin-top:5px !important;  width:100px !important;"><span id="onionID_continue" class="tacButton"  style="font-size:13px !important;">CONTINUE.</span></div> ');
                                    $('#errorMessage').css("visibility", "hidden");
                                    $('#onionRegisterExtension').css('display','none');
                                    $('#onionID_continue').click(function () {
                                        location.reload();
                                    });
                                } else {
                                    location.reload();
                                }
                            });
                       });
                    }

                }
                else {
                    $('#errorMessage').css("visibility", "visible");
                }
            },
            error: function (x, t, m) {
                if (t === "timeout") {
                    stopClick = true;
                    //onionIdSystemMessage('Network connectivity cannot be established at this time. Please try again. If the problem persists, please contact your network administrator.');
                    OnionIDLog("Validate Phone Timeout!");
                }
            }
        });
}