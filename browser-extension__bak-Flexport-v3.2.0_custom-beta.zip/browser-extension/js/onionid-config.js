theUrlServer = "https://router.onionid.com";
useRemoteLogs = false;