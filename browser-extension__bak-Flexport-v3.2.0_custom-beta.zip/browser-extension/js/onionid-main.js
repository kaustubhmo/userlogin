////////////////////////            !!!!!!!!! MAIN !!!!!!!!!!!         ///////////////////////////////////////
var currentUrl = window.location.href;
OnionIDLog("The host is " + window.location.host);
overlay = "<div id=\"onionID_overlay\"><\/div> ";

var windowIsVisible = true;

// Actions to be done on window visibility changes
document.addEventListener('visibilitychange', function () {
    windowIsVisible = !document.hidden;

    // Actions to be done if window becomes active
    if (windowIsVisible) {
        // Act on the main document only (there could be embedded documents)
        if (window.self === window.top) {
            getBlockedElementsList();
        }
    }
});

chrome.storage.sync.get("endpoint", function (obj) {
    if(jQuery.isEmptyObject(obj)) {
        theServer = cloudServiceUrl;
        OnionIDLog('APIEndpoint: '+theServer);
    }
    else {
        theServer = obj.endpoint;
        OnionIDLog('APIEndpoint: '+theServer);
    }
    if(window.isTop) {
        chrome.storage.sync.get("admin", function (obj) {
            if(!jQuery.isEmptyObject(obj)) {
                OnionIDLog("The admin flag is " + obj.admin);
                if(obj.admin === 1) {
                  removeTheContextMenu();  //remove the menu before create it again for the new age in order to avoid duplicates
                  createTheContextMenu();
                }
            }
            else {
               /* OnionIDLog("Removing menus");
                removeTheContextMenu(); */
            }
        });
    }
});


chrome.storage.sync.get( "sdcode", function (obj) {
    if(jQuery.isEmptyObject(obj)) {
        chrome.runtime.sendMessage ( {command: "getCookieSdcode"}, function (response) {
            if(response) {
                console.log("The cookie " + response);
                getUserEndpoint(response, "dontsend");
            }
            else {
                OnionIDLog("Attempting to fetch sdcode from userAgent or query params for auto registering BE.");
                var query_param_sdcode = '', useragent_sdcode = '';
                try {
                    query_param_sdcode = (new URLSearchParams(window.location.search)).get('oid_sdcode');
                    useragent_sdcode = navigator.userAgent.split("oid_sdcode:")[1].split(" ")[0];
                } catch (err) {
                    // Failure looking up sdcode. Ignore.
                }

                if (useragent_sdcode) {
                    OnionIDLog(`Found sdcode ${useragent_sdcode} in userAgent. Proceeding to auto register BE.`);
                    getUserEndpoint(useragent_sdcode, "dontsend", true);
                } else if (query_param_sdcode) {
                    OnionIDLog(`Found sdcode ${query_param_sdcode} in query string. Proceeding to auto register BE.`);
                    getUserEndpoint(query_param_sdcode, "dontsend", true);
                } else {
                    console.log("Install the normal way");
                    if(window.isTop)
                        $.get(chrome.extension.getURL('html/onionid-top-banner.html'), function(result) {
                            $('body').append(result);
                            OnionIDLog("It works");
                            addBypassButton();
                            $('#onionID_top_bar').click(function() {
                                $('#onionID_top_bar').remove();
                                bulk_register_process();
                            });
                        });
                }
            }
        });
    }
    else {
        sdcode = obj.sdcode.val;
        OnionIDLog("currentUrl: " + currentUrl);
        OnionIDLog("sdcode: " + sdcode);
        logCurrentApp();

        // Fetch the blocked elements, for the main document only (there could be other embedded documents)
        if (window.self === window.top) {
            getBlockedElementsList();
        }
        OnionIDLog("Url is clear");

        /*  // This tracking code may not get a chance to run in some cases such as redirect.
         *  // Hence commenting this(for reference) and adding alternate solution in background js. 
        // Log access of special_url having LoginAccess policy
        chrome.storage.local.get('logAccessUrlList', function (obj) {
            console.log('Get logAccessUrlList:: ');
            console.log(obj);
            var decodedUrl = decodeURI(currentUrl);

            obj.logAccessUrlList.forEach(function (page) {
                console.log('foreach page & currentUrl: ');
                console.log(page.url);
                console.log(currentUrl);
                if (decodedUrl == page.url) {
                    console.log('startAuthenticationProcess - false');
                    // Do not do auth. Only log access of special_url having LoginAccess policy
                    startAuthenticationProcess(sdcode, false, false, true);
                }
            });
        });
         */

        getAppList(function() {
            if (appIsInAppList(appList)) {
                OnionIDLog('main-findApp(): ' + findApp(currentUrl));
                switch (findApp(currentUrl)) {

                    case 'ahrefs':
                        $(document).on('click', '#signIn', function () {

                            // Enable authentication process only on first attempt
                            if (!attempts_count) {
                                startAuthenticationProcess(sdcode, true);
                            } else {
                                onionIdSystemMessage('Please reload the page and try again.');
                            }
                        });
                        break;

                    case 'semrush':
                        $(document).on('click', '#srf-login-btn', function () {

                            // Enable authentication process only on first attempt
                            if (!attempts_count) {
                                
                                // Add 1 sec delay to allow AJAX data to load in the login form
                                setTimeout(function () {
                                    startAuthenticationProcess(sdcode, true);
                                }, 1000);
                            } else {
                                onionIdSystemMessage('Please reload the page and try again.');
                            }

                        });
                        break;

                    case 'microsoftonline': // fall-through
                    case 'live':    // Custom login workflow for MS Office etc
                        try {
                            // MFA already done and username already submitted.
                            if (window.name && window.name.indexOf('live') > -1) {
                                OnionIDLog("Microsoft Live: Saved login found. Proceed to submit pass.");
                                var winName = JSON.parse(window.name);
                                do_login(winName.username, winName.password);
                            } else if ($('input[name ="loginfmt"]').length == 1 && !window.name) {
                                OnionIDLog("Microsoft Live: Login not yet saved. Proceed to do MFA normally.");
                                startAuthenticationProcess(sdcode, true);
                            }
                        } catch (err) {
                            console.error("Microsoft Live: Unable to access credentials from window.name.");
                            console.log(err.stack);
                        }
                        break;

                    case 'account.box.com': // fall-through
                    case 'box':    // Custom login workflow for box.com
                        try {
                            // MFA already done and username already submitted.
                            if (window.name && window.name.indexOf('box') > -1) {
                                OnionIDLog("Box.com: Saved login found. Proceed to submit pass.");
                                var winName = JSON.parse(window.name);
                                do_login(winName.username, winName.password);
                            } else if ($('input#login-email').length == 1) {
                                OnionIDLog("Box.com: Login not yet saved. Proceed to do MFA normally.");
                                startAuthenticationProcess(sdcode, true);
                            }
                        } catch (err) {
                            console.error("Box.com: Unable to access credentials from window.name.");
                            console.log(err.stack);
                        }
                        break;

                    case 'airbnb':
                        // Force reload using supported theme if unsupported theme is detected. OG-661
                        airbnbSwitchTheme();
                        startAuthenticationProcess(sdcode, true);
                        break;

                    case 'jumpcloud':
                        setTimeout(() => startAuthenticationProcess(sdcode, true), 1500);  // Wait for everything to load before checking for type of login form required
                        break;

                    default:
                        OnionIDLog("default->startAuthenticationProcess()");
                        startAuthenticationProcess(sdcode, true);
                        break;
                }
                
            }
            else
                OnionIDLog("Application is not supported");
        });

    }
});


//Enable/Disable bypass-close button in case if setting changes
chrome.storage.onChanged.addListener(function(changes, namespace) {

    // Enable/Disable bypass-close button in case if setting changes
    if (typeof changes.general_development_mode !== 'undefined' &&
        typeof changes.general_development_mode !== 'undefined' &&
        changes.general_development_mode.oldValue !== changes.general_development_mode.newValue ) {
            addBypassButton();
    }
});


//Force reload using supported theme if unsupported theme is detected. OG-661
function airbnbSwitchTheme() {
    OnionIDLog('Force reload using supported theme if unsupported theme is detected.');
    if ($('input#email-login-password').length || $('input#phone-login-password').length) {
        OnionIDLog('Unsupported theme found. Attempting theme switching.');
        var cookieMessage = {
            command: "removeAllCookiesByUrl",
            url: "https://www.airbnb.com/"
        };

        chrome.runtime.sendMessage (cookieMessage, response => {
            OnionIDLog('removeAllCookiesByUrl response: ');
            OnionIDLog(response);
        });

        $("body").remove();  // Temporarily removing a toplevel element to force reload new theme
        document.location.reload(true);
    }
}