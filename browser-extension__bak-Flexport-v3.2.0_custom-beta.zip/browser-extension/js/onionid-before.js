stop = false;
theServerBefore = "";
cloudServiceUrl = "https://panel.onionid.com:4443";
action = 1;
globalTimeout = 10000;
account = "none";
masterpass = false;
showLogs = false;
cacheLimit = 300000;
secondsAllow = 6000;
fallback = 0;
fallback_limit = 30;
fallback_seconds = 0;
autologin_seconds = 3;
stopLogin = false;

chrome.storage.sync.get("endpoint", function (obj) {
    if(jQuery.isEmptyObject(obj)) {
        theServerBefore = cloudServiceUrl;
        OnionIDLog(theServerBefore);
    }
    else {
        theServerBefore = obj.endpoint;
        OnionIDLog(theServerBefore);
    }
});


function OnionIDLog(message) {
    if(showLogs)
        console.log(message);
}

//Find Application from url
function findApp(theRequestUrl) {

    OnionIDLog(theRequestUrl);

    if(theRequestUrl.indexOf(".com") > -1 ) {
        theRequestUrl = theRequestUrl.split(".com")[0];
    }
    else if(theRequestUrl.indexOf(".eu") > -1 ) {
        theRequestUrl = theRequestUrl.split(".eu")[0];
    }else if(theRequestUrl.indexOf(".net") > -1 ) {
        theRequestUrl = theRequestUrl.split(".net")[0];
    }
    else if(theRequestUrl.indexOf(".io") > -1 ) {
        theRequestUrl = theRequestUrl.split(".io")[0];
    }
    else if(theRequestUrl.indexOf(".org") > -1 ) {
        theRequestUrl = theRequestUrl.split(".org")[0];
    }
    else if(theRequestUrl.indexOf(".gr") > -1 ) {
        theRequestUrl = theRequestUrl.split(".gr")[0];
    }
    else if(theRequestUrl.indexOf(".es") > -1 ) {
        theRequestUrl = theRequestUrl.split(".es")[0];
    }
    else if(theRequestUrl.indexOf(".co") > -1 ) {
        theRequestUrl = theRequestUrl.split(".co")[0];
    }
    else if(theRequestUrl.indexOf(".in") > -1 ) {
        theRequestUrl = theRequestUrl.split(".in")[0];
    }
    else if(theRequestUrl.indexOf(".tv") > -1 ) {
        theRequestUrl = theRequestUrl.split(".tv")[0];
    }
    else if(theRequestUrl.indexOf(".ch") > -1 ) {
        theRequestUrl = theRequestUrl.split(".ch")[0];
    }

    theRequestUrl = theRequestUrl.split(".");
    theRequestUrl = theRequestUrl.pop();
    if(theRequestUrl.indexOf("https://")>-1) {
        theRequestUrl = theRequestUrl.split("https://")[1];
    }
    if(theRequestUrl.indexOf("http://")>-1) {
        theRequestUrl = theRequestUrl.split("http://")[1];
    }

    OnionIDLog("The app is " + theRequestUrl);
    return theRequestUrl;

}

function removePopups() {
    $('#onionID_application_popup').remove();
    $('#onionID_register_popup').remove();
    $('#onionID_register_pin_popup').remove();
    $('#onionID_top_bar').remove();
    $('#onionID_top_error_bar').remove();
    $('#onionID_top_block_bar').remove();
    $('#onionID_credentials_popup').remove();
    $('#onionID_masterpass_popup').remove();
    $('#onionID_policy_popup').remove();
    $('#onionID_overlay').remove();
    $('#onionID_masterpass_update_popup').remove();
    $('#onionID_masterpass_update_email').remove();
    $('#onionID_element_save_popup').remove();
    $('#onionID_access_request_popup').remove();
    lockContext = false;
}

function addBypassButton () {
    $('.onionIDBypass').css("display","block");
    $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
    $('.onionIDBypass').on('click', function () {
        removePopups();
        stop=true;
        bypassRequest =  {
            "url": currentUrl,
            "sdcode": sdcode,
            "full_domain": window.location.hostname,
            "type": "Chrome Bypass"
        };
        $.ajax({
            type: "POST",
            url: theServerBefore,
            dataType: "json",
            data: JSON.stringify(bypassRequest),
            context: document.body
        })
    });
}

/// BEGIN ACCESS REQUEST FUNCTIONS ///

function showRequestAccessBar() {
    removePopups();
    $.get(chrome.extension.getURL('html/onionid-top-access-request-banner.html'), function(result) {
        $('body').append(result);  
        OnionIDLog("It works");
        addBypassButton();
        $('#onionID_top_block_bar').click(function() {
                removePopups();
                showRequestAccessPopup();
        });              
    });  
}

function showRequestAccessPopup() {
    removePopups();
    $.get(chrome.extension.getURL('html/onionid-access-request-popup.html'), function(result) {
        $('body').append(result);  
        OnionIDLog("It works");
        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        addBypassButton();
        $('#onionSubmitReason').click(function() {
            theReason = $('#onionIDaccessReason').val();
            $('#onionID_access_request_popup').remove();
            sendAccessRequestToServer(theReason);
            lockContext = false;
        }); 
    });
}

function sendAccessRequestToServer(theReason) {
     accessRequest =  {
            "url": currentUrl,
            "reason": theReason,
            "sdcode": sdcode,
            "access_type": "url",
            "type": "Browser Request Resource Access"
    };

    $.ajax({
        type: "POST",
        url: theServerBefore,
        dataType: "json",
        data: JSON.stringify(accessRequest),
        context: document.body
    });
}

/// END ACCESS REQUEST FUNCTIONS ///


function startAuthenticationProcessBefore(sdcode, checkLogin) {
    OnionIDLog("startAuthenticationProcessBefore()");
    //get location coords
    step1 = Date.now();
    OnionIDLog(step1);
    chrome.runtime.sendMessage ( {command: "geoloc"}, function (response) {
        if(response != "geolocation error") {
            theGeo = response.coords;
            step2 = Date.now();
            OnionIDLog("THE GEOLOC IS " + theGeo)
            OnionIDLog("Google coords: " + (step2 - step1) + "msec");
            //Fetching Country Region and State
            chrome.runtime.sendMessage({command: "geoip"}, function (response) {
                step3 = Date.now();
                OnionIDLog("Ip API (Country,State): " + (step3 - step2) + "msec");
                OnionIDLog("The timeout of the geoip was " + response.timeout);
                OnionIDLog("The cached of the geoip was " + response.cached);

                //begin the OID process
                if(checkLogin)
                    checkForLoginForm(false, 2000, sdcode, theGeo, response.geoip.city, response.geoip.regionName, response.geoip.country, response.geoip.query);
                else {
                    step4 = step3;
                    banPage(false, 2000, sdcode, theGeo, response.geoip.city, response.geoip.regionName, response.geoip.country, response.geoip.query);
                }

            });
        }
        else {
            OnionIDLog('Google Geolocation API has failed us');
            //onionIdSystemMessage('We cannot establish a network connection to validate your location at this time. Please try again later. If the problem persists, please contact your network administrator.');
        }
    });

}

function urlIsInUrlList(urlList, useHash) {
    
    console.log("Checking if url is in url list");
    if(!urlList) {
        console.log("There are no blocked urls");
        return false;
    }

    if(useHash) 
        currentHash = CryptoJS.SHA1(currentUrl).toString(CryptoJS.enc.Hex)
    else
        currentHash = currentUrl;

    //if we are using hash look for exact match
    if(useHash) {
        if($.inArray(currentHash, urlList) != -1)
            return true;
        else
            return false;
    }
    else {
        currentDomain = window.location.hostname;
        currentUrlSuffix = currentUrl.split(currentDomain)[1];
        
        OnionIDLog("The current domain is " + currentDomain);
        OnionIDLog("The current url suffix is " + currentUrlSuffix);

        banIt = false;
        $.each(urlList, function(index, url) {
            banIt = banLogic(url.url);
            if(banIt) {
                theBanUrlId = url.id;
                theBanUrl = url.url;
                OnionIDLog("Banning url with id " + theBanUrlId);
                return false;
            }
        });
        return banIt;
    }
}

function urlIsInBlockUrlList(urlList, useHash) {

    OnionIDLog("Checking if url is in block url list");
    if(!urlList) {
        OnionIDLog("There are no blocked urls");
        return false;
    }

    urlList = urlList.split(",");

    if(useHash) 
        currentHash = CryptoJS.SHA1(currentUrl).toString(CryptoJS.enc.Hex)
    else
        currentHash = currentUrl;

    //if we are using hash look for exact match
    if(useHash) {
        if($.inArray(currentHash, urlList) != -1)
            return true;
        else
            return false;
    }
    else {
        
        banIt = false;
        $.each(urlList, function(index, url) {
            if(currentUrl.indexOf(url) > -1) {
                banIt = true;
            }
        });
        return banIt;
    }

}


function banLogic(url) {
    if(url === undefined) {
        return false;
    }
    urlSuffix = url.split(currentDomain)[1];
    if( (url.indexOf(currentDomain) > -1) && (currentUrlSuffix.indexOf(urlSuffix) > -1) )
        return true;
    else
        return false;
}

function banPage(credsChecked, timeout, obj, theCoords, city, state, country, ip) {
        /*theCurrentUrl = currentUrl.split("?")[0];
        theCurrentUrl = currentUrl.split("#")[0];
        console.log("The current url now " + theCurrentUrl);*/
        var policyRequest = {
            "urlId": theBanUrlId,
            "type": "Find Url Policy",
            "sdcode": sdcode,
            "coords": theCoords,
            "city": city,
            "country": country,
            "state": state,
            "ip": ip,
            "agent": navigator.appVersion
        };
        sendUrlPolicyRequest(policyRequest, sdcode, true);
}

function removeUnwantedBodies(timeout) {
    
    /*$('body').find('*').each(function(index, element){
        console.log($(this));
        if($(this)[0].outerHtml.toLowerCase().indexOf('onionid') < 0) {
            $(this).remove();
        }
    }); */
    
    setTimeout(function() {
        OnionIDLog("removing unwanted bodies");
        $('body:not([id=onionid-bg-black])').remove();
        removeUnwantedBodies(timeout);
    }, timeout);
}

function showBlackBlockMessage(mode) {
    if(mode == "restrict")
        window.location.href = chrome.extension.getURL('html/onionid-ban-restrict.html');
    else
        window.location.href = chrome.extension.getURL('html/onionid-ban.html');
}

function sendUrlPolicyRequest(policyRequest, sdcode, special_url) {

    $.ajax({
        type: "POST",
        url: theServerBefore,
        dataType: "json",
        data: JSON.stringify(policyRequest),
        timeout: globalTimeout,
        success: function (response) {
            step5 = Date.now();
            OnionIDLog("Policy Request (Server): " + (step5 - step4) + "msec");
            OnionIDLog("Process completed!");
            OnionIDLog("Whole time: " + (step5 - step1) + "msec");
            OnionIDLog(response);
            if(response.accounts)
                accounts = response.accounts;
            else 
                accounts = [];

            if (response.policy) {
                popups = response.policy;
                popups = popups.split(" ");
                popups.pop();
                OnionIDLog(popups.length);
                geoproximity = response.geoproximity;
                geofencing = response.geofencing;

                if(response.masterpass == 1) {
                    masterpass = true;
                }
                OnionIDLog("THE FALLBACK IS " + response.fallback);

                if(response.fallback) {
                    fallback = response.fallback;
                    OnionIDLog("FALLBACK ENABLED " + response.fallback );
                    if(fallback == 1 ) fallback = true;
                    else fallback = false;
                }
                else {
                    fallback = false;
                }


                 if(response.autologin)
                    autologin = response.autologin;
                else
                    autologin = 0;

                if(popups[0] == 6) {
                    showMasterPassPopupWithAccounts(accounts);
                }
                else {

                    if(special_url && window.location.href != chrome.extension.getURL('html/onionid-ban.html')) {
                        showBlackBlockMessage();
                    }

                    authNext(popups, accounts, autologin, geofencing, geoproximity, sdcode, special_url);
                }
            }
            else {
                if(response.restrict == "1") {

                    if(window.location.href != chrome.extension.getURL('html/onionid-ban.html')) {
                        showBlackBlockMessage();
                    }
                    else {
                        showRequestAccessBar();
                    }
                }
                OnionIDLog(response.message);
            }
        },
        error: function (x, t, m) {
            if (t === "timeout") {
                onionIdSystemMessage('Network connectivity cannot be established at this time. Please try again. If the problem persists, please contact your network administrator.');
                OnionIDLog("Policy Fetch Timeout!");
            } else {
            }
        }
    });

}

function updateAllowedOrNot() {
     chrome.storage.local.get("global_masterpass", function (obj) {
            if(!jQuery.isEmptyObject(obj)) {
                OnionIDLog("The global masterpass flag is " + obj.global_masterpass);
                if(obj.global_masterpass === 1) {
                    $('#onionIDupdateMasterPass').css('display','none');
                }
            }
            else {
            }
    });
}


function showMasterPassPopupWithAccounts(accounts) {
     removePopups();
    $.get(chrome.extension.getURL('html/onionid-masterpass-popup.html'), function(result) {
        $('body').append(result);
        $('body').append(overlay);
        //Toggle comment if you want masterpass popup to disappear or not.
        //setTimeout(function() { removePopups(); }, 30 * 1000);

        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        $('#onionIDupdateMasterPass').css('cursor','pointer');
        addBypassButton();

        $('#onionID_masterpass_update_popup').draggable({
                start: function () {
                }
            }
        );

        updateAllowedOrNot();

        $('#onionIDupdateMasterPass').on('click',function() {
            removePopups();
            $.get(chrome.extension.getURL('html/onionid-masterpass-update-popup.html'), function(result) {
                $('body').append(result);
                $('body').append(overlay);
                //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
                $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
                $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));                
                $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
                addBypassButton();

            $('#onionRegisterCredentialsSubmit').on('click',function() {
                 
                theMasterPass = $('#newOnionIDpassword').val();
                var onionIdMasterPassRequest = {
                    "sdcode": sdcode,
                    "masterpass": theMasterPass,
                    "type": "Chrome Register Master Password"
                }

                OnionIDLog("Masterpass Verified");

                if($('#newOnionIDpassword').val() == $('#confirmOnionIDpassword').val() ) {
                    OnionIDLog("Password Match");
                    $.ajax({
                        type: "POST",
                        url: theServerBefore,
                        dataType: "json",
                        data: JSON.stringify(onionIdMasterPassRequest),
                        context: document.body,
                        success: function (response) {
                            OnionIDLog("Updated Passwords");
                            if(action==1) {
                                stop = true;
                                do_login(username, password);
                                setTimeout(function() {removePopups();}, 2000);
                            }
                            else if (action==2) {
                                showRegisterForm();
                            }
                            else if (action==3) {
                                showRegisterForm("wrong");
                            }
                            else if (action==4) {
                                deleteAccount();
                            }
                                }
                        });
                }
                else {
                    OnionIDLog("password missmatch");
                    $('#errorMessage').html("Passwords do not match");
                    $('#errorMessage').css("visibility", "visible");
                }
                  
            });
        });
        });

        $("#onionSubmitMasterPass").on('click',function() {
            var masterpass = $('#onionIDpassword').val();
            var onionIdMasterPassRequest = {
                    "masterpass": masterpass,
                    "sdcode": sdcode,
                    "url": currentUrl,
                    "type": "Chrome Verify Master Password"
                };

            OnionIDLog(onionIdMasterPassRequest);
            $.ajax({
                type: "POST",
                url: theServerBefore,
                dataType: "json",
                data: JSON.stringify(onionIdMasterPassRequest),
                context: document.body,
                success: function (response) {
                    if(response.response == "Masterpass Verified"){
                        if(action==1) {
                                stop = true;
                                removePopups();
                                var passObj = {};                                
                                passName = "pass" + theBanUrlId;
                                passValue = Date.now();
                                passObj[passName] = passValue;
                                chrome.storage.local.set(passObj, function(obj) {
                                    setTimeout(function() {window.location.href = currentUrl;}, 2000);
                                });
                            }
                            else if (action==2) {
                                showRegisterForm();
                            }
                            else if (action==3) {
                                showRegisterForm("wrong");
                            }
                            else if (action==4) {
                                deleteAccount();
                            }
                    }
                    else {
                        $('#errorMessage').html(response.message);
                        $('#errorMessage').css("visibility", "visible");
                    }
                }
            });

        });

        $("#onionIDpassword").keyup(function(event){
            if(event.keyCode == 13){
                $("#onionSubmitMasterPass").click();
            }
        });

    });

}


function makePolicyPopup(policy, accounts, request, autologin, callback, special_url) {
    $('body').append(overlay);
    application_popup = '<div id="onionID_application_popup">' +
    //'<img class="onionID_logo" src="img/logo.png" />' +
    '<img class="onionID_logo" style="top: -25px !important; height: 76px; width: 76px; margin-left: -34px"  src="img/popupicon.svg" style="float:left;"/>' +
    '<div style="text-align: center; padding-top: 15px !important;margin-left: -65px">' +
    '<img src="img/thycotic-all-white.svg" class="ThycoticAllWhite" id="ThycoticAllWhiteLogo" >' +
    '<span class="ACCESS-CONTROLLER" >ACCESS CONTROLLER</span>' +
    '</div>' +
    '<img class="onionIDBypass" src="img/x_button.png">' +
    '<div class="onionID_MainBody">' +
    '<p class="onionID_identified">Identified</p>' +
    '<p class="onionID_website">Facebook</p>' +
    '<img class="onionID_loading_bar" src="img/waiting_animation_matte_R218_G218_B218_No-trancparency.gif" style="padding-top:41px !important;" />' +
    '<p class="onionID_message">Waiting for Mobile Authentication...</p>' +
    '</div>' +
    '</div>'
    // starting yubikey policy here
    if(policy == 7) {
        chrome.storage.local.get("yubikey_client_id", function (obj) {
            OnionIDLog('yubikey_client_id is: ' + JSON.stringify(obj))
            if(jQuery.isEmptyObject(obj) || jQuery.isEmptyObject(obj.yubikey_client_id) || obj.yubikey_client_id.val === undefined) {
                show_yubikey_register_popup(accounts, special_url)
            } else {
                show_yubikey_authentation(accounts, obj.yubikey_client_id.val, special_url)
            }
        });
    } else {
        $.get(chrome.extension.getURL('html/onionid-application-popup.html'), function(result) {
            $('body').append(result);
            if(autologin == 1) {
                $('.onionID_message').html('Logging you in automatically in ' + autologin_seconds + ' seconds... (press space to skip, or h to halt the process)');
                autologinCountdown(autologin_seconds);
            }
            $('.onionID_website').html(findApp(currentUrl));
        });

        $.get(chrome.extension.getURL('html/onionid-policy-popup-new.html'), function(result) {
            $('body').append(result);
            currentPolicy = parseInt(policy);
            switch(currentPolicy) {
                case 1:
                    $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/TouchID.png"));
                    $('.onionID_policy_text').html('use TouchID');
                    break;
                case 2:
                    $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/AirSign.png"));
                    $('.onionID_policy_text').html('use AirSign');
                    break;
                case 4:
                    $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/GeoFencing.png"));
                    $('.onionID_policy_text').html('use GeoFencing');
                    break;
                case 5:
                    $('.onionID_policy_image').attr('src', chrome.extension.getURL("img/Geoproximity.png"));
                    $('.onionID_policy_text').html('use GeoProximity');
                    break;
            }
             if(fallback && !autologin) {
                $('.onionID_message').html('Waiting for Mobile Authentication - Fallback in 30 seconds');
                $('.onionID_MainBody').append('<a id="onionID_masterpass_message" href="#" title="Fall back allows you to login even if none of the above techniques are available on your phone - please enter you master password that you have registered with Thycotic Access Controller during the installation process">What is fallback?</a>');
                $('#onionID_masterpass_message').tooltip({
                      track: true
                    });
            }
            //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
            $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
            $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
            //$('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.gif"));
            $('.onionID_loading_bar').attr('src', chrome.extension.getURL("img/loading.svg"));
            $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
            addBypassButton();

            setTimeout(function() {
                $('#onionID_application_popup').css('display','none');
                $('#onionID_policy_popup').css('display','block');
            }, 2500)



            if(accounts.length > 0 && !special_url) {
                $.each(accounts, function (key, account) {
                    if(account.username.length>20) {
                        wellFormedAccount = account.username.substring(0,19);
                        wellFormedAccount+="...";
                    }
                    else {
                        wellFormedAccount = account.username;
                    }
                    $('#onionID_choose_account select').append('<option value="' + account.id + '">' + wellFormedAccount + '</option>')
                });
                account = $( "#onionID_choose_account select option").first().val();
                OnionIDLog("Account id is " + account);
                $( "#onionID_choose_account select" )
                .change(function () {
                    account = $( "#onionID_choose_account select option:selected" ).val();
                    OnionIDLog("Account id is " + account);
                });

                $( "#onionID_choose_action select" )
                .change(function () {
                    action = $( "#onionID_choose_action select option:selected" ).val();
                    OnionIDLog("Action id is " + action);
                    actionInt = parseInt(action);
                    switch(actionInt) {
                        case 1:
                            $('.onionID_message').html('Waiting for Mobile Authentication...');
                            $('.onionID_message').css('color','black');
                            break;
                        case 2:
                            $('.onionID_message').html('Authenticate with your phone to add an account');
                            $('.onionID_message').css('color','#2ECC40');
                            break;
                        case 3:
                            $('.onionID_message').html('Authenticate with your phone to update the account');
                            $('.onionID_message').css('color','#2ECC40');
                            break;
                        case 4:
                            $('.onionID_message').html('Authenticate with your phone to delete the account');
                            $('.onionID_message').css('color','#FF4136');
                            break;
                    }
                });

            }
            else {
                $('#onionID_choose_account').css('display','none');
                $('#onionID_choose_action').css('display','none');
            }

            if(accounts.length <= 1) {
                $('#onionID_choose_account').css('display','none');
            }

            $('#onionID_policy_popup').draggable({
                    start: function () {
                    }
                }
            );

            //if we have autologin let {autologin_seconds} seconds for user to choose account or do other action
            if(autologin) {
                callback(autologin_seconds * 1000, request, special_url, autologin);
                $(document).keypress(function(event) {
                    OnionIDLog(event.which);
                    if ( event.which == 32 ) {
                        OnionIDLog("PRESSED space");
                        callback(0, request, special_url, autologin, accounts, blockedElement);
                    }
                    if ( event.which == 104 ) {
                        OnionIDLog("PRESSED h");
                        stopLogin = true;
                        setTimeout(function() {
                        $('.onionID_message').html('<a id="OnionIDClickToVerify" style="cursor:pointer;"> Click when ready to perform your action </a>');
                        $('#OnionIDClickToVerify').click(function() {
                            stopLogin = false;
                            callback(0, request, special_url, autologin, accounts, blockedElement);
                        });
                        }, 500);
                        OnionIDLog(stopLogin);
                    }
                });
            }
            else
                callback(1000, request, special_url);

            if(fallback && !autologin) {
                fallbackCountdown(1000, accounts);    
            }
         
        });
    }
}


function fallbackCountdown(timeout, accounts, blockedElement) {
    fallback_seconds++;
    if(!stop) {
    setTimeout(
        function() {
            if(fallback_seconds == fallback_limit)
                showMasterPassPopupWithAccounts(accounts);
            else{
                $('.onionID_message').html('Waiting for Mobile Authentication - Fallback in ' + (fallback_limit - fallback_seconds) + ' seconds');
                fallbackCountdown(timeout, accounts);
            }
        }, timeout
        );
    }
}

function autologinCountdown(seconds) {
    if (seconds >= 0) {
        setTimeout( function() {
            if(!stopLogin) {
                $('.onionID_message').html('Logging you in automatically in ' + seconds + ' seconds... (press space to skip, or h to halt the process)');
                autologinCountdown(seconds - 1);
            }
        }, 1000);
    }
}


// yubikey functions start
function show_yubikey_register_popup(accounts, special_url) {
    $.get(chrome.extension.getURL('html/onionid-yubikey-register.html'), function(result) {
        $('body').append(result);
        $('body').append(overlay);
        //Toggle comment if you want masterpass popup to disappear or not.
        //setTimeout(function() { removePopups(); }, 30 * 1000);

        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        $('#onionIDupdateMasterPass').css('cursor','pointer');
        addBypassButton();
        $('#onionID_policy_popup').draggable({
                start: function () {
                }
            }
        );
        // on form submit:
        $("#onionIDRegisterYubikey").on('click', function() {
            var yubikey_client_id = $('#yubikey_client_id').val();
            var onionIdYubikeyRequest = {
                "yubikey_client_id": yubikey_client_id,
                "sdcode": sdcode,
                "type": "Register Yubikey Client ID"
            };

            OnionIDLog("onionIdYubikeyRequest: " + JSON.stringify(onionIdYubikeyRequest));
            $.ajax({
                type: "POST",
                url: theServerBefore,
                dataType: "json",
                data: JSON.stringify(onionIdYubikeyRequest),
                context: document.body,
                success: function (response) {
                    if(response.response == "Yubikey id succesfully registered"){
                        OnionIDLog("Yubikey Client ID Stored");
                        // remove popus:
                        removePopups();
                        // Store Yubikey
                        chrome.storage.local.set(
                            {
                                "yubikey_client_id": {'val': yubikey_client_id}},
                                function (obj) {
                                    // authenticate with Yubikey
                                    show_yubikey_authentation(accounts, yubikey_client_id, special_url)
                                }
                            );
                        
                    }
                    else {
                        $('#errorMessage').html(response.message);
                        $('#errorMessage').css("visibility", "visible");
                    }
                }
            });

        });

        $("#yubikey_client_id").keyup(function(event){
            if(event.keyCode == 13){
                $("#onionIDRegisterYubikey").click();
            }
        });
        // handle accounts:
        OnionIDLog("The accounts length is " + accounts.length);
        if(accounts.length > 0) {
            $.each(accounts, function (key, account) {
                if(account.username.length>20) {
                    wellFormedAccount = account.username.substring(0,19);
                    wellFormedAccount+="...";
                }
                else {
                    wellFormedAccount = account.username;
                }
                $('#onionID_choose_account select').append('<option value="' + account.id + '">' + wellFormedAccount + '</option>')
            });
            account = $( "#onionID_choose_account select option").first().val();
            $( "#onionID_choose_account select" ).change(function () {
                account = $( "#onionID_choose_account select option:selected" ).val();
            });

            $("#onionID_policy_popup").on("change", "#onionID_choose_action select",function () {
                action = $( "#onionID_choose_action select option:selected" ).val();
                actionInt = parseInt(action);
                OnionIDLog("Action changed to " + actionInt);                
                //If autologin don't change the message and keep countdown
                if(autologin)
                    actionInt = 0; 

                switch(actionInt) {
                    case 1:
                        $('.onionID_message').html('Waiting for Yubikey input...');
                        $('.onionID_message').css('color','black');
                        break;
                    case 2:
                        $('.onionID_message').html('Authenticate with your Yubikey to add an account');
                        $('.onionID_message').css('color','#2ECC40');
                        break;
                    case 3:
                        $('.onionID_message').html('Authenticate with your Yubikey to update the account');
                        $('.onionID_message').css('color','#2ECC40');
                        break;
                    case 4:
                        $('.onionID_message').html('Authenticate with your Yubikey to delete the account');
                        $('.onionID_message').css('color','#FF4136');
                        break;
                    default:
                        break;
                }
            });

        }
        else {
            $('#onionID_choose_account').css('display','none');
            $('#onionID_choose_action').css('display','none');
            $('#onionID_choose_account').remove();
            $('#onionID_choose_action').remove();
        }

    });
}

function show_yubikey_authentation(accounts, yubikey_client_id, special_url) {
    OnionIDLog("show_yubikey_authentation with: " + yubikey_client_id);
    $.get(chrome.extension.getURL('html/onionid-yubikey-authenticate.html'), function(result) {
        $('body').append(result);
        $('body').append(overlay);
        //Toggle comment if you want masterpass popup to disappear or not.
        //setTimeout(function() { removePopups(); }, 30 * 1000);

        //$('.onionID_logo').attr('src', chrome.extension.getURL("img/logo.png"));
        $('.onionID_logo').attr('src', chrome.extension.getURL("img/popupicon.svg"));
        $('#ThycoticAllWhiteLogo').attr('src', chrome.extension.getURL("img/thycotic-all-white.svg"));
        $('.onionIDBypass').attr('src', chrome.extension.getURL("img/x_button.png"));
        $('.onionID_yubikey_image').attr('src', chrome.extension.getURL("img/yubikey.png"))
        $('#onionIDupdateMasterPass').css('cursor','pointer');
        addBypassButton();
        // add accounts:
        if(accounts.length > 0) {
            $.each(accounts, function (key, account) {
                if(account.username.length>20) {
                    wellFormedAccount = account.username.substring(0,19);
                    wellFormedAccount+="...";
                }
                else {
                    wellFormedAccount = account.username;
                }
                $('#onionID_choose_account select').append('<option value="' + account.id + '">' + wellFormedAccount + '</option>')
            });
            account = $( "#onionID_choose_account select option").first().val();
            $( "#onionID_choose_account select" )
            .change(function () {
                account = $( "#onionID_choose_account select option:selected" ).val();
            });

            $( "#onionID_choose_action select" )
            .change(function () {
                action = $( "#onionID_choose_action select option:selected" ).val();
                actionInt = parseInt(action);
                OnionIDLog("Action changed to " + actionInt);                
            });
        }
        $("#onionSubmitYubikeyPass").on('click', function(event) {
            var otp = $('#yubikeyPassword').val();
            var onionIdYubikeyAuthenticateRequest = {
                "yubikey": otp,
                "sdcode": sdcode,
                "url": currentUrl,
                "type": "Authenticate Yubikey Password"
            };
            OnionIDLog("onionIdYubikeyAuthenticateRequest: " + JSON.stringify(onionIdYubikeyAuthenticateRequest))
            $.ajax({
                type: "POST",
                url: theServerBefore,
                dataType: "json",
                data: JSON.stringify(onionIdYubikeyAuthenticateRequest),
                context: document.body,
                success: function (response) {
                    OnionIDLog("onionIdYubikeyAuthenticate Response: " + JSON.stringify(response))
                    // if success: {"response": "successfull authentication"}
                    if(response.response == "successfull authentication"){
                        OnionIDLog(response);
                        var authenticate_request = {
                            "url": currentUrl,
                            "sdcode": sdcode,
                            "account": account,                    
                            "full_domain": window.location.hostname,
                            "type": "Chrome Authenticate Account"
                        };
                        OnionIDLog("authenticate_request:\n" + JSON.stringify(authenticate_request))
                        authenticateAttempt(globalTimeout, authenticate_request, special_url)
                    } else {
                        $('#errorMessage').html(response.response);
                        $('#errorMessage').css("visibility", "visible");
                    }
                },
                error: function(x, t, m) {
                    OnionIDLog('error: ' + JSON.stringify(x));
                    if (t === "timeout") {
                        OnionIDLog("Auth Attempt Timeout!");
                    }else if(x.responseJSON !== undefined && x.responseJSON.response !== undefined) {
                        $('#errorMessage').css("visibility", "visible");
                        switch (x.responseJSON.response) {
                            case 'BAD_OTP':
                                $('#errorMessage').html('The OTP is invalid format.');
                                break;
                            case 'REPLAYED_OTP':
                                $('#errorMessage').html('The OTP has already been seen by the service.');
                                break;
                            default:
                                $('#errorMessage').html(x.responseJSON.response);
                        }

                    }
                }
            });
        });
        // enter automatically pressed by Yubikey
        $("#yubikeyPassword").keydown(function(event){
            if(event.keyCode == 13){
                event.preventDefault();
                $("#onionSubmitYubikeyPass").click();
                return false;
            }
        });
    });
    return;
}
// yubikey functions end


function authenticateAttempt(timeout, request, special_url, autologin) {
    request.account = account;
    setTimeout(
        function() {
            if (!stop && !stopLogin) {
                $.ajax({
                    type: "POST",
                    url: theServerBefore,
                    dataType: "json",
                    data: JSON.stringify(request),
                    context: document.body,
                    timeout: globalTimeout,
                    success: function (response) {
                        if (response.message == "register") {
                            showRegisterForm();
                            stop = true;
                        }
                        else if (response.status == "Waiting for Authentication") {
                            authenticateAttempt(timeout, request, special_url, autologin)
                        }
                        else if (response.message == "canceled") {
                            OnionIDLog('canceled');
                            removePopups();
                        }
                        else if(!masterpass) {
                          if(action==1) {
                                OnionIDLog("Hello bladsadasdas");
                                if(!special_url) {
                                    stop = true;
                                    do_login(response.username, response.password);
                                    setTimeout(function() {removePopups();}, 2000);
                                }
                                else {
                                    stop = true;
                                    removePopups();
                                    var passObj = {};                                
                                    passName = "pass" + theBanUrlId;
                                    passValue = Date.now();
                                    passObj[passName] = passValue;
                                    chrome.storage.local.set(passObj, function(obj) {
                                        setTimeout(function() {window.location.href = currentUrl;}, 2000);
                                    });
                                    
                                }
                            }
                            else if (action==2) {
                                showRegisterForm();
                            }
                            else if (action==3) {
                                showRegisterForm("wrong");
                            }
                            else if (action==4) {
                                deleteAccount();
                            }
                            OnionIDLog(response);
                        }
                        else {
                           showMasterPassPopupWithAccounts(response.username, response.password);
                        }
                    },
                    error: function(x, t, m) {
                        if (t === "timeout") {
                            authenticateAttempt(timeout, request, special_url)
                            OnionIDLog("Auth Attempt Timeout!");
                        } else {
                        }
                    }
                })
            }
        }, timeout
    );
}


function authNext(popups, accounts, autologin, geofencing, geoproximity, sdcode, special_url) {

    //Fetch saved sdcode
    var request = {
        "url": currentUrl,
        "sdcode": sdcode,
        "account": account,
        "type": "Chrome Authenticate Account"
    };

    currentPopup = popups[0];

    makePolicyPopup(currentPopup, accounts, request, autologin, authenticateAttempt, special_url);
    /*
     if(geoproximity == 1) {
     $('#onionIDExtraAuth').css("display","block");
     $('#onionIDgeoproximity').css("display","block");
     }

     if(geofencing == 1) {
     $('#onionIDExtraAuth').css("display","block");
     $('#onionIDgeofencing').css("display","block");
     }
     */


}

function getUrlListFromServer (callback) {
    UrlListRequest =  {
        "url": currentUrl,
        "sdcode": sdcode,
        "full_domain": window.location.hostname,
        "type": "Fetch Url List New"
    };
    OnionIDLog("BEFORE JS");
    $.ajax({
        type: "POST",
        url: theServerBefore,
        dataType: "json",
        data: JSON.stringify(UrlListRequest),
        context: document.body,
        timeout: globalTimeout,
        success: function (response) {
            OnionIDLog("GETTING URL RESPONSE");
            urlList = response;
            OnionIDLog(urlList);
            currentTime = Date.now();
            chrome.storage.local.set( {urlList: urlList}, function (obj) {
                chrome.storage.local.set( {"urlCache": {'val': currentTime}}, function (obj) {
                    callback();
                });
            });
        },
        error: function(x, t, m) {
            if (t === "timeout") {
                chrome.storage.local.get( "urlList", function (obj) {
                    OnionIDLog("Getting url list from cache");
                    urlList = obj.urlList.val;
                    callback();
                });
                OnionIDLog("Fetch Url List Timeout!");
            } else {
                OnionIDLog("AWKWARD!!!!");
            }
        }
    })
}

function getBlockUrlListFromServer (callback) {
    UrlListRequest =  {
        "sdcode": sdcode,
        "type": "Browser Fetch Block Url List"
    };
    $.ajax({
        type: "POST",
        url: theServerBefore,
        dataType: "json",
        data: JSON.stringify(UrlListRequest),
        context: document.body,
        timeout: globalTimeout,
        success: function (response) {
            blockUrlList = response.response;
            OnionIDLog(blockUrlList);
            currentTime = Date.now();
            chrome.storage.local.set( {blockUrlList: blockUrlList}, function (obj) {
                chrome.storage.local.set( {"blockUrlCache": {'val': currentTime}}, function (obj) {
                    callback();
                });
            });
        },
        error: function(x, t, m) {
            if (t === "timeout") {
                chrome.storage.local.get( "blockUrlList", function (obj) {
                    blockUrlList = obj.blockUrlList.val;
                    callback();
                });
                OnionIDLog("Browser Fetch Block Url List Timeout!");
            } else {

            }
        }
    })
}

function getUrlList(callback) {
    chrome.storage.local.get( "urlCache", function (obj) {
        if (!jQuery.isEmptyObject(obj)) {
            currentTime = Date.now();
            timeDiff = currentTime -  obj.urlCache.val;
            if (timeDiff < cacheLimit) {
                chrome.storage.local.get( "urlList", function (obj) {
                    urlList = obj.urlList;
                    callback();
                });
            }
            else {
                getUrlListFromServer(callback);
            }
        }
        else {
            getUrlListFromServer(callback);
        }
    }); 
}

function getBlockUrlList(callback) {
    chrome.storage.local.get( "blockUrlCache", function (obj) {
        if (!jQuery.isEmptyObject(obj)) {
            currentTime = Date.now();
            timeDiff = currentTime -  obj.blockUrlCache.val;
            if (timeDiff < cacheLimit) {
                chrome.storage.local.get( "blockUrlList", function (obj) {
                    blockUrlList = obj.blockUrlList;
                    callback();
                });
            }
            else {
                getBlockUrlListFromServer(callback);
            }
        }
        else {
            getBlockUrlListFromServer(callback);
        }
    }); 
}

function sendFilteredAccessNoticeToServer() {

    filteredAccessRequest = {
        "type": "Browser Log Filtered Access",
        "sdcode": sdcode,
        "url": currentUrl
    }

     $.ajax({
        type: "POST",
        url: theServerBefore,
        dataType: "json",
        data: JSON.stringify(filteredAccessRequest),
        context: document.body,
        success: function (response) {
                OnionIDLog("Sent filtered acess request");
            }
        });
}

var currentUrl = window.location.href;
OnionIDLog(currentUrl);
overlay = "<div id=\"onionID_overlay\"><\/div> ";


chrome.runtime.sendMessage ( {command: "fileChoice"}, function (response) {
});


chrome.storage.local.get( "sdcode", function (obj) {
    OnionIDLog(window.location.href);
    if(jQuery.isEmptyObject(obj)) {
    }
    else {
        sdcode = obj.sdcode.val;
        if(window.location.href == chrome.extension.getURL('html/onionid-ban.html')) {
            chrome.storage.local.get("latest_url", function (obj) {
                currentUrl = obj.latest_url;
                chrome.storage.local.get("latest_url_id", function (obj) {
                    theBanUrlId = obj.latest_url_id;
                    OnionIDLog("Current url loaded " + currentUrl);
                    OnionIDLog("Current id loaded " + theBanUrlId);
                    startAuthenticationProcessBefore(sdcode, false);
                    sendFilteredAccessNoticeToServer();
                });
            });
        }
    }
});


