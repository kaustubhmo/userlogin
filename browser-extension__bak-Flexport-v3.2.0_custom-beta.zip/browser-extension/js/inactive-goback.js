/*
 * Browser's back button doesn't help when a user is on a blocked page as it 
 * will take the user back to blocked page since prev page is blocked. 
 * Hence an option is given inside the page to go back two levels.
 * https://app.asana.com/0/1119112800355867/1120494995160534
 * https://developer.chrome.com/extensions/contentSecurityPolicy
 */


/**
 * Navigate two pages back in current tab's history.
 *
 * @param event
 * @returns None
 */

function inactiveGoBackClicked(e) {

    // https://developer.mozilla.org/en-US/docs/Web/API/History_API
    history.go(-1);

}

// Add Go Back button listner on page load
document.addEventListener('DOMContentLoaded', function () {
    document.querySelector('#inactiveGoBack').addEventListener('click', inactiveGoBackClicked);
});