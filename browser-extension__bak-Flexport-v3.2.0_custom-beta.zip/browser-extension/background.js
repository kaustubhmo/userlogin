cacheLimit = 300000;
var theServerBefore = "";
var phpServer = "";
globalTimeout = 10000;
videoStop = true;
recordingsList = "";
var sdcode;
var defaultGeolocation = ''; // OG-733

//OG-733
chrome.storage.local.get("defaultGeolocation", function (obj) {
    if (obj.hasOwnProperty('defaultGeolocation')) {
        console.log('Setting defaultGeolocation var from val in local storage');
        defaultGeolocation = obj.defaultGeolocation.val;
    }
});

//Find Application from url

function findApp(theRequestUrl) {

    var unSplittedUrl = theRequestUrl;
    if (theRequestUrl.indexOf(".comodo") > -1 ) {
        return "comodo";
    }

    if (theRequestUrl.indexOf(".com") > -1 ) {
        theRequestUrl = theRequestUrl.split(".com")[0];
    }
    else if (theRequestUrl.indexOf(".eu") > -1 ) {
        theRequestUrl = theRequestUrl.split(".eu")[0];
    }
    else if (theRequestUrl.indexOf(".net") > -1 ) {
        theRequestUrl = theRequestUrl.split(".net")[0];
    }
    else if (theRequestUrl.indexOf(".io") > -1 ) {
        theRequestUrl = theRequestUrl.split(".io")[0];
    }
    else if (theRequestUrl.indexOf(".org") > -1 ) {
        theRequestUrl = theRequestUrl.split(".org")[0];
    }
    else if (theRequestUrl.indexOf(".gr") > -1 ) {
        theRequestUrl = theRequestUrl.split(".gr")[0];
    }
    else if (theRequestUrl.indexOf(".es") > -1 ) {
        theRequestUrl = theRequestUrl.split(".es")[0];
    }
    else if (theRequestUrl.indexOf(".co") > -1 ) {
        theRequestUrl = theRequestUrl.split(".co")[0];
    }
    else if (theRequestUrl.indexOf(".in") > -1 ) {
        theRequestUrl = theRequestUrl.split(".in")[0];
    }
    else if (theRequestUrl.indexOf(".tv") > -1 ) {
        theRequestUrl = theRequestUrl.split(".tv")[0];
    }
    else if (theRequestUrl.indexOf(".ch") > -1 ) {
        theRequestUrl = theRequestUrl.split(".ch")[0];
    }
    else if (theRequestUrl.indexOf(".ne") > -1 ) {
        theRequestUrl = theRequestUrl.split(".ne")[0];
    }
    else if (theRequestUrl.indexOf(".jp") > -1 ) {
        theRequestUrl = theRequestUrl.split(".jp")[0];
    }
    else if (theRequestUrl.indexOf(".cn") > -1 ) {
        theRequestUrl = theRequestUrl.split(".cn")[0];
    }

    // TODO: implememt this for other apps with same name format
    // https://xxx.yyy.zzz/something.com
    //theRequestUrl until here is https://health.hostedcafe
    //and we want to keep health.hostedcafe in order to not match with health-dev.hostedcafe
    if (!urlIsForNetdefend(unSplittedUrl)
        && ( (unSplittedUrl.indexOf("servicedesk") == -1) && (unSplittedUrl.indexOf("hostedcafe") == -1) )
        && (!urlIsForSecretServer(unSplittedUrl)
        && ( (unSplittedUrl.indexOf("SecretServer") == -1) && (unSplittedUrl.indexOf("ivstg10101.corp.intervision") == -1) ))) {
      theRequestUrl = theRequestUrl.split(".");
      theRequestUrl = theRequestUrl.pop();
    }

    if (theRequestUrl.indexOf("https://")>-1) {
        theRequestUrl = theRequestUrl.split("https://")[1];
    }
    if (theRequestUrl.indexOf("http://")>-1) {
        theRequestUrl = theRequestUrl.split("http://")[1];
    }

    if (theRequestUrl == "force") theRequestUrl = "salesforce";

    return theRequestUrl;

}

function getPhpServer(url) {
    //https://someserver:port we want to remove :port
    parts = url.split(":");
    return parts[0] + ":" + parts[1];
}

function appNeedsHack(theRequestUrl) {

    if (theRequestUrl.indexOf("tsukaeru") > -1) {
        return true;
    }

}

// TODO: implememt this for other apps with same name format
// https://xxx.yyy.zzz/something.com
function urlIsForNetdefend(url) {
  if (url == "https://health.hostedcafe.com/phoenix/login.jsf"
   || url == "https://health.hostedcafe.com/phoenix/login-html.jsf"
   || url == "https://health-dev.hostedcafe.com/phoenix/login.jsf"
   || url == "https://health-dev.hostedcafe.com/phoenix/login-html.jsf"
   || url == "https://health.dev.hostedcafe.com/phoenix/login-html.jsf"
   || url == "https://health.dev.hostedcafe.com/phoenix/login.jsf")
    return true;

  return false;
}

// TODO: implememt this for other apps with same name format
// https://xxx.yyy.zzz/something.com
function urlIsForSecretServer(url) {
  if (url == "https://ivstg10101.corp.intervision.com/SecretServer/login.aspx"
   || url == "http://ivstg10101.corp.intervision.com/SecretServer/login.aspx")
    return true;

  return false;
}

function appFindHack(theRequestUrl) {

    if (theRequestUrl.indexOf("tsukaeru") > -1) {
        return "tsukaeru";
    }

}


if (!Date.now) {
    Date.now = function now() {
        return new Date().getTime();
    };
}

function wrapMenuClick(type) {
  return function(data, tab) {
    chrome.tabs.executeScript(tab.id, {
        code:"showElementSavePopup(\"" + type + "\");"
    });

    setActive(tab.id, false);
  };
};

createProperties = {
    title: "Protect Form",
    contexts: ["editable"],
    onclick: wrapMenuClick("form")
}


createProperties2 = {
    title: "Protect Click",
    contexts: ["page", "selection", "image", "link", "all"],
    onclick: wrapMenuClick("button")
}

createProperties3 = {
    title: "Protect Text",
    contexts: ["page", "selection", "image", "link", "all"],
    onclick: wrapMenuClick("text")
}



chrome.runtime.onMessage.addListener (
    function (request, sender, sendResponse) {

        console.log("Received command " + request.command);
        console.log(sender.tab ?
                "from a content script:" + sender.tab.url :
                "from the extension");

        if (request.command == "geoloc") {

            chrome.storage.local.get(["geoloc", "geocached"], function (obj) {

                if (!jQuery.isEmptyObject(obj) && obj.geocached.hasOwnProperty('val')) {

                    currentTime = Date.now();
                    timeDiff = currentTime - obj.geocached.val;

                    if (timeDiff < 1800000) {
                        theResponse = {
                            cached: true,
                            coords: obj.geoloc.val
                        }
                        console.log('Returning geoloc cachedval: ', obj.geoloc.val);
                        sendResponse(theResponse);
                        return true;
                    }

                }

                theCoords = "";

                var options = {
                    timeout: 5000
                };

                navigator.geolocation.getCurrentPosition(
                    function (position) {
                        try {
                            console.log('Geolocation returned by getCurrentPosition: ', position.coords);
                            theCoords = (position.coords.latitude) ? position.coords.latitude + "," + position.coords.longitude : defaultGeolocation;
                        } catch (e) {
                            console.log('Invalid geolocation returned by getCurrentPosition ', position);
                        }
                        chrome.storage.local.set({"geoloc": {'val': theCoords}}, function (theCoords) {});

                        currentTime = Date.now();
                        chrome.storage.local.set({"geocached": {'val': currentTime}}, function (theCoords) {});
                        theResponse = {
                            cached: false,
                            coords: theCoords
                        }
                        sendResponse(theResponse);
                        return true;
                    },
                    function(error) {
                        switch(error.code) {
                            case 1:
                                sendResponse("User denied the request for Geolocation.");
                                break;
                            case 2:
                                chrome.storage.local.get("geoloc", function (obj) {
                                    theResponse = {};
                                    try {
                                        if (obj.val || defaultGeolocation) {
                                            geoCoords = (obj.val) ? obj.val : defaultGeolocation;
                                            theResponse = {
                                                cached: true,
                                                coords: geoCoords
                                            }
                                            console.log('Using cached/default val due to geoloc lookup returned unavailable', geoCoords);
                                        } else {
                                            theResponse = "Location information is unavailable";
                                            console.log('Unable to lookup cached geoloc or defaultGeoloc on geoloc unavailable error.');
                                        } 
                                    } catch (e) {
                                        theResponse = "Location information is unavailable";
                                        console.log('Location information is unavailable');
                                    }
                                    sendResponse(theResponse);
                                    return true;
                                });
                                break;
                            case 3:  // timed out
                                chrome.storage.local.get("geoloc", function (obj) {
                                    theResponse = {};
                                    try {
                                        if (obj.val || defaultGeolocation) {
                                            geoCoords = (obj.val) ? obj.val : defaultGeolocation;
                                            theResponse = {
                                                cached: true,
                                                coords: geoCoords
                                            }
                                            console.log('Using cached/default val due to geoloc lookup failure', geoCoords);
                                        } else {
                                            theResponse = "Timeout error getting geolocation";
                                            console.log('Unable to lookup cached geoloc or defaultGeoloc on geoloc timeout.');
                                        } 
                                    } catch (e) {
                                        theResponse = "Timeout error getting geolocation";
                                        console.log('Timeout error getting geolocation');
                                    }
                                    sendResponse(theResponse);
                                    return true;
                                });
                            default:
                                responseMsg = (defaultGeolocation) ? {cached: true, coords: defaultGeolocation} : "An unknown error occurred.";
                                console.log('Error looking up geoloc - Using default val ', defaultGeolocation);
                                sendResponse(responseMsg);
                                return true;
                                break;
                        }
                    },
                    options
                );
            });

            return true; // Needed because the response is asynchronous

        }

        if (request.command == "geoip") {
            chrome.storage.local.get(["geoip"], function (geoip) {
                chrome.storage.local.get(["geocached"], function (geocached) {

                    if (!jQuery.isEmptyObject(geoip) && geocached.hasOwnProperty('geocached')) {
                        currentTime = Date.now();
                        timeDiff = currentTime - geocached.geocached.val;

                        if (timeDiff < 1800000) {

                            theResponse = {
                                cached: true,
                                timeout: false,
                                geoip: geoip.geoip.val
                            }
                            sendResponse(theResponse);
                            return true;

                        }
                    }

                    if (jQuery) {
                        $.ajax({
                            type: "GET",
                            url: "http://ip-api.com/json",
                            success: function (geoip) {
                                chrome.storage.local.set({"geoip": {'val': geoip}}, function (geoip) {
                                });
                                theResponse = {
                                    cached: false,
                                    timeout: false,
                                    geoip: geoip
                                }
                                sendResponse(theResponse);
                            },
                            timeout: 5000,
                            error: function (x, t, m) {
                                console.log("error in ip api");
                                if (!jQuery.isEmptyObject(geoip)) {
                                    theResponse = {
                                        cached: true,
                                        timeout: true,
                                        geoip: geoip.geoip.val
                                    }
                                    sendResponse(theResponse);
                                }
                                else {
                                    theResponse = {
                                        cached: true,
                                        timeout: true,
                                        geoip: null
                                    }
                                }

                                sendResponse(theResponse);
                            }

                        });
                    }
                    else {
                        sendResponse("No jquery");
                    }
                });
            });
                return true; // Needed because the response is asynchronous
        }
        if (request.command == "setUninstallUrl") {
            chrome.storage.sync.get("endpoint", function (obj) {
                //

                phpServer = getPhpServer(obj.endpoint);
                console.log("php server is " + phpServer);
                theUrl = phpServer + "/extension/uninstall/" + request.sdcode + "/chrome/" + request.city + "/" + request.ip + "/" + request.country;
                console.log("Set the uninstall url to " + theUrl)
                chrome.runtime.setUninstallURL(theUrl);
                sendResponse('Uninstall url set');
                return true;
            });
        }

        if (request.command == "getCookieSdcode") {
            chrome.cookies.get({"name": "onionid_sdcode", "url": "https://www.onionid.com"}, function(cookie) {
                console.log("Gettting cookie");
                if (cookie) {
                    console.log("The cookie value " + cookie.value);
                    theResponse = {
                        "cookie": cookie.value
                    }
                    sendResponse(cookie.value);
                }
                else {
                    sendResponse(undefined);
                    console.log("Cookie not found");
                }
            });
            return true;
        }

        if (request.command == "getCookieValue") {
            chrome.cookies.get({"name": request.name, "url": request.url}, function (cookie) {
                if (cookie) {
                    console.log("The cookie value " + cookie.value);
                    theResponse = {
                        command: "getCookieValue",
                        status: "success",
                        cookie: cookie.value
                    }
                    sendResponse(theResponse);
                }
                else {
                    sendResponse(undefined);
                    console.log("Cookie not found");
                }
            });
            return true;
        }

        // Fetch all cookies for a url and remove them. OG-661
        if (request.command == "removeAllCookiesByUrl") {
            console.log('Removing cookies for url ' + request.url);

            chrome.cookies.getAll({url: request.url}, cookies => {
                var removedCookies = [];
                cookies.forEach(cookie => {
                    removedCookies.push(cookie.name);
                    chrome.cookies.remove({url: request.url, name: cookie.name}, details => {
                        if (chrome.runtime.lastError)
                            console.warn("Error deleting cookie: " + chrome.runtime.lastError.message);
                    });
                });
                console.log('Cookies removed: ' + removedCookies.join(', '));

                theResponse = {
                    command: "removeAllCookiesByUrl",
                    status: (removedCookies.length) ? "success" : "fail",
                    message: removedCookies
                };
                sendResponse(theResponse);
            });
            return true;
        }

        if (request.command == "stopLoads") {
             chrome.tabs.executeScript(sender.tab.id, {
                    code: "window.stop();",
                    all_frames: "true"
                });
             sendResponse("Done");
             return true;
        }

        if (request.command == "removeMenus") {
            chrome.contextMenus.removeAll(function() {
                console.log("Removing Menus");
                sendResponse("Hoola hoop");
                return true;
            });
        }

        if (request.command == "createMenus") {
                var protectForm = chrome.contextMenus.create(createProperties, function() {
                });
                var protectClick = chrome.contextMenus.create(createProperties2, function() {
                });
                var protectText = chrome.contextMenus.create(createProperties3, function() {
                });
                console.log("protect form: " + protectForm + " protect click: " + protectClick + " protect text: " + protectText);
        }

       if (request.command == "stopVideo") {
            videoStop = true;
       }

       // OG-733
       if (request.command == "setDefaultGeolocation") {
           console.log('Setting defaultGeolocation as ' + request.coords);
           defaultGeolocation = request.coords;
           chrome.storage.local.set({"defaultGeolocation": {'val': defaultGeolocation}}, (resp) => {});
           sendResponse({coords: defaultGeolocation});
           return true;
       }
    }

);

function getUrlListFromServerBackground (callback) {

    chrome.storage.sync.get("endpoint", function (obj) {

        theServerBefore = obj.endpoint;

        UrlListRequest =  {
            "sdcode": sdcode,
            "type": "Fetch Url List New"
        };

        $.ajax({
            type: "POST",
            url: theServerBefore,
            dataType: "json",
            data: JSON.stringify(UrlListRequest),
            context: document.body,
            timeout: globalTimeout,
            success: function (response) {
                console.log('Fetch Url List New response: ', response);
                var urlList = response.filter(function(item) {
                    return item.policy_name != 'LoginAccess';  // All privileged urls except the ones with policy LoginAccess
                });
                currentTime = Date.now();
                chrome.storage.local.set( {urlList: urlList}, function (obj) {
                    chrome.storage.local.set( {"urlCache": {'val': currentTime}}, function (obj) {
                        callback();
                    });
                });

                var logAccessUrlList = response.filter(function (item) {
                    return item.policy_name == 'LoginAccess';  // Save privileged urls with policy 'LoginAccess' separately for tracking only
                });
                chrome.storage.local.set({logAccessUrlList: logAccessUrlList}, function (obj) {});
            },
            error: function(x, t, m) {
                if (t === "timeout") {
                    chrome.storage.local.get( "urlList", function (obj) {
                        urlList = obj.urlList.val;
                        console.log(urlList);
                        callback();
                    });
                } else {
                }
            }
        })
    });
}

function getUrlListBackground(callback) {
    chrome.storage.local.get( "urlCache", function (obj) {
        if (!jQuery.isEmptyObject(obj)) {
            currentTime = Date.now();
            timeDiff = currentTime -  obj.urlCache.val;
            //console.log("The cache value " + obj.urlCache.val);
            //console.log("The current time " + currentTime);
            //console.log("The current timediff " + timeDiff);
            if (timeDiff < cacheLimit) {
                chrome.storage.local.get( "urlList", function (obj) {
                    urlList = obj.urlList;
                    callback();
                });
            }
            else {
                getUrlListFromServerBackground(callback);
            }
        }
        else {
            getUrlListFromServerBackground(callback);
        }
    });
}

function urlIsInUrlListBackground(urlList, useHash, tab) {

    //console.log("Checking if url is in url list");
    if (!urlList) {
        //console.log("There are no blocked urls");
        return false;
    }

    if (useHash)
        var currentHash = CryptoJS.SHA1(currentUrl).toString(CryptoJS.enc.Hex)
    else
        var currentHash = tab.url;

    //if we are using hash look for exact match
    if (useHash) {
        if ($.inArray(currentHash, urlList) != -1)
            return true;
        else
            return false;
    }
    else {
        banIt = false;
        $.each(urlList, function(index, url) {
            banIt = banLogicBackground(url.url, currentHash);
            if (banIt) {
                theBanUrlIdBackground = url.id;
                chrome.storage.local.set({bannedUrlId: theBanUrlIdBackground}, function() {
                });
                theBanUrl = url.url;
                console.log("Banning url with id " + theBanUrlIdBackground);
                return false;
            }
        });
        return banIt;
    }
}
var saveBannedUrl;
function banLogicBackground(url, currentHash) {
    //console.log("URL is " + url + " and currentHASH " + currentHash);
    saveBannedUrl = currentHash;
    if (url.indexOf("^") > -1) {
      //using regural expression for ambiguous url
      var urlParts = url.split("^");
      var finalUrl = "";
      var expression = "(([-a-zA-Z0-9@:%_+*.,;\\[\\]$'!()~#?&//=]*)?)";

      $.each(urlParts, function(index, part) {
          finalUrl = finalUrl + part;
          if (index != urlParts.length-1) {
            //dont add reg exp in the end
            finalUrl = finalUrl + expression;
          }
      });
      var regex = new RegExp(finalUrl);
      return regex.test(currentHash);
    }
    //for expicit urls
    return (currentHash.indexOf(url) > -1);
}

function showBlackBlockMessageBackground(tab, mode) {
    if (mode == "restrict")
        window.location.href = chrome.extension.getURL('html/onionid-ban-restrict.html');
    else {
       chrome.storage.local.set({saveBanned: saveBannedUrl}, function() {
       });

       chrome.tabs.update(tab.id,{
           url: chrome.extension.getURL('html/onionid-ban.html')
       });
    }
}

function getBlockUrlListFromServerBackground(callback) {
    chrome.storage.sync.get("endpoint", function (obj) {
        theServerBefore = obj.endpoint;
        UrlListRequest = {
            "sdcode": sdcode,
            "type": "Browser Fetch Block Url List"
        };
        $.ajax({
            type: "POST",
            url: theServerBefore,
            dataType: "json",
            data: JSON.stringify(UrlListRequest),
            context: document.body,
            timeout: globalTimeout,
            success: function (response) {
                blockUrlList = response.response;
                currentTime = Date.now();
                chrome.storage.local.set({blockUrlList: blockUrlList}, function (obj) {
                    chrome.storage.local.set({"blockUrlCache": {'val': currentTime}}, function (obj) {
                        callback();
                    });
                });
            },
            error: function (x, t, m) {
                if (t === "timeout") {
                    chrome.storage.local.get("blockUrlList", function (obj) {
                        blockUrlList = obj.blockUrlList.val;
                        callback();
                    });
                    console.info("Browser Fetch Block Url List Timeout!");
                }
            }
        });
    });
}

function getBlockUrlListBackground(callback) {
    chrome.storage.local.get("blockUrlCache", function (obj) {

        if (!jQuery.isEmptyObject(obj)) {
            currentTime = Date.now();
            timeDiff = currentTime - obj.blockUrlCache.val;
            if (timeDiff < cacheLimit) {
                chrome.storage.local.get("blockUrlList", function (obj) {
                    blockUrlList = obj.blockUrlList;
                    callback();
                });
            } else {
                getBlockUrlListFromServerBackground(callback);
            }
        } else {
            getBlockUrlListFromServerBackground(callback);
        }
    });
}

function urlIsInBlockUrlListBackground(blockUrlList, useHash, tab) {

    if (!blockUrlList) {
        return false;
    }

    blockUrlList = blockUrlList.split(",");

    var theUrl = tab.url;
    var currentHash = '';

    if (useHash) {
        currentHash = CryptoJS.SHA1(theUrl).toString(CryptoJS.enc.Hex)
    } else {
        currentHash = tab.url;
    }

    //if we are using hash look for exact match
    if (useHash) {
        if ($.inArray(currentHash, blockUrlList) != -1) {
            return true;
        } else {
            return false;
        }
    } else {
        var blockIt = false;
        $.each(blockUrlList, function (index, url) {
            if (theUrl.indexOf(url) > -1) {
                blockIt = true;
            }
        });
        return blockIt;
    }
}

window.setInterval(function(){
    chrome.tabs.getSelected(null,function(tab){
        if (tab.url.indexOf("http://") != -1 || tab.url.indexOf("https://") != -1){
            chrome.storage.sync.get( "sdcode", function (obj) {
                //console.log(window.location.href);
                if (jQuery.isEmptyObject(obj)) {
                }
                else {
                    sdcode = obj.sdcode.val;
                }
                getUrlListBackground(function() {
                    if (urlIsInUrlListBackground(urlList, false, tab)) {
                        getPass = "pass" + theBanUrlIdBackground;
                        //console.log(getPass);
                        chrome.storage.local.get(getPass, function(obj) {
                            console.log("Pass value is " + obj[getPass]);
                            var timeDiff = Date.now() - obj[getPass];
                            if (!jQuery.isEmptyObject(obj) && timeDiff < 300000) {
                                var passObj = {};
                                passName = "pass" + theBanUrlIdBackground;
                                passValue = obj[getPass] - 1;
                                passObj[passName] = passValue;
                                //console.log(passObj);
                            }
                            else {
                                chrome.storage.local.set( {"latest_url": tab.url}, function () {
                                    chrome.storage.local.set( {"latest_url_id": theBanUrlIdBackground}, function () {
                                       showBlackBlockMessageBackground(tab);
                                    });
                                });
                            }
                        });
                    }
                });

                // Check if any tab is having blocked URL
                getBlockUrlListBackground(function () {

                    if (urlIsInBlockUrlListBackground(blockUrlList, false, tab)) {
                        chrome.tabs.update(tab.id, {
                            url: chrome.extension.getURL('html/onionid-ban-restrict.html')
                        });
                    }
                });
            });
        }
    });
},500);


window.setInterval(function(){
        getListOfRecordings();
}, 30000);


 window.setInterval(function(){
    chrome.tabs.getSelected(null,function(tab){
        if (tab.url.indexOf("http://") != -1 ||
           tab.url.indexOf("https://") != -1){
            // console.log(tab.url);  // TODO: Uncomment to debug
            if (appIsInRecordingList(tab.url)) {
                var app = findApp(tab.url);
                chrome.tabs.captureVisibleTab(null, {
                    format: 'jpeg',
                    quality: 35
                }, function (img) {
                    console.log(img);
                    var xhr = new XMLHttpRequest();
                    var formData = new FormData();
                    chrome.storage.sync.get( "sdcode", function (obj) {
                        if (jQuery.isEmptyObject(obj)) {
                        }
                        else {
                            sdcode = obj.sdcode.val;
                        }
                        
                        chrome.storage.sync.get("appUsernameList", function (obj) {
                            var appUsernameList = obj.appUsernameList;
                            console.log("Fetching appUsernameList to get the username for " + app);
                            console.log(appUsernameList);
                            var appUsername = '';

                            if (!jQuery.isEmptyObject(appUsernameList) && appUsernameList[app] != undefined) {
                                appUsername = appUsernameList[app];
                            }
                                
                            chrome.storage.sync.get("endpoint", function (obj) {
                               //Get php server url from endpoint (remove port)
                               phpServer = getPhpServer(obj.endpoint);
                               xhr.open("POST", phpServer + "/api/v1/video/update", true);
                               xhr.setRequestHeader("Content-type",
                                   "application/x-www-form-urlencoded");
                               xhr.onreadystatechange = function() {
                                   if (xhr.readyState == 4) {
                                       console.log("SEEENTTTTT");
                                       console.log(xhr.responseText);
                                   }
                               }
                               
                               var tabUrl = new URL(tab.url);
                               xhr.send("img=" + img + "&sdcode=" + sdcode + "&application=" + app + "&full_domain=" + tabUrl.hostname + "&app_username=" + appUsername);
                               console.log("Sent request!!!!!!");
                           });
                       });
                    });
                });
            }
        }
    });
}, 500);

function appIsInRecordingList(theUrl) {
    console.log('recordingsList: ');  // TODO: [Un]comment to debug
    console.log(recordingsList);      // TODO: [Un]comment to debug
    if ($.inArray(findApp(theUrl), recordingsList) != -1){
        console.log("App found in recordingsList!");
        return true;
    }
    else {
        var tabUrl = new URL(theUrl);
        if ($.inArray(tabUrl.hostname, recordingsList) != -1) {
            console.log("App found in recordingsList via tab hostname!");
            return true;
        } else if ($.inArray(document.domain, recordingsList) != -1) {
            console.log("App found in recordingsList via hostname");
            return true;
        } else {
            console.log("App NOT found in recordingsList.");  // TODO: [Un]comment to debug
            return false;
        }
    }
}


function getListOfRecordings() {

    chrome.storage.local.get( "recordingsCache", function (obj) {
        if (!jQuery.isEmptyObject(obj)) {
            currentTime = Date.now();
            timeDiff = currentTime -  obj.recordingsCache;
            console.log(timeDiff/1000);
            if (timeDiff < 30000) {
                chrome.storage.local.get( "recordingsList", function (obj) {
                    recordingsList = obj.recordingsList.applications;
                });
            }
            else {
                getRecordingsListFromServer();
            }
        }
        else {
            getRecordingsListFromServer();
        }
    });

}

function getRecordingsListFromServer() {
    chrome.storage.sync.get("endpoint", function (obj) {
        //Get php server url from endpoint (remove port)
        phpServer = getPhpServer(obj.endpoint);
        $.ajax({
            type: "GET",
            url: phpServer + "/api/v1/video/user/sessions?sdcode=" + sdcode,
            success: function (response) {
                recordingsList = response.applications;
                console.log(recordingsList);
                console.log("FROM SERVER");
                currentTime = Date.now();
                chrome.storage.local.set( {recordingsList: response}, function (obj) {
                    chrome.storage.local.set( {"recordingsCache": currentTime}, function (obj) {
                    });
                });
            },
            error: function(x, t, m) {
                currentTime = Date.now();
                chrome.storage.local.set( {"recordingsCache": currentTime}, function (obj) {
                });
                if (t==="timeout") {
                    console.warn("Timeout for Recordings list!");
                } else {
                }
            }
        });
    });

}




chrome.runtime.onInstalled.addListener(function(details) {
    if (details.reason == "install") {
        chrome.tabs.create({
        });
    }
});


/**
 * Fetch general_development_mode org setting from api and set in local storage of browser.
 *
 * @param none
 * @returns none
 */
function setDevelopmentMode() {

    // Return if no valid sdcode is set
    if (typeof sdcode === 'undefined' || sdcode === null || !sdcode) {
        return false;
    }

    chrome.storage.sync.get("endpoint", function (obj) {
        FetchElementsRequest =  {
            "sdcode": sdcode,
            "type": "Browser Fetch Development Mode Setting"
        };

        $.ajax({
            type:    "POST",
            url:      obj.endpoint,
            dataType: "json",
            data:    JSON.stringify(FetchElementsRequest),
            context: document.body,
            timeout: globalTimeout,
            success: function (response) {

                // Set general_development_mode result in localstorage
                if (response != null && response != []) {
                    if (typeof response.general_development_mode !== 'undefined')
                        value = response.general_development_mode;
                    else
                        value = "false";

                    chrome.storage.local.set({"general_development_mode": value}, function() {
                        if (chrome.runtime.error) {
                            console.log("Runtime error on setting general_development_mode.");
                        }
                    });
                }
            },
            error: function(x, t, m) {
                if (t === "timeout") {
                    console.log("Fetch Development Mode Setting Timeout!");
                } else {
                    console.log(m);
                }
            }
        });
    });
}

// Fetch current general_development_mode of org periodically and update in local
window.setInterval(function() {
    setDevelopmentMode();
}, 10000);


// For privileged urls to be tracked, fetch geolocation for loaded url and log access.
function logURL(requestDetails) {
    //console.log("Loading req: ", requestDetails.url);

    // Return if no valid sdcode is set
    if (typeof sdcode === 'undefined' || sdcode === null || !sdcode) {
        console.log("sdcode not set. Not logging url.");        
        return false;
    }

    // Log access of special_url having LoginAccess policy
    chrome.storage.local.get('logAccessUrlList', function (obj) {
        var decodedUrl = decodeURI(requestDetails.url);
        obj.logAccessUrlList.forEach(function (page) {
            if (decodedUrl == page.url) {
                console.log("Logging privileged url access from tabId: ", requestDetails.requestHeaders.tabId);
                // Do not do auth. Only log access of special_url having LoginAccess policy
                // Similar to "startAuthenticationProcess(sdcode, false, false, true);"
                var attempt = {sdcode: sdcode, url: page.url, urlId: page.id};
                geoloc(attempt, geoip, AddBockedUrlAccessAttempt)
            }
        });
    });
  }

// Find geolocation and poceed with callbacks
function geoloc (attempt, callback, callback2) {
    chrome.storage.local.get(["geoloc", "geocached"], function (obj) {
        if (!jQuery.isEmptyObject(obj)) {
            currentTime = Date.now();
            timeDiff = currentTime - obj.geocached.val;
            // Use cached geoloc coordinates
            if (timeDiff < 1800000) {
                attempt.coords = obj.geoloc.val;
                console.log('geoloc cached callback attempt: ', obj.geocached.val);
                callback(attempt, callback2);
                return true;
            }
        }
        console.log('geoloc not available already');
        theCoords = "";
        var options = {timeout: 5000};

        navigator.geolocation.getCurrentPosition(
            function (position) {
                theCoords = position.coords.latitude + "," + position.coords.longitude;
                attempt.coords = theCoords;  // TODO: Set defaultGeolocation - OG-733
                console.log(`navigator.geolocation.getCurrentPosition coords: ${theCoords}`);
                callback(attempt, callback2);
            },
            function(error) {
                switch (error.code) {
                    case 3:
                        chrome.storage.local.get(["geoloc", "geocached"], function (obj) {
                            attempt.coords = obj.geoloc.val;  // TODO: Set defaultGeolocation - OG-733
                            callback(attempt, callback2);
                        });
                        return true;
                    case 1:
                    case 2:
                    default:
                        attempt.coords = '';  // TODO: Set defaultGeolocation - OG-733
                        callback(attempt, callback2);
                        break;
                }
            },
            options
        );
    });
}

// Find geoip and proceed with callback
function geoip (attempt, callback) {
    chrome.storage.local.get(["geoip"], function (geoip) {
        chrome.storage.local.get(["geocached"], function (geocached) {

            if (!jQuery.isEmptyObject(geoip)) {
                currentTime = Date.now();
                timeDiff = currentTime - geocached.geocached.val;
                if (timeDiff < 1800000) {
                    console.log('geoip callback  with cacheed val ', geoip.geoip.val);
                    attempt.geoip = geoip.geoip.val;
                    callback(attempt);
                    return true;
                }
            }

            if (jQuery) {
                $.ajax({
                    type: "GET",
                    url: "http://ip-api.com/json",
                    success: function (geoip) {
                        console.log('GET ip-api.com response ', geoip);
                        attempt.geoip = geoip;
                        callback(attempt);
                    },
                    timeout: 5000,
                    error: function (x, t, m) {
                        console.log("GET ip-api.com error");
                        if (!jQuery.isEmptyObject(geoip)) 
                            attempt.geoip = geoip.geoip.val;
                        else 
                            attempt.geoip = null;
                        callback(attempt);
                    }
                });
            } else {
                attempt.geoip = geoip.geoip.val;
                callback(attempt);
            }
        });
    });
}

// Send AddBockedUrlAccessAttempt API request based on request url/geoloc etc 
function AddBockedUrlAccessAttempt (attempt) {

    var host = (new URL(attempt.url)).host;
    var policyRequest = {
            "urlId":  attempt.urlId,
            "url":    attempt.url,
            "full_domain": host,
            "type":   "AddBockedUrlAccessAttempt",
            "sdcode": attempt.sdcode,
            "coords": attempt.coords,
            "city":   attempt.geoip.city,
            "country":attempt.geoip.country,
            "state":  attempt.geoip.regionName,
            "ip":     attempt.geoip.query,
            "agent":  navigator.appVersion
    };

    chrome.storage.sync.get("endpoint", function (obj) {
        theServerBefore = obj.endpoint;    
        console.log(`AddBockedUrlAccessAttempt- theServerBefore: ${theServerBefore}, policyRequest: `, policyRequest);

        $.ajax({
            type: "POST",
            url: theServerBefore,
            dataType: "json",
            data: JSON.stringify(policyRequest),
            timeout: globalTimeout,
            success: function (response) {
                console.log("AddBockedUrlAccessAttempt xhr success!");
            },
            error: function (x, t, m) {
                if (t === "timeout") {
                    console.log("AddBockedUrlAccessAttempt Timeout!");
                } else {
                    console.log('Network Error. Please, verify your network connection.');
                }
            }
        });
    });
}

// Invoke privileged url tracking code for all page requests - OG-605
  chrome.webRequest.onBeforeSendHeaders.addListener(
    logURL,
    {urls: ["<all_urls>"]},
    ["requestHeaders"]
  );

//* Fetch general_inactive_mode setting from api and set in local storage of browser.
 function setInactiveMode() {

    // Return if no valid sdcode is set
    if (typeof sdcode === 'undefined' || sdcode === null || !sdcode) {
        return false;
    }
     chrome.storage.sync.get("endpoint", function (obj) {
        FetchSettings =  {
            "sdcode": sdcode,
            "type": "Browser Fetch User Inactive Mode Setting"
        };
        $.ajax({
            type:    "POST",
            url:      obj.endpoint,
            dataType: "json",
            data:    JSON.stringify(FetchSettings),
            context: document.body,
            timeout: globalTimeout,
             success: function (response) {
                 
                if (response != null && response != []) {
                    if (typeof response.user_inactive_mode !== 'undefined')
                        value = response.user_inactive_mode;
                    else
                        value = "false";

                    chrome.storage.local.set({"user_inactive_mode": value}, function() {
                        if (chrome.runtime.error) {
                            console.log("Runtime error on setting User Inactive Mode Setting.");
                        }
                    });
                }
            },
                 error: function(x, t, m) {
                if (t === "timeout") {
                    console.log("User Inactive Mode Setting Timeout!");
                } else {
                    console.log(m);
                }
            }
        });
    });
 }
//* Fetch general_inactive_time org setting from api and set in local storage of browser.
 function setInactiveTimePeriod() {

    // Return if no valid sdcode is set
    if (typeof sdcode === 'undefined' || sdcode === null || !sdcode) {
        return false;
    }
     chrome.storage.sync.get("endpoint", function (obj) {
        FetchInactiveTime =  {
            "sdcode": sdcode,
            "type": "Browser Fetch User Inactive Setting Time Period Setting"
        };
        $.ajax({
            type:    "POST",
            url:      obj.endpoint,
            dataType: "json",
            data:    JSON.stringify(FetchInactiveTime),
            context: document.body,
            timeout: globalTimeout,
             success: function (response) {
                 
                if (response != null && response != []) {
                    if (typeof response.user_inactive_time !== 'undefined')
                        value = response.user_inactive_time;
                    else
                        value = "false";

                    chrome.storage.local.set({"user_inactive_time": value}, function() {
                        if (chrome.runtime.error) {
                            console.log("Runtime error on setting User Inactive Time Setting.");
                        }
                    });
                }
            },
                 error: function(x, t, m) {
                if (t === "timeout") {
                    console.log("User Inactive Time Setting Timeout!");
                } else {
                    console.log(m);
                }
            }
        });
    });
 }
// Fetch current general_inactive_mode of org periodically and update in local
 window.setInterval(function() {
    setInactiveMode();
    setInactiveTimePeriod();
} , 300000);
 
  
 var timeInMilliseconds;
 window.setInterval(function(){
    chrome.storage.local.get("user_inactive_mode", function (obj) {
        inactiveStatusMode = obj.user_inactive_mode;
        if (inactiveStatusMode == 'true')   {
            chrome.storage.local.get("user_inactive_time", function (obj) {
                var timeInMinuts = obj.user_inactive_time;
                timeInMilliseconds = timeInMinuts * 60;
                if (timeInMilliseconds == '0') 
                timeInMilliseconds = 30 * 60;
                chrome.idle.queryState(timeInMilliseconds, function (state) {
                    if (state != "active") {
                        chrome.storage.local.get( "appList", function (obj) {
                            appList = obj.appList.split(",");
                            var queryInfo = {
                                currentWindow: true
                            };
                            
                            chrome.tabs.query(queryInfo, function (tabs,useHash) {
                                for (var i = 0; i < tabs.length; i++) {
                                    var taburl = tabs[i]['url'];
                                    var domain = taburl.replace('http://','').replace('https://','').split(/[/?#]/)[0];
                                    currentApp = findApp(taburl);
                                    var tabid = tabs[i]['id'];
                                    currentHashUrl = CryptoJS.SHA1(currentApp).toString(CryptoJS.enc.Hex);
                                    if ($.inArray(currentHashUrl, appList) != -1 && currentApp != 'onionid' ) {
                                        chrome.tabs.update(tabid, {
                                      
                                        url: chrome.extension.getURL('html/onionid-ban-inactive-app.html')
                                        });
//                                    chrome.cookies.getAll({domain: domain }, function(cookies) {
//                                    for(var i=0; i<cookies.length;i++) {
//                                     console.log('ok');
//                                    chrome.cookies.remove({url: taburl + cookies[i].path, name: cookies[i].name});
//                                    }
//                                    });
                                    }
                                }      
                            });
                        });
                    }
                });
            });
        }
    });
 } ,timeInMilliseconds); 